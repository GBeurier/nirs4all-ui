import { StrictMode, useEffect, useRef, useState } from 'react'
import { createRoot } from 'react-dom/client'
import { N4aInspector, projectN4aInspection, projectN4aPreview, type N4aInspectionView, type N4aPreviewState } from 'nirs4all-ui/n4aInspector'
import 'nirs4all-ui/assets/theme.css'
import 'nirs4all-ui/assets/workbench.css'
import 'nirs4all-ui/assets/qualification.css'
import 'nirs4all-ui/assets/dag.css'
import 'nirs4all-ui/assets/viz.css'
import 'nirs4all-ui/assets/n4a-inspector.css'
import './style.css'

function App() {
  const [inspection, setInspection] = useState<N4aInspectionView | null>(null)
  const [phase, setPhase] = useState<'idle' | 'opening' | 'ready' | 'error'>('idle')
  const [error, setError] = useState<string | null>(null)
  const [previews, setPreviews] = useState<Record<string, N4aPreviewState>>({})
  const [rows, setRows] = useState(32)
  const [variant, setVariant] = useState<'explorer' | 'compact'>('explorer')
  const [theme, setTheme] = useState(() => window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light')
  const worker = useRef<Worker | null>(null)
  const fileInput = useRef<HTMLInputElement>(null)
  const rowsRef = useRef(rows)
  rowsRef.current = rows
  useEffect(() => { document.documentElement.dataset.theme = theme }, [theme])
  useEffect(() => () => worker.current?.terminate(), [])
  function close() {
    worker.current?.terminate()
    worker.current = null
    setInspection(null); setPreviews({}); setError(null); setPhase('idle')
  }
  function open(files: FileList | readonly File[]) {
    close()
    if (files.length !== 1) { setError('Select one container at a time.'); setPhase('error'); return }
    const file = files[0]!
    setPhase('opening')
    const next = new Worker(new URL('./worker.ts', import.meta.url), { type: 'module' })
    worker.current = next
    next.onmessage = ({ data }) => {
      if (worker.current !== next) return
      try {
        if (data.type === 'opened') {
          setInspection(projectN4aInspection(data.report, file.name)); setPhase('ready')
        } else if (data.type === 'preview' && data.rows === rowsRef.current) {
          const preview = projectN4aPreview(data.preview)
          setPreviews(current => ({ ...current, [data.artifactId]: { status: 'ready', preview } }))
          setInspection(current => current ? { ...current, artifacts: current.artifacts.map(artifact => artifact.id === data.artifactId ? { ...artifact, contentStatus: preview.status, contentDetail: preview.detail } : artifact) } : current)
        } else if (data.type === 'error') {
          if (data.artifactId && data.rows === rowsRef.current) setPreviews(current => ({ ...current, [data.artifactId]: { status: 'error', message: data.message } }))
          else if (!data.artifactId) { setError(data.message); setPhase('error'); next.terminate(); worker.current = null }
        }
      } catch (cause) { setError(cause instanceof Error ? cause.message : String(cause)); setPhase('error'); next.terminate(); worker.current = null }
    }
    next.onerror = event => { if (worker.current === next) { setError(event.message || 'The inspection worker stopped.'); setPhase('error'); next.terminate(); worker.current = null } }
    next.postMessage({ type: 'open', file })
  }
  function requestPreview(artifactId: string) {
    if (!worker.current) return
    setPreviews(current => ({ ...current, [artifactId]: { status: 'loading' } }))
    worker.current.postMessage({ type: 'preview', artifactId, rows })
  }
  async function loadExample() {
    try {
      const response = await fetch('./examples/synthetic-signals.n4a')
      if (!response.ok) throw new Error('The synthetic example could not be loaded.')
      open([new File([await response.blob()], 'synthetic-signals.n4a')])
    } catch (cause) { setError(cause instanceof Error ? cause.message : String(cause)); setPhase('error') }
  }
  function exportReport() {
    if (!inspection) return
    const url = URL.createObjectURL(new Blob([JSON.stringify({ schema: 'nirs4all.inspection-report.v1', inspection, previews }, null, 2)], { type: 'application/json' }))
    const link = document.createElement('a'); link.href = url; link.download = `${inspection.fileName}.inspection.json`; link.click()
    setTimeout(() => URL.revokeObjectURL(url), 1000)
  }
  return <main className="n4ai-host">
    <div className="n4ai-host-bar"><a href="../">nirs4all</a><span>Local container inspection</span><button type="button" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}>{theme === 'dark' ? 'Light theme' : 'Dark theme'}</button></div>
    <N4aInspector key={inspection?.containerSha256 ?? 'empty'} inspection={inspection} phase={phase} error={error} previews={previews} variant={variant} onRequestPreview={requestPreview} onClose={close} onExportReport={exportReport}
      headerActions={<label>View <select aria-label="View" value={variant} onChange={event => setVariant(event.target.value as 'explorer' | 'compact')}><option value="explorer">Explorer</option><option value="compact">Compact</option></select></label>}
      sourceSlot={<section className="n4ai-host-source" aria-label="Open a local container" onDragOver={event => event.preventDefault()} onDrop={event => { event.preventDefault(); open(event.dataTransfer.files) }}>
        <p>Drop a .n4a file here, or <button type="button" onClick={() => fileInput.current?.click()}>Browse files</button>.</p>
        <input hidden ref={fileInput} aria-label="Choose a .n4a container" type="file" accept=".n4a" onChange={event => { if (event.target.files?.length) open(event.target.files); event.target.value = '' }} />
        <p>Files stay on your device. References are listed without fetching external content.</p>
        <button type="button" onClick={loadExample}>Load synthetic example</button>
        <label>Rows per preview <input aria-label="Rows per preview" type="number" min="1" step="1" value={rows} onChange={event => { const value = Number(event.target.value); if (Number.isSafeInteger(value) && value > 0) { setRows(value); setPreviews({}) } }} /></label>
        {phase === 'opening' ? <button type="button" onClick={close}>Cancel inspection</button> : null}
      </section>} />
  </main>
}
createRoot(document.getElementById('root')!).render(<StrictMode><App /></StrictMode>)
