import { inspectN4aContainer, type N4aInspectionSession } from 'nirs4all'
import { datasetInspectionPorts } from '@nirs4all/io-wasm/inspection'
import { dagMlInspectionPorts } from 'dag-ml-wasm/artifact-inspector'
import { webHostInspectionPort } from '../src/lib/n4a-inspection-port'

let session: N4aInspectionSession | undefined
self.onmessage = async (event: MessageEvent) => {
  const request = event.data
  try {
    if (request.type === 'open') {
      session?.close()
      session = await inspectN4aContainer(request.file, { previewers: [...datasetInspectionPorts, ...dagMlInspectionPorts, webHostInspectionPort] })
      self.postMessage({ type: 'opened', report: session.report() })
    } else if (request.type === 'preview') {
      if (!session) throw new Error('Open a container before requesting previews.')
      const preview = await session.preview(request.artifactId, { maxRows: request.rows })
      self.postMessage({ type: 'preview', artifactId: request.artifactId, rows: request.rows, preview })
    } else if (request.type === 'close') {
      session?.close()
      session = undefined
    }
  } catch (error) {
    self.postMessage({ type: 'error', artifactId: request.artifactId, rows: request.rows, message: error instanceof Error ? error.message : String(error) })
  }
}
