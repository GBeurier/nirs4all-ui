// SPDX-License-Identifier: CeCILL-2.1 OR AGPL-3.0-or-later
// Passive projections of DAG-owned persisted schemas. Never compile, rescore or import fitted state.
const SCHEMAS = {
  'dagml.graph_spec': [1, 'pipeline'],
  'dagml.execution_plan': [1, 'pipeline'],
  'dagml.execution_bundle': [2, 'result'],
  'dagml.score_set': [2, 'result'],
  'dagml.training_outcome': [2, 'result'],
  'dagml.portable_predictor_package': [2, 'model'],
  'dagml.portable_refit_package': [3, 'model'],
  'dagml.initial_full_refit_package': [1, 'model'],
  'dagml.prediction_cache_payload_set': [2, 'result'],
};
const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const scalar = value => value === null || ['string', 'number', 'boolean'].includes(typeof value) ? value : JSON.stringify(value);

export function inspectDagMlArtifact(bytes, artifact, options = {}) {
  const definition = SCHEMAS[artifact.content_type.id];
  if (artifact.owner !== 'dag-ml' || !definition || artifact.content_type.version !== definition[0]) throw new TypeError('Unsupported DAG inspection schema or version.');
  const maxRows = options.maxRows ?? 32;
  if (!Number.isSafeInteger(maxRows) || maxRows < 1) throw new TypeError('Preview maxRows must be a positive integer.');
  const value = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(bytes));
  if (!object(value)) throw new TypeError('A DAG artifact must be a JSON object.');
  if (value.schema_version !== undefined && value.schema_version !== definition[0]) throw new TypeError('DAG payload version differs from its declared content type.');
  const fields = [];
  for (const key of ['id', 'schema_version', 'outcome_id', 'run_id', 'package_id', 'plan_id', 'status', 'selection_metric', 'selection_output_id', 'warnings', 'unsafe_flags', 'replayable_phases', 'fitted_artifact_mode', 'predictor_node_ids', 'data_requirements', 'data_identities', 'training_outcome']) {
    if (value[key] !== undefined) fields.push({ label: key, value: String(scalar(value[key])) });
  }
  const tables = [];
  const graph = value.effective_plan?.graph_plan?.graph ?? value.graph_plan?.graph ?? value.template?.graph ?? (Array.isArray(value.nodes) ? value : undefined);
  if (graph) tables.push({ title: 'Stored graph nodes', columns: ['Node', 'Kind', 'Operator', 'Parameters'],
    rows: graph.nodes.slice(0, maxRows).map(node => [node.id, node.kind, scalar(node.operator), scalar(node.params)]), totalRows: graph.nodes.length });
  const scores = value.scores ?? value.score_set ?? value;
  if (Array.isArray(scores.reports)) {
    const rows = scores.reports.flatMap(report => Object.entries(report.metrics ?? {}).map(([metric, score]) => [
      metric, scalar(score), report.partition ?? null, report.fold_id ?? null, report.level ?? null,
      scalar(report.target_names ?? null), report.producer_node ?? null, report.variant_id ?? null, report.prediction_id ?? null,
    ]));
    tables.push({ title: 'Stored metric reports', columns: ['Metric', 'Value', 'Partition', 'Fold / aggregate', 'Level', 'Targets', 'Producer', 'Variant', 'Prediction ID'], rows: rows.slice(0, maxRows), totalRows: rows.length });
  }
  for (const key of ['bindings', 'model_states', 'artifacts', 'predictions', 'output_bindings', 'artifact_bindings']) {
    if (Array.isArray(value[key])) tables.push({ title: key, columns: ['Stored entry'], rows: value[key].slice(0, maxRows).map(row => [scalar(row)]), totalRows: value[key].length });
  }
  const result = { artifactId: artifact.id, kind: definition[1], title: value.id ?? value.package_id ?? value.outcome_id ?? value.plan_id ?? artifact.id,
    status: 'not_evaluated', detail: 'Read-only projection of declared DAG content. Owner semantic validity, links and execution admission are not evaluated. Scores are copied without recalculation; folds and aggregates retain their stored labels. JSON numeric display uses JavaScript number precision.', fields, tables };
  if (graph) result.graph = graph;
  return result;
}

export const dagMlInspectionPorts = Object.entries(SCHEMAS).map(([contentType, [version]]) => ({ owner: 'dag-ml', contentType, version, inspect: inspectDagMlArtifact }));
