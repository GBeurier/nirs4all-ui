export interface InspectionArtifact { id: string; owner: string; content_type: { id: string; version: number }; }
export function inspectDagMlArtifact(bytes: Uint8Array, artifact: InspectionArtifact, options?: { maxRows?: number }): {
  artifactId: string; kind: 'pipeline' | 'result' | 'model'; title: string; status: 'not_evaluated'; detail: string;
  fields: { label: string; value: string }[];
  tables: { title: string; columns: string[]; rows: (string | number | boolean | null)[][]; totalRows: number }[];
  graph?: unknown;
};
export const dagMlInspectionPorts: { owner: 'dag-ml'; contentType: string; version: number; inspect: typeof inspectDagMlArtifact }[];
