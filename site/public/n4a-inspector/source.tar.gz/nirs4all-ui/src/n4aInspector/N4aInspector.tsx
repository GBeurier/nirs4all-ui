// SPDX-License-Identifier: CeCILL-2.1 OR AGPL-3.0-or-later
/**
 * Presentational inspector for a `.n4a` container whose storage Core has verified.
 *
 * The host reads the file, has Core verify its storage, projects the result with
 * `projectN4aInspection` and passes the view here. The component never reads a
 * File, fetches, starts a worker or loads an owner: previews are produced by the
 * host only when the user asks (`onRequestPreview`). It reuses the workbench chrome
 * (`assets/workbench.css`) and the existing spectra, graph and Inspector views; its own
 * scoped rules live in `assets/n4a-inspector.css`.
 *
 * Three facts are kept apart everywhere: storage integrity (verified by Core), owner
 * content status (per artifact, as the owner reported it) and execution (never
 * evaluated by inspection). An owner "validated" status covers only the record that owner
 * checked (its detail says what); it is never presented as scientific validity.
 */
import { useEffect, useId, useMemo, useRef, useState, type ReactNode, type RefObject } from "react";

import { DagGraphView } from "../dag/DagGraphView.js";
import type { DagGraph } from "../dag/types.js";
import { Inspector } from "../inspector/Inspector.js";
import type { InspectorViewId } from "../inspector/types.js";
import { SpectraExplorer } from "../qualification/SpectraExplorer.js";
import { N4_CATEGORICAL } from "../viz/theme.js";
import { cx } from "../workbench/_cx.js";
import { Button, EmptyState, IconButton, StatTile } from "../workbench/controls.js";
import { useControllable, useElementSize } from "../workbench/hooks.js";
import { DEFAULT_WORKBENCH_ICONS as ICON } from "../workbench/icons.js";
import { PanelSection } from "../workbench/layout.js";
import { formatN4aBytes, linkedN4aArtifacts, N4A_SECTION_LABELS, N4A_SECTIONS } from "./model.js";
import type {
  N4aArtifactPreview,
  N4aArtifactView,
  N4aContentStatus,
  N4aInspectionView,
  N4aInspectorProps,
  N4aMemberView,
  N4aPreviewState,
  N4aPreviewTable,
  N4aSection,
  N4aSpectraPreview,
} from "./types.js";

type Tone = "ok" | "neutral" | "warning" | "danger";
type ArtifactSection = Exclude<N4aSection, "overview" | "files">;

const ARTIFACT_SECTIONS: readonly ArtifactSection[] = ["data", "pipelines", "results", "models", "other"];
const STATUS_ORDER: readonly N4aContentStatus[] = ["validated", "not_evaluated", "opaque", "unresolved", "refused"];
const EMPTY_PREVIEWS: Readonly<Record<string, N4aPreviewState>> = {};

/** Owner content status wording: what the owner reported, never an execution verdict. */
export const N4A_CONTENT_STATUS_TEXT: Readonly<Record<N4aContentStatus, { label: string; tone: Tone; help: string }>> = {
  validated: {
    label: "Owner-validated record",
    tone: "ok",
    help: "The owner validated the record it reads. This is not an assessment of scientific validity or of execution.",
  },
  not_evaluated: { label: "Not evaluated", tone: "neutral", help: "The owner has not evaluated this content yet." },
  opaque: { label: "Opaque", tone: "neutral", help: "No registered owner can read this content; only its declared storage entry is shown." },
  unresolved: { label: "Unresolved", tone: "warning", help: "The content could not be resolved from this file." },
  refused: { label: "Refused by owner", tone: "danger", help: "The owner refused this content as stored." },
};

// ------------------------------------------------------------------ small helpers

/** Exact decimal bytes first, then the binary approximation when it differs. */
function Bytes({ value }: { value: string }) {
  let human: string | null = null;
  try {
    human = formatN4aBytes(value);
  } catch {
    human = null;
  }
  const exact = `${value} bytes`;
  return (
    <span className="n4ai-bytes">
      <span className="n4wb-mono">{exact}</span>
      {human && human !== exact ? <span className="n4wb-muted"> ({human})</span> : null}
    </span>
  );
}

/** Renders any declared value as text (never as HTML). */
function textOf(value: unknown): string {
  if (value === null) return "null";
  if (value === undefined) return "";
  if (typeof value === "string") return value;
  if (typeof value === "number" || typeof value === "boolean" || typeof value === "bigint") return String(value);
  try {
    return JSON.stringify(value, null, 2) ?? String(value);
  } catch {
    return String(value);
  }
}

function cellText(value: string | number | boolean | null): string {
  return value === null ? "not available" : String(value);
}

function Badge({ tone, children, title }: { tone: Tone; children: ReactNode; title?: string | undefined }) {
  return (
    <span className={cx("n4ai-badge", `is-${tone}`)} title={title}>
      {children}
    </span>
  );
}

function ContentBadge({ status }: { status: N4aContentStatus }) {
  const meta = N4A_CONTENT_STATUS_TEXT[status];
  return (
    <Badge tone={meta.tone} title={meta.help}>
      {meta.label}
    </Badge>
  );
}

function StorageBadge({ storage }: { storage: N4aArtifactView["storage"] }) {
  return storage === "embedded" ? <Badge tone="neutral">Embedded</Badge> : <Badge tone="warning">Reference only</Badge>;
}

function KeyValues({ rows, label }: { rows: ReadonlyArray<readonly [string, ReactNode]>; label?: string | undefined }) {
  return (
    <dl className="n4ai-kv" aria-label={label}>
      {rows.map(([key, value]) => (
        <div key={key} className="n4ai-kv-row">
          <dt>{key}</dt>
          <dd>{value}</dd>
        </div>
      ))}
    </dl>
  );
}

function RecordList({ record, empty, label }: { record: Readonly<Record<string, unknown>>; empty: string; label: string }) {
  const entries = Object.entries(record);
  if (entries.length === 0) return <p className="n4ai-muted-line">{empty}</p>;
  return (
    <KeyValues
      label={label}
      rows={entries.map(([key, value]) => {
        const text = textOf(value);
        return [key, typeof value === "object" && value !== null ? <pre className="n4ai-pre">{text}</pre> : <span className="n4ai-wrap">{text}</span>] as const;
      })}
    />
  );
}

/** Horizontally scrollable, keyboard-focusable table region (long ids/paths wrap). */
function TableRegion({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="n4ai-table-wrap" role="region" aria-label={label} tabIndex={0}>
      {children}
    </div>
  );
}

function SimpleTable({
  caption,
  columns,
  rows,
  empty,
}: {
  caption: string;
  columns: readonly string[];
  rows: ReadonlyArray<ReadonlyArray<ReactNode>>;
  empty?: string | undefined;
}) {
  if (rows.length === 0 && empty) return <p className="n4ai-muted-line">{empty}</p>;
  return (
    <TableRegion label={caption}>
      <table className="n4ai-table">
        <caption>{caption}</caption>
        <thead>
          <tr>
            {columns.map((column, index) => (
              <th key={`${index}-${column}`} scope="col">
                {column}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, i) => (
            <tr key={i}>
              {row.map((cell, j) => (
                <td key={j}>{cell}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </TableRegion>
  );
}

type Navigate = (artifactId: string) => void;

/** Exact-id reference: a navigation button when the id names an artifact of this container. */
function IdRef({ id, known, onNavigate }: { id: string; known: boolean; onNavigate: Navigate }) {
  if (!known) return <code className="n4ai-id">{id}</code>;
  return (
    <button type="button" className="n4ai-id-link" onClick={() => onNavigate(id)} title={`Open artifact ${id}`}>
      <code className="n4ai-id">{id}</code>
    </button>
  );
}

function contentSummary(artifacts: readonly N4aArtifactView[]): string {
  if (artifacts.length === 0) return "no artifacts declared";
  const parts: string[] = [];
  for (const status of STATUS_ORDER) {
    const count = artifacts.filter((artifact) => artifact.contentStatus === status).length;
    if (count > 0) parts.push(`${N4A_CONTENT_STATUS_TEXT[status].label}: ${count}`);
  }
  return parts.join(" · ");
}

function kindSummary(artifacts: readonly N4aArtifactView[]): string {
  if (artifacts.length === 0) return "None";
  const counts = new Map<string, number>();
  for (const artifact of artifacts) counts.set(artifact.kind || "unspecified kind", (counts.get(artifact.kind || "unspecified kind") ?? 0) + 1);
  return [...counts.entries()].map(([kind, count]) => `${kind} ×${count}`).join(", ");
}

function subtitleOf(inspection: N4aInspectionView): string {
  const total = inspection.artifacts.length;
  return `${inspection.schema} · ${total} artifact${total === 1 ? "" : "s"} · ${inspection.embeddedCount} embedded / ${inspection.referenceCount} reference${inspection.referenceCount === 1 ? "" : "s"}`;
}

// ------------------------------------------------------------------ status strip

function StatusFacts({ inspection }: { inspection: N4aInspectionView }) {
  return (
    <ul className="n4ai-facts" aria-label="Inspection status">
      <li className="n4ai-fact">
        <span className="n4wb-dot" aria-hidden="true" />
        <strong>Storage verified</strong>
        <span className="n4wb-muted">integrity of the stored bytes, checked by Core; says nothing about content</span>
      </li>
      <li className="n4ai-fact">
        <span className="n4wb-dot is-idle" aria-hidden="true" />
        <strong>Owner content</strong>
        <span className="n4wb-muted">{contentSummary(inspection.artifacts)}</span>
      </li>
      <li className="n4ai-fact">
        <span className="n4wb-dot is-idle" aria-hidden="true" />
        <strong>Execution not evaluated</strong>
        <span className="n4wb-muted">inspection grants no execution admission</span>
      </li>
    </ul>
  );
}

// ------------------------------------------------------------------ previews

function PreviewTableView({ table }: { table: N4aPreviewTable }) {
  const shown = table.rows.length;
  const total = table.totalRows;
  const count = total !== undefined && total !== shown ? `showing ${shown} of ${total} rows` : `${shown} row${shown === 1 ? "" : "s"}`;
  return (
    <SimpleTable
      caption={`${table.title} · ${count}`}
      columns={table.columns}
      rows={table.rows.map((row) =>
        row.map((cell) => (
          <span className={cx(cell === null && "n4wb-muted", typeof cell === "number" && "n4wb-mono")} data-value={cell === null ? "" : String(cell)}>
            {cellText(cell)}
          </span>
        )),
      )}
    />
  );
}

function isGap(value: number | null | undefined): boolean {
  return value === null || value === undefined || !Number.isFinite(value);
}

function SpectraPreviewView({ spectra }: { spectra: N4aSpectraPreview }) {
  const [selected, setSelected] = useState<string[]>([]);
  const [tableOpen, setTableOpen] = useState(false);
  const [frameRef, frame] = useElementSize<HTMLDivElement>({ width: 900, height: 0 });
  const axisTitle = `${spectra.axisLabel}${spectra.axisUnit ? ` (${spectra.axisUnit})` : ""}`;
  const gaps = spectra.series.map((series) => ({
    series,
    count: spectra.axis.reduce((sum, _, index) => sum + (isGap(series.values[index]) ? 1 : 0), 0),
  }));
  const totalGaps = gaps.reduce((sum, entry) => sum + entry.count, 0);
  const shown = spectra.series.length;
  return (
    <figure className="n4ai-figure">
      <div ref={frameRef}>
      <SpectraExplorer
        title={spectra.title}
        axis={spectra.axis}
        axisUnit={spectra.axisUnit}
        yLabel={spectra.yLabel}
        locale="en"
        width={Math.max(160, frame.width || 900)}
        height={260}
        selected={selected}
        onSelect={(id) => setSelected(id === null ? [] : [id])}
        series={spectra.series.map((series, index) => ({
          id: series.id,
          values: series.values,
          color: N4_CATEGORICAL[index % N4_CATEGORICAL.length]!,
          ...(series.label !== undefined ? { label: series.label } : {}),
        }))}
      />
      </div>
      <figcaption className="n4ai-caption">
        Horizontal axis: {axisTitle}, {spectra.axis.length} position{spectra.axis.length === 1 ? "" : "s"} · {shown} of {spectra.totalSamples} sample
        {spectra.totalSamples === 1 ? "" : "s"} shown · {totalGaps === 0 ? "no masked or missing values" : `${totalGaps} masked or missing value${totalGaps === 1 ? "" : "s"} (drawn as gaps)`}
      </figcaption>
      {totalGaps > 0 ? (
        <SimpleTable
          caption={`${spectra.title} · masked or missing values per series`}
          columns={["Series", "Label", "Gaps"]}
          rows={gaps.filter((entry) => entry.count > 0).map((entry) => [<code className="n4ai-id">{entry.series.id}</code>, entry.series.label ?? "", <span className="n4wb-mono">{entry.count}</span>])}
        />
      ) : null}
      <details className="n4ai-details" onToggle={(event) => setTableOpen(event.currentTarget.open)}>
        <summary>
          Exact values · {spectra.axis.length} positions × {shown} series
        </summary>
        {tableOpen ? (
          <SimpleTable
            caption={`${spectra.title} · exact values (${spectra.yLabel || "signal"})`}
            columns={[axisTitle, ...spectra.series.map((series) => (series.label ? `${series.id} · ${series.label}` : series.id))]}
            rows={spectra.axis.map((coordinate, index) => [
              <span className="n4wb-mono">{String(coordinate)}</span>,
              ...spectra.series.map((series) => {
                const value = series.values[index];
                return isGap(value) ? (
                  <span className="n4wb-muted" data-value="">
                    gap
                  </span>
                ) : (
                  <span className="n4wb-mono" data-value={String(value)}>
                    {String(value)}
                  </span>
                );
              }),
            ])}
          />
        ) : null}
      </details>
    </figure>
  );
}

function GraphPreviewView({ graph, title }: { graph: DagGraph; title: string }) {
  // The DAG view draws at a pixel size: follow the available width so it never clips.
  const [frameRef, frame] = useElementSize<HTMLDivElement>({ width: 960, height: 0 });
  const graphWidth = Math.max(320, frame.width || 960);
  return (
    <figure className="n4ai-figure">
      <div className="n4ai-graph" ref={frameRef}>
        <DagGraphView
          // Refit when the available width changes (the view fits its layout once per mount).
          key={graphWidth}
          graph={graph}
          title={graph.name ?? title}
          width={graphWidth}
          height={460}
        />
      </div>
      <figcaption className="n4ai-caption">
        {graph.nodes.length} node{graph.nodes.length === 1 ? "" : "s"} · {graph.edges.length} edge{graph.edges.length === 1 ? "" : "s"} · stored recipe
        graph; nothing is compiled or executed.
      </figcaption>
      <details className="n4ai-details">
        <summary>Graph as text</summary>
        <SimpleTable
          caption={`${title} · nodes`}
          columns={["Node", "Label", "Kind", "Group"]}
          rows={graph.nodes.map((node) => [<code className="n4ai-id">{node.id}</code>, node.label ?? "", node.kind ?? "", (node.group ?? []).join(" › ")])}
          empty="No nodes."
        />
        <SimpleTable
          caption={`${title} · edges`}
          columns={["Source", "Target", "Kind", "Label"]}
          rows={graph.edges.map((edge) => [<code className="n4ai-id">{edge.source}</code>, <code className="n4ai-id">{edge.target}</code>, edge.kind ?? "", edge.label ?? ""])}
          empty="No edges."
        />
      </details>
    </figure>
  );
}

/** Views that work from owner scores/predictions alone (no UI statistics, no runtime requests). */
export function n4aInspectorViews(inspector: NonNullable<N4aArtifactPreview["inspector"]>): InspectorViewId[] {
  const views: InspectorViewId[] = ["overview", "top", "table", "folds", "hyperparams"];
  const hasPredictions = Object.keys(inspector.predictions ?? {}).length > 0;
  if (hasPredictions && inspector.chains.some((chain) => chain.task === "regression")) views.push("parity", "residuals");
  if (hasPredictions && inspector.chains.some((chain) => chain.task === "classification")) views.push("confusion");
  return views;
}

function InspectorPreviewView({ inspector, title }: { inspector: NonNullable<N4aArtifactPreview["inspector"]>; title: string }) {
  const views = useMemo(() => n4aInspectorViews(inspector), [inspector]);
  return (
    <div className="n4ai-figure">
      <div className="n4ai-capsule">
        <Inspector
          chains={inspector.chains}
          scoreRefs={inspector.scoreRefs}
          predictions={inspector.predictions}
          unavailablePredictions={inspector.unavailablePredictions}
          localStatistics={false}
          availableViews={views}
          locale="en"
          title={title}
        />
      </div>
      <p className="n4ai-caption">Recorded owner scores and predictions only: no metric is recomputed and nothing is refit or predicted.</p>
    </div>
  );
}

function PreviewView({ preview }: { preview: N4aArtifactPreview }) {
  const status = N4A_CONTENT_STATUS_TEXT[preview.status];
  const hasBody = preview.fields.length > 0 || preview.tables.length > 0 || (preview.spectra?.length ?? 0) > 0 || preview.graph !== undefined || preview.inspector !== undefined;
  return (
    <div className="n4ai-preview">
      <div className="n4ai-preview-head">
        <strong className="n4ai-wrap">{preview.title}</strong>
        <Badge tone="neutral">{preview.kind}</Badge>
        <ContentBadge status={preview.status} />
      </div>
      {preview.detail ? <p className="n4ai-text">{preview.detail}</p> : null}
      {status.tone === "warning" || status.tone === "danger" ? (
        <p className={cx("n4wb-note", status.tone === "danger" ? "is-error" : "is-warning")}>
          {status.label}: {status.help} Values below, if any, are not a validation.
        </p>
      ) : null}
      {preview.fields.length > 0 ? <KeyValues label={`${preview.title} fields`} rows={preview.fields.map((field) => [field.label, <span className="n4ai-wrap">{field.value}</span>] as const)} /> : null}
      {preview.tables.map((table, index) => (
        <PreviewTableView key={`${index}-${table.title}`} table={table} />
      ))}
      {(preview.spectra ?? []).map((spectra, index) => (
        <SpectraPreviewView key={`${index}-${spectra.title}`} spectra={spectra} />
      ))}
      {preview.graph ? <GraphPreviewView graph={preview.graph} title={preview.title} /> : null}
      {preview.inspector ? <InspectorPreviewView inspector={preview.inspector} title={preview.title} /> : null}
      {!hasBody ? <p className="n4ai-muted-line">The owner returned no previewable fields, tables, spectra or graph for this artifact.</p> : null}
      <p className="n4ai-caption">Report only: a preview neither admits this artifact for execution nor assesses its scientific validity.</p>
    </div>
  );
}

/** Why no local preview can be requested, or null when a preview may be requested. */
export function n4aPreviewUnavailableReason(artifact: N4aArtifactView): string | null {
  if (artifact.storage === "reference") return "No local preview: this artifact is a reference, so its content is not stored in this file. Nothing is downloaded.";
  if (artifact.contentStatus === "opaque") return `No preview: owner "${artifact.owner}" is not registered with this reader, so the content stays opaque.`;
  if (artifact.contentStatus === "refused") return "No preview: the owner refused this content.";
  if (artifact.contentStatus === "unresolved") return "No preview: the content could not be resolved from this file.";
  return null;
}

function PreviewPanel({
  artifact,
  state,
  onRequestPreview,
}: {
  artifact: N4aArtifactView;
  state: N4aPreviewState | undefined;
  onRequestPreview?: ((artifactId: string) => void) | undefined;
}) {
  const reason = n4aPreviewUnavailableReason(artifact);
  if (reason) {
    return (
      <div className="n4ai-preview-slot">
        <p className="n4wb-note">{reason}</p>
        {artifact.contentDetail ? <p className="n4ai-text">{artifact.contentDetail}</p> : null}
      </div>
    );
  }
  if (!state) {
    return (
      <div className="n4ai-preview-slot">
        {onRequestPreview ? (
          <>
            <Button variant="outline" icon={ICON.eye} onClick={() => onRequestPreview(artifact.id)}>
              Load preview
            </Button>
            <p className="n4ai-caption">The owner reads this artifact only when you ask. Nothing is executed.</p>
          </>
        ) : (
          <p className="n4ai-muted-line">This host does not provide content previews.</p>
        )}
      </div>
    );
  }
  if (state.status === "loading") {
    return (
      <div className="n4ai-preview-slot">
        <p className="n4ai-loading" role="status">
          <span className="n4wb-view-busy" aria-hidden="true" />
          Loading preview…
        </p>
      </div>
    );
  }
  if (state.status === "error") {
    return (
      <div className="n4ai-preview-slot">
        <p className="n4wb-note is-error" role="alert">
          Preview failed: {state.message}
        </p>
        {onRequestPreview ? (
          <Button variant="outline" icon={ICON.reset} onClick={() => onRequestPreview(artifact.id)}>
            Retry preview
          </Button>
        ) : null}
      </div>
    );
  }
  if (state.preview.artifactId !== artifact.id) {
    return (
      <div className="n4ai-preview-slot">
        <p className="n4wb-note is-error" role="alert">
          Preview refused: it describes artifact <code className="n4ai-id">{state.preview.artifactId}</code>, not the selected artifact.
        </p>
      </div>
    );
  }
  return <PreviewView preview={state.preview} />;
}

// ------------------------------------------------------------------ artifact detail

function ArtifactDetail({
  artifact,
  inspection,
  known,
  members,
  state,
  onRequestPreview,
  onNavigate,
  headingRef,
}: {
  artifact: N4aArtifactView;
  inspection: N4aInspectionView;
  known: (id: string) => boolean;
  members: ReadonlyMap<string, N4aMemberView>;
  state: N4aPreviewState | undefined;
  onRequestPreview?: ((artifactId: string) => void) | undefined;
  onNavigate: Navigate;
  headingRef: RefObject<HTMLHeadingElement | null>;
}) {
  const headingId = useId();
  const content = N4A_CONTENT_STATUS_TEXT[artifact.contentStatus];
  const links = linkedN4aArtifacts(inspection, artifact.id);
  const entrypoints = inspection.entrypoints.filter((entry) => entry.rootArtifact === artifact.id || entry.inputArtifacts.includes(artifact.id));
  const requiredBy = inspection.artifacts.filter((other) => other.requirements === artifact.id);
  const ref = (id: string) => <IdRef id={id} known={known(id)} onNavigate={onNavigate} />;
  const relationCount = links.length + entrypoints.length + requiredBy.length + (artifact.requirements ? 1 : 0);
  return (
    <article className="n4ai-detail" aria-labelledby={headingId}>
      <header className="n4ai-detail-head">
        <span className="n4ai-eyebrow">
          {artifact.kind || "unspecified kind"} · {artifact.owner || "no owner"}
        </span>
        <h3 id={headingId} ref={headingRef} tabIndex={-1} className="n4ai-detail-title">
          <code className="n4ai-id">{artifact.id}</code>
        </h3>
        <span className="n4ai-badges">
          <StorageBadge storage={artifact.storage} />
          <ContentBadge status={artifact.contentStatus} />
        </span>
      </header>

      <dl className="n4ai-status-list" aria-label="Artifact status">
        <div className={cx("n4ai-status-row", artifact.storage === "embedded" ? "is-ok" : "is-warning")}>
          <dt>Storage</dt>
          <dd>
            {artifact.storage === "embedded"
              ? "Embedded in this file; container storage verified by Core (bytes only, not content)."
              : "Reference only: declared here, content not stored in this file."}
          </dd>
        </div>
        <div className={cx("n4ai-status-row", `is-${content.tone}`)}>
          <dt>Owner content</dt>
          <dd>
            {content.label}. {artifact.contentDetail ?? content.help}
            {artifact.contentStatus === "validated" && artifact.contentDetail ? ` ${content.help}` : null}
          </dd>
        </div>
        <div className="n4ai-status-row is-neutral">
          <dt>Execution</dt>
          <dd>Not evaluated. Inspection grants no execution admission.</dd>
        </div>
      </dl>

      <h4 className="n4ai-h4">Declaration</h4>
      <KeyValues
        label="Artifact declaration"
        rows={[
          ["Kind", artifact.kind || "—"],
          ["Owner", <span className="n4ai-wrap">{artifact.owner || "—"}</span>],
          ["Content type", <span className="n4ai-wrap n4wb-mono">{`${artifact.contentType} @${artifact.contentVersion}`}</span>],
          ["Storage", artifact.storage === "embedded" ? "Embedded" : "Reference"],
          ["Root member", artifact.rootMember ? <code className="n4ai-id">{artifact.rootMember}</code> : "—"],
          ["Size", <Bytes value={artifact.byteLength} />],
          ["Root SHA-256", artifact.rootSha256 ? <code className="n4ai-hash">{artifact.rootSha256}</code> : "—"],
          ["Requirements", artifact.requirements ? ref(artifact.requirements) : "None declared"],
        ]}
      />

      <h4 className="n4ai-h4">Identity</h4>
      <RecordList record={artifact.identity} empty="No identity fields declared." label="Artifact identity" />

      <h4 className="n4ai-h4">
        Members <span className="n4wb-count">{artifact.memberPaths.length}</span>
      </h4>
      <SimpleTable
        caption={`Members of ${artifact.id}`}
        columns={["Path", "Size", "SHA-256"]}
        empty={artifact.storage === "reference" ? "No members: references store no bytes in this file." : "No members declared."}
        rows={artifact.memberPaths.map((path) => {
          const member = members.get(path);
          return [
            <code className="n4ai-id">{path}</code>,
            member ? <Bytes value={member.byteLength} /> : <span className="n4wb-muted">not in inventory</span>,
            member ? <code className="n4ai-hash">{member.sha256}</code> : "—",
          ];
        })}
      />

      <h4 className="n4ai-h4">
        Relationships <span className="n4wb-count">{relationCount}</span>
      </h4>
      {relationCount === 0 ? <p className="n4ai-muted-line">No link, requirement or entrypoint refers to this artifact.</p> : null}
      {links.length > 0 ? (
        <SimpleTable
          caption={`Links of ${artifact.id}`}
          columns={["Relation", "Source", "Target", "Owner"]}
          rows={links.map((link) => [link.relation, ref(link.source), ref(link.target), <span className="n4ai-wrap">{link.owner}</span>])}
        />
      ) : null}
      {requiredBy.length > 0 ? (
        <SimpleTable caption={`Artifacts requiring ${artifact.id}`} columns={["Artifact", "Kind"]} rows={requiredBy.map((other) => [ref(other.id), other.kind])} />
      ) : null}
      {entrypoints.length > 0 ? (
        <SimpleTable
          caption={`Entrypoints using ${artifact.id}`}
          columns={["Entrypoint", "Operation", "Role"]}
          rows={entrypoints.map((entry) => [<code className="n4ai-id">{entry.id}</code>, entry.operation, entry.rootArtifact === artifact.id ? "root" : "input"])}
        />
      ) : null}

      <h4 className="n4ai-h4">Preview</h4>
      <PreviewPanel artifact={artifact} state={state} onRequestPreview={onRequestPreview} />
    </article>
  );
}

// ------------------------------------------------------------------ explorer sections

function SectionHeading({ id, title, count }: { id: string; title: string; count?: number | undefined }) {
  return (
    <h2 id={id} className="n4ai-h2">
      {title}
      {count !== undefined ? <span className="n4wb-count">{count}</span> : null}
    </h2>
  );
}

function OverviewSection({
  inspection,
  known,
  onSection,
  onNavigate,
}: {
  inspection: N4aInspectionView;
  known: (id: string) => boolean;
  onSection: (section: N4aSection) => void;
  onNavigate: Navigate;
}) {
  const headingId = useId();
  const attention = inspection.artifacts.filter((artifact) => artifact.contentStatus === "refused" || artifact.contentStatus === "unresolved" || artifact.contentStatus === "opaque");
  const ref = (id: string) => <IdRef id={id} known={known(id)} onNavigate={onNavigate} />;
  return (
    <section className="n4ai-section" aria-labelledby={headingId}>
      <SectionHeading id={headingId} title={N4A_SECTION_LABELS.overview} />
      <div className="n4wb-stats n4ai-stats">
        <StatTile label="Artifacts" value={inspection.artifacts.length} />
        <StatTile label="Embedded" value={inspection.embeddedCount} />
        <StatTile label="References" value={inspection.referenceCount} />
        <StatTile label="Members" value={inspection.members.length} />
        <StatTile label="Links" value={inspection.links.length} />
        <StatTile label="Entrypoints" value={inspection.entrypoints.length} />
      </div>

      <h3 className="n4ai-h3">Contents</h3>
      <ul className="n4ai-cards" aria-label="Contents by section">
        {ARTIFACT_SECTIONS.map((section) => {
          const artifacts = inspection.artifacts.filter((artifact) => artifact.section === section);
          return (
            <li key={section}>
              <button type="button" className="n4ai-card" onClick={() => onSection(section)}>
                <span className="n4wb-stat-label">{N4A_SECTION_LABELS[section]}</span>
                <strong className="n4wb-stat-value">{inspection.counts[section]}</strong>
                <span className="n4ai-card-hint">{kindSummary(artifacts)}</span>
              </button>
            </li>
          );
        })}
        <li>
          <button type="button" className="n4ai-card" onClick={() => onSection("files")}>
            <span className="n4wb-stat-label">{N4A_SECTION_LABELS.files}</span>
            <strong className="n4wb-stat-value">{inspection.counts.files}</strong>
            <span className="n4ai-card-hint">members, hashes and manifest</span>
          </button>
        </li>
      </ul>

      <h3 className="n4ai-h3">Container</h3>
      <KeyValues
        label="Container identity"
        rows={[
          ["File", <span className="n4ai-wrap">{inspection.fileName}</span>],
          ["Size", <Bytes value={inspection.byteLength} />],
          ["Container ID", <code className="n4ai-id">{inspection.containerId}</code>],
          ["Schema", <span className="n4ai-wrap n4wb-mono">{`${inspection.schema} · schema version ${inspection.schemaVersion}`}</span>],
          ["Physical profile", <span className="n4ai-wrap n4wb-mono">{inspection.physicalProfile}</span>],
          ["Required features", inspection.requiredFeatures.length ? <FeatureList features={inspection.requiredFeatures} /> : "None declared"],
        ]}
      />

      <h3 className="n4ai-h3">
        Entrypoints <span className="n4wb-count">{inspection.entrypoints.length}</span>
      </h3>
      <SimpleTable
        caption="Declared entrypoints"
        columns={["Entrypoint", "Operation", "Root artifact", "Inputs", "Required features"]}
        empty="No entrypoints declared."
        rows={inspection.entrypoints.map((entry) => [
          <code className="n4ai-id">{entry.id}</code>,
          entry.operation,
          ref(entry.rootArtifact),
          entry.inputArtifacts.length ? <span className="n4ai-refs">{entry.inputArtifacts.map((id, index) => <span key={`${index}-${id}`}>{ref(id)}</span>)}</span> : "—",
          entry.requiredFeatures.length ? <FeatureList features={entry.requiredFeatures} /> : "—",
        ])}
      />
      <p className="n4ai-caption">Entrypoints are declarations; whether they can run is not evaluated here.</p>

      {attention.length > 0 ? (
        <>
          <h3 className="n4ai-h3">
            Not readable locally <span className="n4wb-count">{attention.length}</span>
          </h3>
          <SimpleTable
            caption="Artifacts without a local owner reading"
            columns={["Artifact", "Storage", "Owner content", "Detail"]}
            rows={attention.map((artifact) => [
              ref(artifact.id),
              <StorageBadge storage={artifact.storage} />,
              <ContentBadge status={artifact.contentStatus} />,
              <span className="n4ai-wrap">{artifact.contentDetail ?? N4A_CONTENT_STATUS_TEXT[artifact.contentStatus].help}</span>,
            ])}
          />
        </>
      ) : null}
    </section>
  );
}

function FeatureList({ features }: { features: readonly string[] }) {
  return (
    <span className="n4ai-features">
      {features.map((feature) => (
        <code key={feature} className="n4ai-feature">
          {feature}
        </code>
      ))}
    </span>
  );
}

function ArtifactSectionView({
  section,
  inspection,
  activeId,
  onSelect,
  children,
}: {
  section: ArtifactSection;
  inspection: N4aInspectionView;
  activeId: string | null;
  onSelect: (id: string) => void;
  children: ReactNode;
}) {
  const headingId = useId();
  const label = N4A_SECTION_LABELS[section];
  const artifacts = inspection.artifacts.filter((artifact) => artifact.section === section);
  return (
    <section className="n4ai-section" aria-labelledby={headingId}>
      <SectionHeading id={headingId} title={label} count={artifacts.length} />
      {artifacts.length === 0 ? (
        <EmptyState title={`No ${label.toLowerCase()} artifacts`} icon={ICON.layers}>
          This container declares no artifact in this section.
        </EmptyState>
      ) : (
        <div className="n4ai-split">
          <ul className="n4ai-artifacts" aria-label={`${label} artifacts`}>
            {artifacts.map((artifact) => (
              <li key={artifact.id}>
                <button
                  type="button"
                  className={cx("n4ai-artifact", artifact.id === activeId && "is-active")}
                  aria-current={artifact.id === activeId ? "true" : undefined}
                  onClick={() => onSelect(artifact.id)}
                >
                  <code className="n4ai-id">{artifact.id}</code>
                  <span className="n4ai-artifact-meta">
                    {artifact.kind || "unspecified kind"} · {artifact.owner || "no owner"}
                  </span>
                  <span className="n4ai-badges">
                    <StorageBadge storage={artifact.storage} />
                    <ContentBadge status={artifact.contentStatus} />
                  </span>
                </button>
              </li>
            ))}
          </ul>
          <div className="n4ai-split-detail">{children}</div>
        </div>
      )}
    </section>
  );
}

function FilesSection({ inspection, known, onNavigate }: { inspection: N4aInspectionView; known: (id: string) => boolean; onNavigate: Navigate }) {
  const headingId = useId();
  const ref = (id: string) => <IdRef id={id} known={known(id)} onNavigate={onNavigate} />;
  return (
    <section className="n4ai-section" aria-labelledby={headingId}>
      <SectionHeading id={headingId} title={N4A_SECTION_LABELS.files} />
      <h3 className="n4ai-h3">Container</h3>
      <KeyValues
        label="Container metadata"
        rows={[
          ["File", <span className="n4ai-wrap">{inspection.fileName}</span>],
          ["Size", <Bytes value={inspection.byteLength} />],
          ["Container ID", <code className="n4ai-id">{inspection.containerId}</code>],
          ["Schema", <span className="n4ai-wrap n4wb-mono">{inspection.schema}</span>],
          ["Schema version", <span className="n4wb-mono">{inspection.schemaVersion}</span>],
          ["Minimum reader version", <span className="n4wb-mono">{inspection.minimumReaderVersion}</span>],
          ["Physical profile", <span className="n4ai-wrap n4wb-mono">{inspection.physicalProfile}</span>],
          ["Container SHA-256", <code className="n4ai-hash">{inspection.containerSha256}</code>],
          ["Manifest SHA-256", <code className="n4ai-hash">{inspection.manifestSha256}</code>],
          ["Storage", "Verified by Core"],
          ["Execution", "Not evaluated"],
          ["Required features", inspection.requiredFeatures.length ? <FeatureList features={inspection.requiredFeatures} /> : "None declared"],
        ]}
      />

      <h3 className="n4ai-h3">
        Artifacts <span className="n4wb-count">{inspection.artifacts.length}</span>
      </h3>
      <SimpleTable
        caption="All declared artifacts"
        columns={["Artifact", "Kind", "Owner", "Content type", "Storage", "Size", "Root SHA-256", "Owner content", "Requirements"]}
        empty="No artifacts declared."
        rows={inspection.artifacts.map((artifact) => [
          ref(artifact.id),
          artifact.kind,
          <span className="n4ai-wrap">{artifact.owner}</span>,
          <span className="n4ai-wrap n4wb-mono">{`${artifact.contentType} @${artifact.contentVersion}`}</span>,
          artifact.storage === "embedded" ? "Embedded" : "Reference",
          <Bytes value={artifact.byteLength} />,
          artifact.rootSha256 ? <code className="n4ai-hash">{artifact.rootSha256}</code> : "—",
          <ContentBadge status={artifact.contentStatus} />,
          artifact.requirements ? ref(artifact.requirements) : "—",
        ])}
      />

      <h3 className="n4ai-h3">
        Members <span className="n4wb-count">{inspection.members.length}</span>
      </h3>
      <SimpleTable
        caption="All container members"
        columns={["Path", "Size", "SHA-256"]}
        empty="No members."
        rows={inspection.members.map((member) => [<code className="n4ai-id">{member.path}</code>, <Bytes value={member.byteLength} />, <code className="n4ai-hash">{member.sha256}</code>])}
      />

      <h3 className="n4ai-h3">
        Links <span className="n4wb-count">{inspection.links.length}</span>
      </h3>
      <SimpleTable
        caption="All declared links"
        columns={["Link", "Relation", "Source", "Target", "Owner"]}
        empty="No links declared."
        rows={inspection.links.map((link) => [<code className="n4ai-id">{link.id}</code>, link.relation, ref(link.source), ref(link.target), <span className="n4ai-wrap">{link.owner}</span>])}
      />

      <h3 className="n4ai-h3">
        Entrypoints <span className="n4wb-count">{inspection.entrypoints.length}</span>
      </h3>
      <SimpleTable
        caption="All declared entrypoints"
        columns={["Entrypoint", "Owner", "Operation", "Root artifact", "Inputs", "Required features", "Requirements"]}
        empty="No entrypoints declared."
        rows={inspection.entrypoints.map((entry) => [
          <code className="n4ai-id">{entry.id}</code>,
          <span className="n4ai-wrap">{entry.owner}</span>,
          entry.operation,
          ref(entry.rootArtifact),
          entry.inputArtifacts.length ? <span className="n4ai-refs">{entry.inputArtifacts.map((id, index) => <span key={`${index}-${id}`}>{ref(id)}</span>)}</span> : "—",
          entry.requiredFeatures.length ? <FeatureList features={entry.requiredFeatures} /> : "—",
          entry.requirements ? ref(entry.requirements) : "—",
        ])}
      />

      <h3 className="n4ai-h3">Semantics</h3>
      <RecordList record={inspection.semantics} empty="No semantics reported." label="Container semantics" />
      <h3 className="n4ai-h3">Training view</h3>
      <RecordList record={inspection.trainingView} empty="No training view reported." label="Training view" />

      <details className="n4ai-details">
        <summary>Original manifest text</summary>
        <pre className="n4ai-pre n4ai-manifest" tabIndex={0} aria-label="Original manifest text">
          {inspection.manifestText}
        </pre>
      </details>
    </section>
  );
}

// ------------------------------------------------------------------ chrome

function Header({
  inspection,
  sourceSlot,
  headerActions,
  onExportReport,
  onClose,
}: {
  inspection: N4aInspectionView | null;
  sourceSlot?: ReactNode;
  headerActions?: ReactNode;
  onExportReport?: (() => void) | undefined;
  onClose?: (() => void) | undefined;
}) {
  return (
    <header className="n4wb-header n4ai-header">
      <div className="n4wb-brand n4ai-brand">
        <span className="n4wb-brand-mark" aria-hidden="true">
          {ICON.cube}
        </span>
        <span className="n4wb-brand-title">
          <strong>{inspection ? inspection.fileName : "N4A Inspector"}</strong>
          <span>{inspection ? subtitleOf(inspection) : "Read-only inspection of .n4a containers"}</span>
        </span>
      </div>
      <span className="n4wb-header-grow" />
      <div className="n4wb-header-group">
        {inspection ? sourceSlot : null}
        {headerActions}
        {inspection && onExportReport ? (
          <Button variant="outline" icon={ICON.download} onClick={onExportReport}>
            Export report
          </Button>
        ) : null}
        {onClose ? (
          <IconButton label="Close inspector" onClick={onClose}>
            {ICON.close}
          </IconButton>
        ) : null}
      </div>
    </header>
  );
}

function phaseMessage(phase: NonNullable<N4aInspectorProps["phase"]>, inspection: N4aInspectionView | null): string {
  if (phase === "opening") return "Opening the container and verifying its storage…";
  if (phase === "error") return "";
  if (inspection) return `${inspection.fileName} open: storage verified, execution not evaluated.`;
  return "No container open.";
}

function NoInspection({ phase, sourceSlot }: { phase: NonNullable<N4aInspectorProps["phase"]>; sourceSlot: ReactNode }) {
  if (phase === "opening") {
    return (
      <div className="n4ai-empty">
        <EmptyState title="Opening container…" icon={<span className="n4wb-view-busy" aria-hidden="true" />}>
          Core is verifying the container storage. Nothing is executed.
        </EmptyState>
      </div>
    );
  }
  return (
    <div className="n4ai-empty">
      <EmptyState title="Open a .n4a container" icon={ICON.cube} action={sourceSlot ? <div className="n4ai-source">{sourceSlot}</div> : undefined}>
        Inspection is read-only: Core verifies storage integrity, owners report on their content on request, and nothing is executed. External
        references are listed without being downloaded.
      </EmptyState>
    </div>
  );
}

// ------------------------------------------------------------------ variants

function useInspectorState(props: N4aInspectorProps, inspection: N4aInspectionView) {
  const [section, setSection] = useControllable<N4aSection>(props.section, "overview", props.onSectionChange);
  const onSelectArtifact = props.onSelectArtifact;
  const [selected, setSelected] = useControllable<string | null>(
    props.selectedArtifactId,
    null,
    onSelectArtifact
      ? (id) => {
          if (id !== null) onSelectArtifact(id);
        }
      : undefined,
  );
  const byId = useMemo(() => new Map(inspection.artifacts.map((artifact) => [artifact.id, artifact])), [inspection]);
  const members = useMemo(() => new Map(inspection.members.map((member) => [member.path, member])), [inspection]);
  const known = (id: string) => byId.has(id);
  return { section, setSection, selected, setSelected, byId, members, known };
}

function ExplorerBody(props: N4aInspectorProps & { inspection: N4aInspectionView }) {
  const { inspection, previews = EMPTY_PREVIEWS, onRequestPreview } = props;
  const { section, setSection, selected, setSelected, byId, members, known } = useInspectorState(props, inspection);
  const headingRef = useRef<HTMLHeadingElement | null>(null);
  const [focusToken, setFocusToken] = useState(0);
  useEffect(() => {
    if (focusToken > 0) headingRef.current?.focus();
  }, [focusToken]);

  const navigate: Navigate = (id) => {
    const artifact = byId.get(id);
    if (!artifact) return;
    setSection(artifact.section);
    setSelected(id);
    setFocusToken((token) => token + 1);
  };

  const artifactSection = (ARTIFACT_SECTIONS as readonly N4aSection[]).includes(section) ? (section as ArtifactSection) : null;
  const inSection = artifactSection ? inspection.artifacts.filter((artifact) => artifact.section === artifactSection) : [];
  const chosen = selected !== null ? byId.get(selected) : undefined;
  const active = chosen && chosen.section === artifactSection ? chosen : inSection[0];
  const activeState = active ? previews[active.id] : undefined;
  const previewMessage =
    active && activeState
      ? activeState.status === "loading"
        ? `Loading preview of ${active.id}.`
        : activeState.status === "ready"
          ? `Preview of ${active.id} ready.`
          : `Preview of ${active.id} failed.`
      : "";

  return (
    <div className="n4ai-body">
      <nav className="n4ai-nav" aria-label="Container sections">
        <ul>
          {N4A_SECTIONS.map((id) => (
            <li key={id}>
              <button
                type="button"
                className={cx("n4ai-nav-item", section === id && "is-active")}
                aria-current={section === id ? "page" : undefined}
                onClick={() => setSection(id)}
              >
                <span>{N4A_SECTION_LABELS[id]}</span>
                {id !== "overview" ? <span className="n4wb-count">{inspection.counts[id]}</span> : null}
              </button>
            </li>
          ))}
        </ul>
      </nav>
      <div className="n4ai-main">
        {section === "overview" ? <OverviewSection inspection={inspection} known={known} onSection={setSection} onNavigate={navigate} /> : null}
        {section === "files" ? <FilesSection inspection={inspection} known={known} onNavigate={navigate} /> : null}
        {artifactSection ? (
          <ArtifactSectionView section={artifactSection} inspection={inspection} activeId={active?.id ?? null} onSelect={setSelected}>
            {active ? (
              <ArtifactDetail
                key={active.id}
                artifact={active}
                inspection={inspection}
                known={known}
                members={members}
                state={activeState}
                onRequestPreview={onRequestPreview}
                onNavigate={navigate}
                headingRef={headingRef}
              />
            ) : null}
          </ArtifactSectionView>
        ) : null}
        <p className="n4wb-sr" role="status">
          {previewMessage}
        </p>
      </div>
    </div>
  );
}

function CompactBody(props: N4aInspectorProps & { inspection: N4aInspectionView }) {
  const { inspection, onSelectArtifact } = props;
  return (
    <div className="n4ai-compact-body">
      <ul className="n4ai-chips" aria-label="Contents">
        {ARTIFACT_SECTIONS.map((section) => (
          <li key={section} className="n4ai-chip">
            <span>{N4A_SECTION_LABELS[section]}</span> <span className="n4wb-count">{inspection.counts[section]}</span>
          </li>
        ))}
        <li className="n4ai-chip">
          <span>Members</span> <span className="n4wb-count">{inspection.counts.files}</span>
        </li>
      </ul>
      <p className="n4ai-caption">
        {inspection.embeddedCount} embedded artifact{inspection.embeddedCount === 1 ? "" : "s"} · {inspection.referenceCount} reference
        {inspection.referenceCount === 1 ? "" : "s"} (not stored in this file) · <Bytes value={inspection.byteLength} />
      </p>
      {ARTIFACT_SECTIONS.filter((section) => inspection.counts[section] > 0).map((section) => (
        <PanelSection key={section} title={N4A_SECTION_LABELS[section]} count={inspection.counts[section]} defaultOpen={false}>
          <ul className="n4ai-compact-list">
            {inspection.artifacts
              .filter((artifact) => artifact.section === section)
              .map((artifact) => {
                const body = (
                  <>
                    <code className="n4ai-id">{artifact.id}</code>
                    <span className="n4ai-artifact-meta">
                      {artifact.kind || "unspecified kind"} · {artifact.owner || "no owner"}
                    </span>
                    <span className="n4ai-badges">
                      <StorageBadge storage={artifact.storage} />
                      <ContentBadge status={artifact.contentStatus} />
                    </span>
                  </>
                );
                return (
                  <li key={artifact.id}>
                    {onSelectArtifact ? (
                      <button type="button" className="n4ai-artifact" onClick={() => onSelectArtifact(artifact.id)}>
                        {body}
                      </button>
                    ) : (
                      <div className="n4ai-artifact is-static">{body}</div>
                    )}
                  </li>
                );
              })}
          </ul>
        </PanelSection>
      ))}
      <PanelSection title="Technical identity" defaultOpen={false}>
        <KeyValues
          label="Technical identity"
          rows={[
            ["Container ID", <code className="n4ai-id">{inspection.containerId}</code>],
            ["Schema", <span className="n4ai-wrap n4wb-mono">{`${inspection.schema} · schema version ${inspection.schemaVersion}`}</span>],
            ["Minimum reader version", <span className="n4wb-mono">{inspection.minimumReaderVersion}</span>],
            ["Physical profile", <span className="n4ai-wrap n4wb-mono">{inspection.physicalProfile}</span>],
            ["Container SHA-256", <code className="n4ai-hash">{inspection.containerSha256}</code>],
            ["Manifest SHA-256", <code className="n4ai-hash">{inspection.manifestSha256}</code>],
            ["Required features", inspection.requiredFeatures.length ? <FeatureList features={inspection.requiredFeatures} /> : "None declared"],
          ]}
        />
      </PanelSection>
    </div>
  );
}

/**
 * Read-only `.n4a` container inspector (explorer or compact card). Fully
 * presentational: the host supplies the verified inspection, previews on request,
 * the file chooser (`sourceSlot`) and every action.
 */
export function N4aInspector(props: N4aInspectorProps) {
  const { inspection = null, error = null, sourceSlot, headerActions, variant = "explorer", onClose, onExportReport, className } = props;
  const phase = props.phase ?? (inspection ? "ready" : "idle");
  const live = phaseMessage(phase, inspection);
  // A new container resets uncontrolled section/selection state.
  const containerKey = inspection ? `${inspection.containerSha256}:${inspection.fileName}` : "none";
  return (
    <div className={cx("n4wb", "n4ai", `n4ai-${variant}`, className)} role="region" aria-label={inspection ? `N4A Inspector: ${inspection.fileName}` : "N4A Inspector"}>
      <Header inspection={inspection} sourceSlot={sourceSlot} headerActions={headerActions} onExportReport={onExportReport} onClose={onClose} />
      {inspection ? <StatusFacts inspection={inspection} /> : null}
      {phase === "error" ? (
        <p className="n4wb-note is-error n4ai-alert" role="alert">
          Could not open the container: {error ?? "unknown error"}
        </p>
      ) : null}
      {phase === "opening" && inspection ? (
        <p className="n4ai-loading n4ai-alert">
          <span className="n4wb-view-busy" aria-hidden="true" />
          Opening another container…
        </p>
      ) : null}
      {!inspection ? (
        <NoInspection phase={phase} sourceSlot={sourceSlot} />
      ) : variant === "compact" ? (
        <CompactBody key={containerKey} {...props} inspection={inspection} />
      ) : (
        <ExplorerBody key={containerKey} {...props} inspection={inspection} />
      )}
      <p className="n4wb-sr" role="status">
        {live}
      </p>
    </div>
  );
}
