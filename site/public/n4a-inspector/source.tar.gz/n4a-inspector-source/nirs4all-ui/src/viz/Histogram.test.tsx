import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";

import { Histogram } from "./Histogram.js";

describe("Histogram", () => {
  it("uses the same finite nonnegative category counts for descriptions and marks", () => {
    const markup = renderToStaticMarkup(<Histogram variant="classification" bins={[
      { label: "unknown", count: NaN }, { label: "invalid", count: -1 },
      { label: "known", count: 2 }, { label: "zero", count: 0 },
    ]} />);
    expect(markup).toContain("2 categories; 2 observations; known: 2; zero: 0");
    expect(markup.match(/class="n4viz-bar"/g)).toHaveLength(2);
    expect(markup).not.toMatch(/unknown|invalid|NaN|Infinity/);
  });

  it("renders a regression distribution from raw values with a mean line", () => {
    const markup = renderToStaticMarkup(
      <Histogram
        values={[0.1, 0.2, 0.2, 0.3, 0.35, 0.4, 0.5, 0.55, 0.6, 0.8]}
        binCount={6}
        meanLine
        xLabel="Protein (%)"
        title="Target distribution"
      />,
    );

    expect(markup).toContain("<svg");
    expect(markup).toContain("n4viz-histogram");
    expect(markup).toContain("<title>Target distribution</title>");
    expect(markup).toContain("n4viz-bar");
    expect(markup).toContain("n4viz-mean");
    expect(markup).toContain("Count");
    expect(markup).toContain("10 numeric observations; range 0.1 to 0.8; mean 0.4.");
  });

  it("renders precomputed classification bins with category labels", () => {
    const markup = renderToStaticMarkup(
      <Histogram
        variant="classification"
        bins={[
          { label: "healthy", count: 12 },
          { label: "stressed", count: 7 },
        ]}
      />,
    );

    expect(markup).toContain("<svg");
    expect(markup).toContain("n4viz-bar");
    expect(markup).toContain("healthy");
    expect(markup).toContain("stressed");
    expect(markup).toContain("2 categories; 19 observations; healthy: 12; stressed: 7.");
  });

  it("renders an empty svg gracefully when no data is provided", () => {
    const markup = renderToStaticMarkup(<Histogram />);
    expect(markup).toContain("<svg");
    expect(markup).toContain("n4viz-histogram");
    expect(markup).toContain("No finite numeric observations.");
  });
});
