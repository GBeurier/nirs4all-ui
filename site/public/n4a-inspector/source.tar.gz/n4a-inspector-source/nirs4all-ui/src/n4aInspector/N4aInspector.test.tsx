import { renderToStaticMarkup } from "react-dom/server";
import { beforeEach, describe, expect, it, vi } from "vitest";

import type { InspectorProps } from "../inspector/Inspector.js";
import { N4aArtifactPreviewView, N4aInspector, n4aInspectorViews, n4aPreviewUnavailableReason } from "./N4aInspector.js";
import type { N4aArtifactPreview, N4aArtifactView, N4aInspectionView, N4aInspectorProps } from "./types.js";

// The embedded trained-chain Inspector is observed, not re-tested here.
const seen = vi.hoisted(() => ({ inspector: [] as InspectorProps[] }));
vi.mock("../inspector/Inspector.js", async (importOriginal) => ({
  ...(await importOriginal<typeof import("../inspector/Inspector.js")>()),
  Inspector: (props: InspectorProps) => {
    seen.inspector.push(props);
    return <div className="mock-inspector" />;
  },
}));

const LONG_ID = `dataset:${"very-long-identifier-segment-".repeat(6)}end`;
const HUGE = "18446744073709551615";

function artifact(overrides: Partial<N4aArtifactView> & Pick<N4aArtifactView, "id" | "kind" | "section">): N4aArtifactView {
  return {
    owner: "nirs4all-io",
    contentType: "nirs4all.dataset",
    contentVersion: 1,
    identity: { name: "Wheat NIR", samples: 240 },
    storage: "embedded",
    rootMember: `artifacts/${overrides.id}/root.json`,
    memberPaths: [`artifacts/${overrides.id}/root.json`],
    byteLength: "2048",
    rootSha256: "a".repeat(64),
    requirements: null,
    contentStatus: "validated",
    contentDetail: null,
    ...overrides,
  };
}

const ARTIFACTS: N4aArtifactView[] = [
  artifact({ id: LONG_ID, kind: "dataset", section: "data", byteLength: HUGE, memberPaths: ["artifacts/wheat/root.json"], rootMember: "artifacts/wheat/root.json" }),
  artifact({ id: "data:harvest-2025", kind: "dataset", section: "data", storage: "reference", rootMember: null, memberPaths: [], byteLength: "0", rootSha256: null, contentStatus: "unresolved" }),
  artifact({ id: "recipe:pls", kind: "recipe", section: "pipelines", owner: "dag-ml", contentType: "dag-ml.recipe", requirements: LONG_ID, contentStatus: "not_evaluated" }),
  artifact({ id: "result:oof", kind: "result", section: "results", owner: "dag-ml", contentStatus: "refused", contentDetail: "Fold scores are incomplete." }),
  artifact({ id: "model:pls", kind: "model", section: "models", owner: "nirs4all-methods" }),
  artifact({ id: "blob:unknown", kind: "vendor-blob", section: "models", owner: "acme.unknown", contentStatus: "opaque" }),
];

const INSPECTION: N4aInspectionView = {
  fileName: "wheat-protein.n4a",
  byteLength: HUGE,
  containerId: "container:0f3c",
  schema: "nirs4all.n4a.container",
  schemaVersion: 1,
  minimumReaderVersion: 1,
  physicalProfile: "zip-stored.v1",
  containerSha256: "c".repeat(64),
  manifestSha256: "d".repeat(64),
  storageStatus: "verified",
  executability: "not_evaluated",
  semantics: { artifacts: 6 },
  trainingView: {},
  requiredFeatures: ["zip64"],
  artifacts: ARTIFACTS,
  members: [
    { path: "artifacts/wheat/root.json", byteLength: HUGE, sha256: "e".repeat(64) },
    { path: "artifacts/recipe:pls/root.json", byteLength: "512", sha256: "f".repeat(64) },
    { path: "artifacts/result:oof/root.json", byteLength: "64", sha256: "1".repeat(64) },
  ],
  links: [{ id: "link:uses", owner: "dag-ml", relation: "uses_dataset", source: "recipe:pls", target: LONG_ID }],
  entrypoints: [{ id: "entry:predict", owner: "dag-ml", operation: "predict", rootArtifact: "model:pls", inputArtifacts: [LONG_ID], requiredFeatures: ["zip64"], requirements: null }],
  counts: { overview: 6, data: 2, pipelines: 1, results: 1, models: 2, other: 0, files: 3 },
  embeddedCount: 5,
  referenceCount: 1,
  manifestText: `{"schema":"nirs4all.n4a.container","size":${HUGE},"note":"<script>alert(1)</script>"}`,
};

const render = (props: Partial<N4aInspectorProps> = {}) => renderToStaticMarkup(<N4aInspector inspection={INSPECTION} {...props} />);
const escapedId = LONG_ID; // only dashes/colons: identical once escaped

beforeEach(() => {
  seen.inspector.length = 0;
});

describe("N4aInspector shell", () => {
  it("shows the host source slot and an honest read-only promise when nothing is open", () => {
    const html = renderToStaticMarkup(<N4aInspector sourceSlot={<button type="button">Choose file</button>} />);
    expect(html).toContain("Open a .n4a container");
    expect(html).toContain("Choose file");
    expect(html).toContain("nothing is executed");
    expect(html).not.toContain("Storage verified");
  });

  it("reports opening and errors through live regions", () => {
    expect(renderToStaticMarkup(<N4aInspector phase="opening" />)).toContain("Opening container…");
    const failed = renderToStaticMarkup(<N4aInspector phase="error" error="Member hash mismatch" />);
    expect(failed).toContain('role="alert"');
    expect(failed).toContain("Could not open the container: Member hash mismatch");
  });

  it("keeps storage, owner content and execution as three separate facts", () => {
    const html = render();
    expect(html).toContain("Storage verified");
    expect(html).toContain("Owner content");
    expect(html).toContain("Owner-validated record: 2 · Not evaluated: 1 · Opaque: 1 · Unresolved: 1 · Refused by owner: 1");
    expect(html).toContain("says nothing about content");
    expect(html).toContain("Execution not evaluated");
    expect(html).toContain("n4wb n4ai n4ai-explorer");
  });

  it("navigates every section, zeros included, with exact counts", () => {
    const html = render();
    for (const label of ["Overview", "Data", "Pipelines", "Results", "Models", "Other", "Files &amp; metadata"]) expect(html).toContain(`<span>${label}</span>`);
    expect(html).toMatch(/<span>Other<\/span><span class="n4wb-count">0<\/span>/);
    expect(html).toContain('aria-current="page"');
    expect(html).toContain("dataset ×2");
    expect(html).toContain("model ×1, vendor-blob ×1");
    // entrypoints and attention list resolve exact ids into navigation buttons
    expect(html).toContain(`title="Open artifact model:pls"`);
    expect(html).toContain("Not readable locally");
    expect(html).toContain("Fold scores are incomplete.");
  });

  it("calls the host only through explicit actions", () => {
    const onExportReport = vi.fn();
    const onClose = vi.fn();
    const html = render({ onExportReport, onClose, headerActions: <span>host action</span>, sourceSlot: <span>Change file</span> });
    expect(html).toContain("Export report");
    expect(html).toContain('aria-label="Close inspector"');
    expect(html).toContain("host action");
    expect(html).toContain("Change file");
    expect(onExportReport).not.toHaveBeenCalled();
    expect(onClose).not.toHaveBeenCalled();
  });
});

describe("N4aInspector files & metadata", () => {
  it("lists every artifact and member with exact bytes, hashes and the original manifest as text", () => {
    const html = render({ section: "files" });
    for (const item of ARTIFACTS) expect(html).toContain(item.id);
    for (const member of INSPECTION.members) {
      expect(html).toContain(member.path);
      expect(html).toContain(member.sha256);
    }
    expect(html).toContain(`${HUGE} bytes`);
    expect(html).toContain("512 bytes");
    expect(html).toContain("Minimum reader version");
    expect(html).toContain("zip-stored.v1");
    expect(html).toContain("uses_dataset");
    expect(html).toContain("entry:predict");
    // verbatim manifest (integer token preserved), escaped as text, never HTML
    expect(html).toContain(`&quot;size&quot;:${HUGE}`);
    expect(html).toContain("&lt;script&gt;alert(1)&lt;/script&gt;");
    expect(html).not.toContain("<script>");
  });
});

describe("N4aInspector artifact detail and previews", () => {
  it("offers an explicit Load preview without requesting it on render or rerender", () => {
    const onRequestPreview = vi.fn();
    const props = { section: "data" as const, selectedArtifactId: LONG_ID, onRequestPreview };
    render(props);
    const html = render(props);
    expect(html).toContain("Load preview");
    expect(onRequestPreview).not.toHaveBeenCalled();
    expect(html).toContain(escapedId);
    expect(html).toContain("Embedded in this file");
    expect(html).toContain("Not evaluated. Inspection grants no execution admission.");
    // the incoming link is navigable by exact id
    expect(html).toContain('title="Open artifact recipe:pls"');
  });

  it("scopes an owner validation to the checked record, never to scientific validity", () => {
    const detail = "IO record validated; semantic fingerprint and links not assessed.";
    const inspection = { ...INSPECTION, artifacts: INSPECTION.artifacts.map((item) => (item.id === "model:pls" ? { ...item, contentDetail: detail } : item)) };
    const html = renderToStaticMarkup(<N4aInspector inspection={inspection} section="models" selectedArtifactId="model:pls" />);
    expect(html).toContain(`Owner-validated record. ${detail} The owner validated the record it reads. This is not an assessment of scientific validity or of execution.`);
    expect(html).toContain("Not evaluated. Inspection grants no execution admission.");
    expect(html).not.toMatch(/scientifically valid|ready to run|executable/i);
  });

  it("states that a host without previews provides none", () => {
    expect(render({ section: "data", selectedArtifactId: LONG_ID })).toContain("This host does not provide content previews.");
  });

  it("never previews references, opaque or refused content", () => {
    const onRequestPreview = vi.fn();
    const reference = render({ section: "data", selectedArtifactId: "data:harvest-2025", onRequestPreview });
    expect(reference).toContain("No local preview: this artifact is a reference");
    expect(reference).toContain("Reference only");
    expect(reference).not.toContain("Load preview");
    const opaque = render({ section: "models", selectedArtifactId: "blob:unknown", onRequestPreview });
    expect(opaque).toContain("acme.unknown");
    expect(opaque).toContain("stays opaque");
    expect(opaque).not.toContain("Load preview");
    const refused = render({ section: "results", selectedArtifactId: "result:oof", onRequestPreview });
    expect(refused).toContain("Refused by owner");
    expect(refused).toContain("Fold scores are incomplete.");
    expect(refused).not.toContain("Load preview");
    expect(onRequestPreview).not.toHaveBeenCalled();
    expect(n4aPreviewUnavailableReason(ARTIFACTS[2]!)).toBeNull();
  });

  it("shows loading and error states", () => {
    const loading = render({ section: "data", selectedArtifactId: LONG_ID, previews: { [LONG_ID]: { status: "loading" } }, onRequestPreview: vi.fn() });
    expect(loading).toContain("Loading preview…");
    expect(loading).toContain(`Loading preview of ${LONG_ID}.`);
    expect(loading).not.toContain("Load preview<");
    const failed = render({ section: "data", selectedArtifactId: LONG_ID, previews: { [LONG_ID]: { status: "error", message: "owner crashed" } }, onRequestPreview: vi.fn() });
    expect(failed).toContain("Preview failed: owner crashed");
    expect(failed).toContain("Retry preview");
  });

  it("refuses a preview that describes another artifact", () => {
    const preview: N4aArtifactPreview = { artifactId: "model:pls", kind: "model", title: "PLS", status: "validated", detail: "", fields: [], tables: [] };
    const html = render({ section: "data", selectedArtifactId: LONG_ID, previews: { [LONG_ID]: { status: "ready", preview } } });
    expect(html).toContain("Preview refused");
  });
});

describe("N4aInspector preview renderers", () => {
  const spectraPreview: N4aArtifactPreview = {
    artifactId: LONG_ID,
    kind: "dataset",
    title: "Wheat NIR",
    status: "validated",
    detail: "240 samples",
    fields: [{ label: "Target", value: "protein (%)" }],
    tables: [{ title: "Samples", columns: ["id", "protein", "masked"], rows: [["W01", 12.5, false], ["W02", null, true]], totalRows: 240 }],
    spectra: [
      {
        title: "Raw signal",
        axis: [0, 1, 2],
        axisUnit: "",
        axisLabel: "Channel index",
        yLabel: "Signal",
        series: [
          { id: "W01", values: [0.1234567890123, null, 0.3] },
          { id: "W02", label: "plot 4", values: [0.2, 0.25, 0.31] },
        ],
        totalSamples: 240,
      },
    ],
  };

  it("renders fields, exact tables and spectra through the existing explorer without inventing wavelengths", () => {
    const html = render({ section: "data", selectedArtifactId: LONG_ID, previews: { [LONG_ID]: { status: "ready", preview: spectraPreview } } });
    expect(html).toContain("protein (%)");
    expect(html).toContain("Samples · showing 2 of 240 rows");
    expect(html).toContain('data-value="12.5"');
    expect(html).toContain("not available");
    expect(html).toContain("false");
    // existing SpectraExplorer (English) with its band table
    expect(html).toContain("n4q-explorer");
    expect(html).toContain("Spectrum values by band");
    expect(html).toContain("Horizontal axis: Channel index, 3 positions");
    expect(html).toContain("2 of 240 samples shown");
    expect(html).toContain("1 masked or missing value");
    expect(html).toContain("masked or missing values per series");
    expect(html).toContain("Exact values · 3 positions × 2 series");
    expect(html).not.toMatch(/wavelength|\bnm\b/i);
    expect(html).toContain("Report only");
  });

  it("does not present a failed owner preview as a success", () => {
    const html = render({
      section: "results",
      selectedArtifactId: "result:oof",
      previews: { "result:oof": { status: "ready", preview: { ...spectraPreview, artifactId: "result:oof", status: "refused", spectra: [] } } },
    });
    // refused content never offers or renders a preview
    expect(html).not.toContain("Spectrum values by band");
    const unresolved = render({
      section: "data",
      selectedArtifactId: LONG_ID,
      previews: { [LONG_ID]: { status: "ready", preview: { ...spectraPreview, status: "unresolved", spectra: [] } } },
    });
    expect(unresolved).toContain("n4wb-note is-warning");
    expect(unresolved).toContain("are not a validation");
  });

  it("renders graphs with the existing DAG view and a textual node/edge alternative", () => {
    const preview: N4aArtifactPreview = {
      artifactId: "recipe:pls",
      kind: "pipeline",
      title: "SNV · PLS",
      status: "validated",
      detail: "",
      fields: [],
      tables: [],
      graph: { nodes: [{ id: "snv", kind: "transform", label: "SNV" }, { id: "pls", kind: "model" }], edges: [{ source: "snv", target: "pls", kind: "data" }] },
    };
    const html = render({ section: "pipelines", selectedArtifactId: "recipe:pls", previews: { "recipe:pls": { status: "ready", preview } } });
    expect(html).toContain("n4dag");
    expect(html).toContain("Graph as text");
    expect(html).toContain("2 nodes · 1 edge");
    expect(html).toContain("SNV · PLS · nodes");
    expect(html).toContain("SNV · PLS · edges");
  });

  it("embeds the trained-chain Inspector with owner scores only and no runtime controls", () => {
    const inspector: NonNullable<N4aArtifactPreview["inspector"]> = {
      chains: [{ id: "c0", model: "PLS", task: "regression", steps: [{ token: "pls", role: "model" }], scores: { rmse_cv: 0.4 } }],
      scoreRefs: [{ key: "rmse_cv", label: "RMSE · CV", metric: "rmse", partition: "validation", lowerIsBetter: true }],
      unavailablePredictions: { c0: "Predictions are not stored." },
    };
    const preview: N4aArtifactPreview = { artifactId: "model:pls", kind: "model", title: "PLS", status: "validated", detail: "", fields: [], tables: [], inspector };
    render({ section: "models", selectedArtifactId: "model:pls", previews: { "model:pls": { status: "ready", preview } } });
    const props = seen.inspector.at(-1)!;
    expect(props.localStatistics).toBe(false);
    expect(props.locale).toBe("en");
    expect(props.availableViews).toEqual(["overview", "top", "table", "folds", "hyperparams"]);
    expect(props.unavailablePredictions).toEqual({ c0: "Predictions are not stored." });
    for (const control of ["onRequestPredictions", "onOpenInPlayground", "onExportSamples", "onOpenChain"] as const) expect(props[control]).toBeUndefined();
    expect(n4aInspectorViews({ ...inspector, predictions: { c0: { chainId: "c0", sampleKeys: ["a"], yTrue: [1], yPred: [1.1] } } })).toContain("parity");
  });
});

describe("N4aInspector compact", () => {
  it("shows a concise identity with collapsed content sections", () => {
    const html = render({ variant: "compact" });
    expect(html).toContain("n4ai-compact");
    expect(html).toContain("wheat-protein.n4a");
    expect(html).toContain("Storage verified");
    expect(html).toContain("Execution not evaluated");
    expect(html).toContain("5 embedded artifacts · 1 reference");
    for (const section of ["Data", "Pipelines", "Results", "Models", "Technical identity"]) expect(html).toContain(`<span>${section}</span>`);
    expect(html).toMatch(/<span>Other<\/span> <span class="n4wb-count">0<\/span>/);
    expect(html).toContain('aria-expanded="false"');
    // collapsed: artifact ids are not dumped into the card
    expect(html).not.toContain("recipe:pls");
  });
});

describe("N4aArtifactPreviewView explore mode", () => {
  const preview: N4aArtifactPreview = {
    artifactId: "data:wheat",
    kind: "dataset",
    title: "Wheat NIR",
    status: "validated",
    detail: "240 samples",
    fields: [{ label: "Target", value: "protein (%)" }],
    tables: [{ title: "Samples", columns: ["id", "protein"], rows: [["W01", 12.5]], totalRows: 240 }],
    spectra: [{ title: "Raw signal", axis: [0, 1], axisUnit: "", axisLabel: "Channel index", yLabel: "Signal", series: [{ id: "W01", values: [0.1, 0.2] }], totalSamples: 240 }],
    graph: { nodes: [{ id: "snv", kind: "transform" }], edges: [] },
  };

  it("keeps the inspector order by default", () => {
    const html = renderToStaticMarkup(<N4aArtifactPreviewView preview={preview} />);
    expect(html).not.toContain("is-explore");
    expect(html.indexOf("protein (%)")).toBeLessThan(html.indexOf("n4q-explorer"));
    expect(html.indexOf("Samples · showing 1 of 240 rows")).toBeLessThan(html.indexOf("n4q-explorer"));
    expect(html).not.toContain("Fields · 1");
  });

  it("shows charts first and keeps fields and tables in collapsed disclosures", () => {
    const html = renderToStaticMarkup(<N4aArtifactPreviewView preview={preview} mode="explore" />);
    expect(html).toContain("is-explore");
    const chart = html.indexOf("n4q-explorer");
    const graph = html.indexOf("n4dag");
    expect(chart).toBeGreaterThan(-1);
    expect(graph).toBeGreaterThan(chart);
    expect(html.indexOf("<summary>Fields · 1</summary>")).toBeGreaterThan(graph);
    expect(html.indexOf("<summary>Tables · 1 (Samples)</summary>")).toBeGreaterThan(graph);
    // the inspector disclosures are closed: native <details> without the open attribute
    expect(html).not.toMatch(/<details class="n4ai-details"[^>]*\sopen/);
    // text alternatives of the existing views remain available
    expect(html).toContain("Graph as text");
    expect(html).toContain("Exact values · 2 positions × 1 series");
    expect(html).toContain("Samples · showing 1 of 240 rows");
    expect(html).toContain("Report only");
  });

  it("keeps the owner warning above the charts in explore mode", () => {
    const html = renderToStaticMarkup(<N4aArtifactPreviewView preview={{ ...preview, status: "unresolved" }} mode="explore" />);
    expect(html.indexOf("are not a validation")).toBeLessThan(html.indexOf("n4q-explorer"));
  });
});
