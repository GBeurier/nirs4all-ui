import { describe, expect, it } from "vitest";
import { formatN4aBytes, projectN4aInspection, projectN4aPreview, type N4aInspectionDocument } from "./model.js";

const report = (): N4aInspectionDocument => ({ byteLength: "9007199254740993", memberByteLengths: { "unknown.bin": "9007199254740993" }, manifestText: '{"byte_length":9007199254740993}',
  view: { readability: { storage: "verified", container_sha256: "container-sha", manifest_sha256: "manifest-sha", semantics: { status: "not_evaluated" }, training_view: {}, manifest: {
    schema: "nirs4all.n4a.container.v1", schema_version: 1, minimum_reader_version: 1, physical_profile: "zip-stored.v1", container_id: "c", required_features: [],
    members: [{ path: "unknown.bin", byte_length: 9007199254740992, sha256: "sha" }],
    artifacts: [{ id: "unknown", kind: "attachment", owner: "custom", content_type: { id: "private.schema", version: 3 }, identity: {}, storage: { kind: "embedded", root_member: "unknown.bin", member_paths: ["unknown.bin"] }, requirements: null },
      { id: "ref", kind: "dataset", owner: "nirs4all-io", content_type: { id: "nirs4all.dataset.v2", version: 2 }, identity: {}, storage: { kind: "reference" }, requirements: null }],
    links: [{ id: "l", owner: "custom", relation: "uses", source_artifact: "unknown", target_artifact: "ref" }], entrypoints: [],
  } } } });
describe("Core inspection projections", () => {
  it("preserves all unknown content, exact ZIP64 sizes, raw manifest and unresolved references", () => {
    const view = projectN4aInspection(report(), "file.n4a");
    expect(view.byteLength).toBe("9007199254740993"); expect(view.artifacts[0]?.byteLength).toBe("9007199254740993");
    expect(view.manifestText).toBe(report().manifestText); expect(view.artifacts[1]?.contentStatus).toBe("unresolved");
    expect(view.counts.other).toBe(1); expect(view.counts.data).toBe(1); expect(view.embeddedCount).toBe(1); expect(view.referenceCount).toBe(1);
    expect(view.links[0]?.target).toBe("ref"); expect(view.executability).toBe("not_evaluated");
  });
  it("requires verified storage and exact member sizes", () => {
    const input = report(); input.view.readability.storage = "unverified";
    expect(() => projectN4aInspection(input, "x")).toThrow(/verify/);
    const missing = report(); missing.memberByteLengths = {};
    expect(() => projectN4aInspection(missing, "x")).toThrow(/Exact member size/);
  });
  it("formats bytes without converting large integers to Number", () => {
    expect(formatN4aBytes("1024")).toBe("1.0 KiB"); expect(formatN4aBytes("0")).toBe("0 bytes");
    expect(formatN4aBytes("9007199254740993")).toBe("8.0 PiB");
  });
  it("projects an owner graph while retaining its recorded parameters table", () => {
    const preview = projectN4aPreview({ artifactId: "p", kind: "pipeline", title: "P", status: "not_evaluated", detail: "Read only", fields: [], tables: [], graph: { nodes: [{ id: "model", kind: "model", operator: "pls" }], edges: [] } });
    expect(preview.graph?.nodes[0]?.id).toBe("model");
    expect(preview.graph?.nodes[0]?.label).toBe("pls");
  });
});
