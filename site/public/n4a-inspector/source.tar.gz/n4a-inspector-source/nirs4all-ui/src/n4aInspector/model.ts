import { fromCompiledGraph } from "../dag/fromCompiledGraph.js";
import { projectDagEvidence } from "./dagEvidence.js";
import type { N4aArtifactPreview, N4aContentStatus, N4aInspectionView, N4aSection } from "./types.js";

export const N4A_SECTIONS: readonly N4aSection[] = ["overview", "data", "pipelines", "results", "models", "other", "files"];
export const N4A_SECTION_LABELS: Readonly<Record<N4aSection, string>> = {
  overview: "Overview", data: "Data", pipelines: "Pipelines", results: "Results",
  models: "Models", other: "Other", files: "Files & metadata",
};

/** Input is supplied after Core storage validation, not directly from a file. */
export interface N4aInspectionDocument {
  view: { readability: { storage: string; container_sha256: string; manifest_sha256: string;
    manifest: Record<string, unknown>; semantics: Record<string, unknown>; training_view: Record<string, unknown> } };
  byteLength: string;
  memberByteLengths: Readonly<Record<string, string>>;
  manifestText: string;
}
const object = (value: unknown): Record<string, unknown> => value !== null && typeof value === "object" && !Array.isArray(value) ? value as Record<string, unknown> : {};
const records = (value: unknown): Record<string, unknown>[] => Array.isArray(value) ? value.map(object) : [];
const strings = (value: unknown): string[] => Array.isArray(value) ? value.filter((item): item is string => typeof item === "string") : [];
const text = (value: unknown): string => typeof value === "string" ? value : "";
const CONTENT_STATUSES = new Set<N4aContentStatus>(["not_evaluated", "validated", "opaque", "unresolved", "refused"]);

export function n4aSectionForKind(kind: string): N4aSection {
  if (kind === "dataset") return "data";
  if (kind === "recipe") return "pipelines";
  if (kind === "model") return "models";
  if (["run", "result", "score", "prediction", "residual", "training_evidence"].includes(kind)) return "results";
  return "other";
}

/** Keep all artifacts and declarations; never infer ownership from file suffixes. */
export function projectN4aInspection(input: N4aInspectionDocument, fileName: string): N4aInspectionView {
  const { readability } = input.view;
  if (readability.storage !== "verified") throw new TypeError("Core must verify container storage before projecting an inspection.");
  const manifest = readability.manifest;
  const members = records(manifest["members"]).map(member => {
    const path = text(member["path"]);
    const byteLength = input.memberByteLengths[path];
    if (byteLength === undefined || !/^\d+$/.test(byteLength)) throw new TypeError(`Exact member size is missing: ${path}`);
    return { path, byteLength, sha256: text(member["sha256"]) };
  });
  const byPath = new Map(members.map(member => [member.path, member]));
  const reports = records(readability.semantics["artifacts"]);
  const artifacts = records(manifest["artifacts"]).map(artifact => {
    const storage = object(artifact["storage"]), content = object(artifact["content_type"]);
    const id = text(artifact["id"]), kind = text(artifact["kind"]);
    const embedded = storage["kind"] === "embedded";
    const paths = strings(storage["member_paths"]);
    const report = reports.find(item => item["artifact_id"] === id);
    const reported = text(report?.["content"]);
    const status: N4aContentStatus = !embedded ? "unresolved" : CONTENT_STATUSES.has(reported as N4aContentStatus) ? reported as N4aContentStatus : "not_evaluated";
    return {
      id, kind, owner: text(artifact["owner"]), contentType: text(content["id"]), contentVersion: Number(content["version"]),
      identity: object(artifact["identity"]), section: n4aSectionForKind(kind),
      storage: embedded ? "embedded" as const : "reference" as const,
      rootMember: embedded ? text(storage["root_member"]) : null, memberPaths: paths,
      byteLength: paths.reduce((sum, path) => sum + BigInt(byPath.get(path)?.byteLength ?? "0"), 0n).toString(),
      rootSha256: text(storage["root_sha256"]) || null,
      requirements: text(object(artifact["requirements"])["artifact_id"]) || null,
      contentStatus: status, contentDetail: text(report?.["detail"]) || null,
    };
  });
  const counts: Record<N4aSection, number> = { overview: artifacts.length, data: 0, pipelines: 0, results: 0, models: 0, other: 0, files: members.length };
  for (const artifact of artifacts) counts[artifact.section]++;
  return {
    fileName, byteLength: input.byteLength, containerId: text(manifest["container_id"]),
    schema: text(manifest["schema"]), schemaVersion: Number(manifest["schema_version"]),
    minimumReaderVersion: Number(manifest["minimum_reader_version"]), physicalProfile: text(manifest["physical_profile"]),
    containerSha256: readability.container_sha256, manifestSha256: readability.manifest_sha256,
    storageStatus: "verified", executability: "not_evaluated", semantics: readability.semantics,
    trainingView: readability.training_view, requiredFeatures: strings(manifest["required_features"]), artifacts, members,
    links: records(manifest["links"]).map(link => ({ id: text(link["id"]), owner: text(link["owner"]), relation: text(link["relation"]), source: text(link["source_artifact"]), target: text(link["target_artifact"]) })),
    entrypoints: records(manifest["entrypoints"]).map(entry => ({ id: text(entry["id"]), owner: text(entry["owner"]), operation: text(entry["operation"]), rootArtifact: text(entry["root_artifact"]), inputArtifacts: strings(entry["input_artifacts"]), requiredFeatures: strings(entry["required_features"]), requirements: text(object(entry["requirements"])["artifact_id"]) || null })),
    counts, embeddedCount: artifacts.filter(artifact => artifact.storage === "embedded").length,
    referenceCount: artifacts.filter(artifact => artifact.storage === "reference").length, manifestText: input.manifestText,
  };
}

/** Owner-produced preview data; only the graph's layout contract is adapted here. */
export type N4aOwnerPreview = Omit<N4aArtifactPreview, "graph"> & { graph?: unknown; evidence?: unknown };
export function projectN4aPreview(preview: N4aOwnerPreview): N4aArtifactPreview {
  const { graph, evidence, ...base } = preview;
  const rest = evidence === undefined ? base : { ...base, inspector: projectDagEvidence(evidence) };
  if (graph === undefined) return rest;
  const projected = fromCompiledGraph(graph);
  const operators = new Map(records(object(graph)["nodes"]).map(node => [text(node["id"]), text(node["operator"])]));
  // GraphSpec uses string operators as well as the compiled viewer's typed form.
  projected.nodes = projected.nodes.map(node => operators.get(node.id) ? { ...node, label: operators.get(node.id)! } : node);
  return { ...rest, graph: projected };
}

/** Integer arithmetic preserves exact byte counts, including ZIP64 inventories. */
export function formatN4aBytes(decimal: string): string {
  const bytes = BigInt(decimal);
  const units = ["bytes", "KiB", "MiB", "GiB", "TiB", "PiB", "EiB"];
  let divisor = 1n, index = 0;
  while (bytes >= divisor * 1024n && index < units.length - 1) { divisor *= 1024n; index++; }
  if (index === 0) return `${bytes} bytes`;
  const tenths = bytes * 10n / divisor;
  return `${tenths / 10n}.${tenths % 10n} ${units[index]}`;
}

export function linkedN4aArtifacts(view: N4aInspectionView, id: string) {
  return view.links.filter(link => link.source === id || link.target === id);
}
