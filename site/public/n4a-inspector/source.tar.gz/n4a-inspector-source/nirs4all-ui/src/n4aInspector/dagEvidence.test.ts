import { describe, expect, it } from 'vitest';
import { projectDagEvidence } from './dagEvidence.js';
describe('stored DAG evidence presentation', () => {
  it('keeps targets, partitions and aggregate methods separate', () => {
    const report = (fold_id: string, partition = 'validation') => ({ variant_id: 'v', producer_node: 'model', level: 'sample', target_names: ['carbon', 'clay'], partition, fold_id, metrics: { rmse: 99, 'rmse:carbon': 2, 'rmse:clay': 7 } });
    const result = projectDagEvidence({ scoreSet: { reports: [report('f1'), report('f2'), report('avg'), report('w_avg'), report('', 'test')] } });
    expect(result.chains).toHaveLength(2); expect(result.scoreRefs).toHaveLength(10);
    expect(result.scoreRefs.map(r => r.protocol)).toContain('cv weighted avg');
    const carbon = result.chains.find(c => c.target === 'carbon')!;
    expect(Object.values(carbon.scores)).toEqual([2, 2, 2, 2, 2]); expect(Object.values(carbon.foldScores!)).toEqual([[2, 2]]);
    expect(Object.values(carbon.scores)).not.toContain(99);
  });
  it('joins OOF truth by unit identity and target name, including permuted rows and targets', () => {
    const result = projectDagEvidence({ scoreSet: { reports: [{ variant_id: 'v', producer_node: 'm', level: 'sample', target_names: ['a', 'b'], partition: 'validation', fold_id: 'avg', metrics: { 'rmse:a': 1, 'rmse:b': 2 } }] },
      variantAverages: [{ variant_id: 'v', oof_averages: [{ predictions: { producer_node: 'm', level: 'sample', target_names: ['a', 'b'], partition: 'validation', fold_id: 'avg', unit_ids: [{ id: 's1', level: 'sample' }, { id: 's2', level: 'sample' }], values: [[11, 21], [12, 22]] },
        y_true: { target_names: ['b', 'a'], unit_ids: [{ id: 's2', level: 'sample' }, { id: 's1', level: 'sample' }], values: [[200, 100], [20, 10]] } }] }] });
    expect(Object.values(result.predictions ?? {})[0]?.yTrue).toEqual([10, 100]); expect(Object.values(result.predictions ?? {})[0]?.yPred).toEqual([11, 12]); expect(Object.values(result.predictions ?? {})[1]?.yTrue).toEqual([20, 200]);
  });
  it('does not fabricate per-target values from a multi-target aggregate or missing truth', () => {
    const result = projectDagEvidence({ scoreSet: { reports: [{ target_names: ['a', 'b'], metrics: { rmse: 4 }, partition: 'validation', fold_id: 'avg' }] } });
    expect(result.scoreRefs).toEqual([]); expect(result.predictions).toEqual({}); expect(result.chains.every(c => Object.keys(c.scores).length === 0)).toBe(true);
  });
  it('keeps the selected variant OOF predictions when the owner stores losing variants separately', () => {
    const average = { predictions: { producer_node: 'm', level: 'sample', target_names: ['y'], partition: 'validation', fold_id: 'avg', unit_ids: [{id:'s',level:'sample'}], values: [[3]] }, y_true: { target_names: ['y'], unit_ids: [{id:'s',level:'sample'}], values: [[2]] } };
    const report = (variant_id: string) => ({ variant_id, producer_node: 'm', level: 'sample', target_names: ['y'], partition: 'validation', fold_id: 'avg', metrics: {rmse: 1} });
    const result = projectDagEvidence({ selectedVariantId:'winner', scoreSet:{reports:[report('winner'),report('other')]}, selectedAverages:[average], variantAverages:[{variant_id:'other',oof_averages:[average]}] });
    expect(Object.values(result.predictions ?? {})).toHaveLength(2);
    expect(Object.values(result.predictions ?? {}).some(p => p.chainId.includes('winner'))).toBe(true);
  });

  it('retains individual training folds and their average without calling them final', () => {
    const result = projectDagEvidence({ variants:[{variant_id:'v',choices:{native_model_params:{param_overrides:[{node_id:'model',params:{n_components:6}}]}}}], scoreSet:{reports:[
      ...[['fold0',1],['fold1',7],['avg',4]].map(([fold_id,rmse])=>({variant_id:'v',producer_node:'model',level:'sample',target_names:['y'],partition:'train_pool',fold_id,metrics:{rmse}})),
      {variant_id:'v',producer_node:'model',level:'sample',target_names:['y'],partition:'final',fold_id:null,metrics:{rmse:9}}
    ]} });
    expect(result.scoreRefs.filter(r=>r.partition==='train_pool').map(r=>r.protocol)).toEqual(['fold fold0','fold fold1','cv avg']);
    expect(Object.values(result.chains[0]!.scores)).toEqual([1,7,4,9]);
    expect(result.chains[0]!.label).toContain('n_components=6');
  });

});
