import type { ReactNode } from "react";
import type { DagGraph } from "../dag/types.js";
import type { InspectorProps } from "../inspector/Inspector.js";

/** Presentation of a Core-validated container; this is not a container parser. */
export type N4aSection = "overview" | "data" | "pipelines" | "results" | "models" | "other" | "files";
export type N4aContentStatus = "not_evaluated" | "validated" | "opaque" | "unresolved" | "refused";

export interface N4aMemberView {
  path: string;
  /** Exact decimal integer, never a rounded JSON number. */
  byteLength: string;
  sha256: string;
}
export interface N4aArtifactView {
  id: string;
  kind: string;
  owner: string;
  contentType: string;
  contentVersion: number;
  identity: Readonly<Record<string, unknown>>;
  section: N4aSection;
  storage: "embedded" | "reference";
  rootMember: string | null;
  memberPaths: readonly string[];
  byteLength: string;
  rootSha256: string | null;
  requirements: string | null;
  contentStatus: N4aContentStatus;
  contentDetail: string | null;
}
export interface N4aLinkView {
  id: string;
  owner: string;
  relation: string;
  source: string;
  target: string;
}
export interface N4aEntrypointView {
  id: string;
  owner: string;
  operation: string;
  rootArtifact: string;
  inputArtifacts: readonly string[];
  requiredFeatures: readonly string[];
  requirements: string | null;
}
export interface N4aInspectionView {
  fileName: string;
  byteLength: string;
  containerId: string;
  schema: string;
  schemaVersion: number;
  minimumReaderVersion: number;
  physicalProfile: string;
  containerSha256: string;
  manifestSha256: string;
  storageStatus: "verified";
  executability: "not_evaluated";
  semantics: Readonly<Record<string, unknown>>;
  trainingView: Readonly<Record<string, unknown>>;
  requiredFeatures: readonly string[];
  artifacts: readonly N4aArtifactView[];
  members: readonly N4aMemberView[];
  links: readonly N4aLinkView[];
  entrypoints: readonly N4aEntrypointView[];
  counts: Readonly<Record<N4aSection, number>>;
  embeddedCount: number;
  referenceCount: number;
  /** Original manifest text supplied by the host, preserving integer tokens. */
  manifestText: string;
}
export interface N4aPreviewField { label: string; value: string; }
export interface N4aPreviewTable {
  title: string;
  columns: readonly string[];
  rows: ReadonlyArray<ReadonlyArray<string | number | boolean | null>>;
  /** Honest displayed/total counts when the owner limits an exploratory view. */
  totalRows?: number;
}
export interface N4aSpectraPreview {
  title: string;
  axis: readonly number[];
  axisUnit: string;
  yLabel: string;
  series: readonly { id: string; label?: string; values: readonly (number | null)[] }[];
  totalSamples: number;
  /** Coordinates may be channel indices; never label them as wavelengths. */
  axisLabel: string;
}
export interface N4aArtifactPreview {
  artifactId: string;
  kind: "dataset" | "pipeline" | "result" | "model" | "document";
  title: string;
  /** Inspection is report-only and grants no execution admission. */
  status: N4aContentStatus;
  detail: string;
  fields: readonly N4aPreviewField[];
  tables: readonly N4aPreviewTable[];
  spectra?: readonly N4aSpectraPreview[];
  graph?: DagGraph;
  inspector?: Pick<InspectorProps, "chains" | "scoreRefs" | "predictions" | "unavailablePredictions">;
}
export type N4aPreviewState =
  | { status: "loading" }
  | { status: "ready"; preview: N4aArtifactPreview }
  | { status: "error"; message: string };

export interface N4aInspectorProps {
  inspection?: N4aInspectionView | null;
  phase?: "idle" | "opening" | "ready" | "error";
  error?: string | null;
  /** File chooser/drop zone supplied by the host; UI never reads File objects. */
  sourceSlot?: ReactNode;
  headerActions?: ReactNode;
  variant?: "explorer" | "compact";
  section?: N4aSection;
  onSectionChange?: (section: N4aSection) => void;
  selectedArtifactId?: string | null;
  onSelectArtifact?: (artifactId: string) => void;
  previews?: Readonly<Record<string, N4aPreviewState>>;
  onRequestPreview?: (artifactId: string) => void;
  onClose?: () => void;
  onExportReport?: () => void;
  className?: string;
}
