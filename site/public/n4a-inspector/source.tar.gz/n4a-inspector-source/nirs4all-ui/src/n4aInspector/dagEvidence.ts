import type { InspectorProps } from "../inspector/Inspector.js";
import type { ChainPredictions, InspectorChain, ScoreRef } from "../inspector/types.js";

const obj = (v: unknown): Record<string, unknown> => v !== null && typeof v === "object" && !Array.isArray(v) ? v as Record<string, unknown> : {};
const list = (v: unknown): Record<string, unknown>[] => Array.isArray(v) ? v.map(obj) : [];
const str = (v: unknown): string => typeof v === "string" ? v : "";
const names = (v: unknown): string[] => Array.isArray(v) ? v.filter((x): x is string => typeof x === "string") : [];
const directions: Record<string, boolean> = { rmse: true, mse: true, mae: true, r2: false };

/** Project stored owner scores without recomputing them or merging evaluation contexts. */
export function projectDagEvidence(input: unknown): Pick<InspectorProps, "chains" | "scoreRefs" | "predictions"> {
  const evidence = obj(input), reports = list(obj(evidence["scoreSet"])["reports"]);
  const refs = new Map<string, ScoreRef>(), chains = new Map<string, InspectorChain>();
  const graphNodes = list(obj(evidence["graph"])["nodes"]);
  const model = graphNodes.find(n => str(n["kind"]).toLowerCase() === "model");
  const method = str(obj(model?.["params"])["method_id"]) || str(model?.["operator"]) || "Stored model";
  const variantParams = new Map(list(evidence["variants"]).map(v => {
    const overrides = Object.values(obj(v["choices"])).flatMap(choice => list(obj(choice)["param_overrides"]));
    return [str(v["variant_id"]), Object.fromEntries(overrides.flatMap(override => Object.entries(obj(override["params"])).map(([key, value]) => [`${str(override["node_id"])}.${key}`, value])))];
  }));
  for (const report of reports) {
    const variant = str(report["variant_id"]) || str(evidence["selectedVariantId"]), partition = str(report["partition"]), fold = str(report["fold_id"]);
    const level = str(report["level"]), producer = str(report["producer_node"]), targets = names(report["target_names"]);
    for (const target of targets) {
      const id = JSON.stringify([variant, producer, level, target]);
      let chain = chains.get(id);
      if (!chain) {
        const params = Object.fromEntries(Object.entries(variantParams.get(variant) ?? {}).filter((entry): entry is [string, string | number | boolean | null] => entry[1] === null || ["number", "string", "boolean"].includes(typeof entry[1])));
        const setting = Object.entries(params).map(([key, value]) => `${key.split('.').at(-1)}=${String(value)}`).join(', ');
        chain = { id, label: `${setting || variant || "Stored variant"} · ${target} · ${level}`, ...(str(evidence["runId"]) ? { runId: str(evidence["runId"]) } : {}),
          task: "regression", target, model: method, modelFamily: method, steps: [],
          params,
          scores: {}, foldScores: {} };
        chains.set(id, chain);
      }
      for (const [metric, lowerIsBetter] of Object.entries(directions)) {
        const stored = obj(report["metrics"])[`${metric}:${target}`];
        // A scalar aggregate over several targets is never labelled as one target's score.
        const value = stored ?? (targets.length === 1 ? obj(report["metrics"])[metric] : undefined);
        if (typeof value !== "number" || !Number.isFinite(value)) continue;
        const isFold = Boolean(fold) && fold !== "avg" && fold !== "w_avg";
        const protocol = fold === "w_avg" ? "cv weighted avg" : fold === "avg" ? "cv avg" : isFold ? `fold ${fold}` : partition === "final" ? "stored final" : `stored ${partition}`;
        const key = JSON.stringify([metric, partition, protocol, level, target]);
        refs.set(key, { key, label: `${metric.toUpperCase()} · ${target} · ${partition} · ${protocol} · ${level}`, metric, partition, protocol, lowerIsBetter });
        if (isFold) {
          const aggregateKey = JSON.stringify([metric, partition, "cv avg", level, target]);
          const previous = chain.foldScores?.[aggregateKey] ?? [];
          chain.foldScores = { ...chain.foldScores, [aggregateKey]: [...previous, value] };
        }
        chain.scores = { ...chain.scores, [key]: value };
      }
    }
  }
  const predictions: ChainPredictions[] = [];
  const averages = list(evidence["variantAverages"]);
  const groups = averages.map(v => ({ variant: str(v["variant_id"]), averages: list(v["oof_averages"]) }));
  const selected = str(evidence["selectedVariantId"]);
  if (!groups.some(g => g.variant === selected)) groups.push({ variant: selected, averages: list(evidence["selectedAverages"]) });
  for (const group of groups) for (const average of group.averages) {
    const p = obj(average["predictions"]), truth = obj(average["y_true"]);
    const pTargets = names(p["target_names"]), tTargets = names(truth["target_names"]);
    const pIds = list(p["unit_ids"]), tIds = list(truth["unit_ids"]);
    const pRows = Array.isArray(p["values"]) ? p["values"] as unknown[][] : [];
    const tRows = Array.isArray(truth["values"]) ? truth["values"] as unknown[][] : [];
    const truthById = new Map(tIds.map((id, i) => [JSON.stringify([id["level"], id["id"]]), tRows[i]]));
    for (const [targetIndex, target] of pTargets.entries()) {
      const chainId = JSON.stringify([group.variant, str(p["producer_node"]), str(p["level"]), target]);
      if (!chains.has(chainId)) continue;
      const truthIndex = tTargets.indexOf(target);
      if (truthIndex < 0) continue;
      const pairs = pIds.flatMap((id, i) => {
        const yPred = pRows[i]?.[targetIndex], yTrue = truthById.get(JSON.stringify([id["level"], id["id"]]))?.[truthIndex];
        return typeof yPred === "number" && Number.isFinite(yPred) && typeof yTrue === "number" && Number.isFinite(yTrue)
          ? [{ id: str(id["id"]), yPred, yTrue }] : [];
      });
      if (pairs.length) predictions.push({ chainId, sampleKeys: pairs.map(x => x.id), yPred: pairs.map(x => x.yPred), yTrue: pairs.map(x => x.yTrue),
        partition: pairs.map(() => str(p["partition"])), fold: pairs.map(() => str(p["fold_id"])) });
    }
  }
  const priority = (ref: ScoreRef) => ref.partition === "validation" && ref.protocol === "cv avg" ? 0 : ref.partition === "validation" && ref.protocol === "cv weighted avg" ? 1 : ref.partition === "final" ? 2 : 3;
  return { chains: [...chains.values()], scoreRefs: [...refs.values()].sort((a, b) => priority(a) - priority(b)), predictions: Object.fromEntries(predictions.map(p => [p.chainId, p])) };
}
