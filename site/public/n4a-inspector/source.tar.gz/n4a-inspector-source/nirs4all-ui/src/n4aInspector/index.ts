/**
 * nirs4all-ui `n4aInspector` domain — read-only inspection of `.n4a` containers.
 *
 * The host reads the file and has Core verify its storage; `projectN4aInspection`
 * turns that verified result into an `N4aInspectionView`, and `N4aInspector`
 * presents it (explorer or compact card). Owner previews are produced by the host
 * on explicit request and adapted with `projectN4aPreview`. Nothing here reads
 * files, fetches, starts workers, loads owners or executes content.
 *
 * Styles: `nirs4all-ui/assets/workbench.css` + `nirs4all-ui/assets/n4a-inspector.css`
 * (plus `qualification.css` and `dag.css` for spectra and graph previews).
 *
 * Consumed as `nirs4all-ui/n4aInspector`.
 */

export * from "./types.js";
export * from "./model.js";
export {
  N4aArtifactPreviewView,
  N4aInspector,
  N4A_CONTENT_STATUS_TEXT,
  n4aInspectorViews,
  n4aPreviewUnavailableReason,
  type N4aArtifactPreviewViewProps,
} from "./N4aInspector.js";
