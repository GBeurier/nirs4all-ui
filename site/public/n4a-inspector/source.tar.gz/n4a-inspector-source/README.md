# N4a Inspector preview source

This archive contains the shared UI source and the inspector host/owner adapters used by the preview, plus selected runtime JavaScript, licenses and artifact provenance. The ten public example bundles contain source attribution and preparation notes. Native artifacts were explicitly selected from the existing Web cohort; this is not a claim that they were rebuilt from current owner working trees. See legal/*/PROVENANCE.json and inspection-build.json for source commits and exact hashes.

Start with nirs4all-web/web-app/inspector-host/README.md. All scientific execution remains in Core, DAG-ML and Methods. No dataset or experiment upload is performed by the preview.

The published showroom UI source is under nirs4all-ui/site/inspector-host. The original Web host and owner adapters are retained for provenance. Rebuild instructions are in the UI checkout.
