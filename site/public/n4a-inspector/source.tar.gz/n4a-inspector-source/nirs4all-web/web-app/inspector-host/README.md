# Instrumented N4a Inspector host

This browser host combines the shared `N4aInspector` identity view with direct
`SpectraExplorer`, `DagGraphView` and results `Inspector` previews. It uses the
existing UI theme and workbench styles. File selection, owner loading, workers,
action inputs and downloads remain host responsibilities.

The ten public examples are produced by the real Core canonical V1 actions,
with DAG-ML scheduling CV/OOF selection/refit and Methods fitting the estimators.
Walnut preserves source calibration/test assignments. Milk keeps every measurement of one cow in the same holdout/CV group. The soil example
uses distinct physical soil layers and a documented demonstration holdout.
These are demonstration analyses, not reproductions of the source benchmarks.

Prepare inputs with the project Python environment and the Datasets source on
`PYTHONPATH`, then run the generator with Node 24. Both commands require explicit
paths; the generator refuses a nonempty output directory.

```sh
python scripts/prepare-inspector-public-inputs.py \
  --datasets-root /path/to/nirs4all-datasets --out-dir /path/to/inputs
node scripts/generate-inspector-examples.mjs \
  --core-package /path/to/selected/core/wasm-package \
  --io-bindings /path/to/nirs4all-io/bindings/wasm \
  --inputs /path/to/inputs --out-dir /path/to/examples
```

Build with `scripts/build-n4a-inspector.mjs` and its explicit UI/Core/IO/DAG/native
arguments, plus `--examples /path/to/examples`. The selected Core JS package and
native artifact must expose the same actions; missing APIs are a refusal, never
a fallback. This source build is distinct from the application's pinned runtime.
The build record hashes the selected code and runtime artifacts. It does not
claim that native artifacts were rebuilt from the current owner working trees.

Browser actions require an explicit click. Run reads the complete native recipe
from a declared DAG execution plan and a selected embedded IO record. Core owns
recipe/schema admission; no recipe is reconstructed from visual graph nodes.
Replay and retrain first admit the archive through Core's native model profile.
A stored replay uses its declared input; another local container supplies external
data. Cancelling terminates the worker. No external artifact reference is fetched.

Public example attribution is embedded in each bundle and copied into new
browser-generated analysis artifacts. Source license/protocol notes accompany
the gallery. The model-only example still contains public sample identities,
OOF labels/predictions and scores; it is not an anonymized artifact.

Run the browser gate against a served build:

```sh
N4A_INSPECTOR_URL=http://127.0.0.1:8795/ \
  node tests/n4a-inspector-workspace-smoke.mjs
```
