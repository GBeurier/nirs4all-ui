import type { N4aInspectionView, N4aPreviewState } from 'nirs4all-ui/n4aInspector'

export interface PublicExample {
  id: string
  title: string
  scenario: string
  description: string
  file: string
  datasets: string[]
  counts: Record<string, number>
  bytes: number
  sources: { title: string; url: string; license: string; attribution: string }[]
  notes: string[]
}
export interface WorkspaceAction {
  id: string
  label: string
  description: string
  kind: 'run' | 'replay' | 'retrain'
  recipeArtifactId?: string
  datasetArtifactId?: string
  entrypoint?: string
  partition?: string
  sourceId: string
}
export interface ActionState {
  status: 'idle' | 'running' | 'done' | 'error'
  title?: string
  message?: string
  preview?: N4aPreviewState
  download?: { url: string; name: string }
}
export interface InstrumentedWorkspaceProps {
  examples: readonly PublicExample[]
  loadingExample: string | null
  currentExample: PublicExample | null
  onLoadExample: (example: PublicExample) => void
  inspection: N4aInspectionView | null
  previews: Readonly<Record<string, N4aPreviewState>>
  onRequestPreview: (id: string) => void
  onInspectArtifact: (id: string) => void
  actions: readonly WorkspaceAction[]
  actionState: ActionState
  onAction: (action: WorkspaceAction) => void
  onCancelAction: () => void
  onOpenActionOutput: () => void
}
