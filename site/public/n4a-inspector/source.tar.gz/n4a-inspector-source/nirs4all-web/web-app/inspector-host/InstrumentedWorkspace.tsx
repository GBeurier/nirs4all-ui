// SPDX-License-Identifier: CeCILL-2.1 OR AGPL-3.0-or-later
/**
 * Instrumented workspace of the `.n4a` inspector host: a public example gallery,
 * direct spectra / pipeline graph / results / models views over the opened
 * container, and the host-provided run, replay and retrain actions.
 *
 * Presentational only. The parent fetches examples, opens containers, produces
 * owner previews on explicit request and executes actions; this component renders
 * what it receives and never fetches, reads files or computes anything scientific.
 * Plots are the shared `N4aArtifactPreviewView` (explore mode), with their text
 * alternatives.
 */
import { useId, useMemo, useState, type ReactNode } from 'react'
import {
  formatN4aBytes,
  N4aArtifactPreviewView,
  N4A_CONTENT_STATUS_TEXT,
  n4aPreviewUnavailableReason,
  type N4aArtifactView,
  type N4aInspectionView,
  type N4aPreviewState,
  type N4aSection,
} from 'nirs4all-ui/n4aInspector'
import type { InstrumentedWorkspaceProps, PublicExample, WorkspaceAction } from './workspace-types'
import './workspace.css'

type ViewId = 'data' | 'pipelines' | 'results' | 'models'

const VIEWS: readonly { id: ViewId; label: string; hint: string }[] = [
  { id: 'data', label: 'Spectra & data', hint: 'Signals, targets and sample tables of the stored datasets.' },
  { id: 'pipelines', label: 'Pipeline graph', hint: 'Stored recipes drawn as DAG graphs.' },
  { id: 'results', label: 'Results', hint: 'Recorded owner scores and predictions in the results Inspector.' },
  { id: 'models', label: 'Models', hint: 'Fitted models and their stored state.' },
]

const KIND_TEXT: Readonly<Record<WorkspaceAction['kind'], { label: string; button: string; note: string }>> = {
  run: {
    label: 'Run',
    button: 'Run in browser',
    note: 'Fits in this browser with the owner runtime. The output is a new bundle; the opened file is not changed.',
  },
  replay: {
    label: 'Replay',
    button: 'Replay',
    note: 'Applies the stored fitted state to stored data. Nothing is fitted or refit.',
  },
  retrain: {
    label: 'Retrain',
    button: 'Retrain in browser',
    note: 'Fits again in this browser with the owner runtime. The output is a new bundle; the opened file is not changed.',
  },
}

function plural(count: number, word: string): string {
  return `${count} ${word}${count === 1 ? '' : 's'}`
}

function bytesText(bytes: number): string {
  if (!Number.isSafeInteger(bytes) || bytes < 0) return 'size not declared'
  const human = formatN4aBytes(String(bytes))
  return human === `${bytes} bytes` ? human : `${human} (${bytes} bytes)`
}

function StatusBadge({ artifact }: { artifact: N4aArtifactView }) {
  const status = N4A_CONTENT_STATUS_TEXT[artifact.contentStatus]
  return <span className={`n4ai-badge is-${status.tone}`} title={status.help}>{status.label}</span>
}

// ------------------------------------------------------------------ gallery

function ExampleProvenance({ example }: { example: PublicExample }) {
  return (
    <details className="n4ai-details n4iw-provenance">
      <summary>Sources, licenses and notes · {example.sources.length + example.notes.length}</summary>
      {example.sources.length > 0 ? (
        <ul className="n4iw-sources" aria-label={`Sources of ${example.title}`}>
          {example.sources.map(source => (
            <li key={`${source.url}-${source.title}`}>
              <a href={source.url} target="_blank" rel="noopener noreferrer">{source.title}</a>
              <span className="n4iw-license">{source.license}</span>
              <span className="n4ai-caption">{source.attribution}</span>
            </li>
          ))}
        </ul>
      ) : <p className="n4ai-muted-line">No external source declared.</p>}
      {example.notes.length > 0 ? (
        <ul className="n4iw-notes" aria-label={`Notes on ${example.title}`}>
          {example.notes.map(note => <li key={note}>{note}</li>)}
        </ul>
      ) : null}
    </details>
  )
}

function ExampleCard({ example, current, loading, busy, onLoad }: { example: PublicExample; current: boolean; loading: boolean; busy: boolean; onLoad: () => void }) {
  const titleId = useId()
  const counts = Object.entries(example.counts).filter(([, count]) => Number.isFinite(count))
  return (
    <li>
      <article className={`n4iw-card${current ? ' is-current' : ''}`} aria-labelledby={titleId} aria-current={current ? 'true' : undefined}>
        <span className="n4ai-eyebrow">{example.scenario}</span>
        <h3 id={titleId} className="n4iw-card-title">{example.title}</h3>
        <p className="n4iw-card-text">{example.description}</p>
        <p className="n4iw-card-datasets"><span className="n4iw-label">Data</span> {example.datasets.join(' · ') || 'none declared'}</p>
        <ul className="n4iw-counts" aria-label="Contents">
          {counts.map(([key, count]) => <li key={key} className="n4ai-badge"><span className="n4wb-mono">{count}</span>&nbsp;{key}</li>)}
          <li className="n4ai-badge">{bytesText(example.bytes)}</li>
        </ul>
        <div className="n4iw-card-actions">
          <button type="button" className="n4wb-btn n4wb-btn-primary" onClick={onLoad} disabled={busy} aria-describedby={titleId}>
            {loading ? <><span className="n4wb-view-busy" aria-hidden="true" />Opening…</> : current ? 'Open again' : 'Open example'}
          </button>
          <a className="n4wb-btn n4wb-btn-outline" href={`examples/${example.file}`} download={example.file} aria-label={`Download ${example.file}`}>
            Download .n4a
          </a>
        </div>
        <ExampleProvenance example={example} />
      </article>
    </li>
  )
}

function Gallery({ examples, loadingExample, currentExample, onLoadExample }: Pick<InstrumentedWorkspaceProps, 'examples' | 'loadingExample' | 'currentExample' | 'onLoadExample'>) {
  const headingId = useId()
  const [scenario, setScenario] = useState<string | null>(null)
  const scenarios = useMemo(() => [...new Set(examples.map(example => example.scenario))], [examples])
  const shown = scenario === null ? examples : examples.filter(example => example.scenario === scenario)
  return (
    <section className="n4iw-section n4iw-gallery" aria-labelledby={headingId}>
      <div className="n4iw-section-head">
        <h2 id={headingId} className="n4ai-h2">Public examples <span className="n4wb-count">{examples.length}</span></h2>
        <p className="n4ai-caption">Real public datasets packed as .n4a containers. Opening one downloads only that file; it stays in this browser.</p>
      </div>
      {examples.length === 0 ? <p className="n4ai-muted-line">No example is published with this page.</p> : (
        <>
          {scenarios.length > 1 ? (
            <div className="n4iw-filter" role="group" aria-label="Filter examples by scenario">
              <button type="button" className={`n4iw-filter-btn${scenario === null ? ' is-active' : ''}`} aria-pressed={scenario === null} onClick={() => setScenario(null)}>
                All <span className="n4wb-count">{examples.length}</span>
              </button>
              {scenarios.map(name => (
                <button key={name} type="button" className={`n4iw-filter-btn${scenario === name ? ' is-active' : ''}`} aria-pressed={scenario === name} onClick={() => setScenario(name)}>
                  {name} <span className="n4wb-count">{examples.filter(example => example.scenario === name).length}</span>
                </button>
              ))}
            </div>
          ) : null}
          <ul className="n4iw-cards" aria-label="Examples">
            {shown.map(example => (
              <ExampleCard
                key={example.id}
                example={example}
                current={currentExample?.id === example.id}
                loading={loadingExample === example.id}
                busy={loadingExample !== null}
                onLoad={() => onLoadExample(example)}
              />
            ))}
          </ul>
        </>
      )}
    </section>
  )
}

// ------------------------------------------------------------------ explore views

function PreviewSlot({ artifact, state, onRequestPreview }: { artifact: N4aArtifactView; state: N4aPreviewState | undefined; onRequestPreview: (id: string) => void }) {
  const reason = n4aPreviewUnavailableReason(artifact)
  if (reason) {
    return (
      <div className="n4iw-slot">
        <p className="n4wb-note">{reason}</p>
        {artifact.contentDetail ? <p className="n4ai-text">{artifact.contentDetail}</p> : null}
      </div>
    )
  }
  if (!state) {
    return (
      <div className="n4iw-slot">
        <button type="button" className="n4wb-btn n4wb-btn-outline" onClick={() => onRequestPreview(artifact.id)}>Load preview</button>
        <p className="n4ai-caption">The owner reads this artifact only when you ask. Nothing is executed.</p>
      </div>
    )
  }
  if (state.status === 'loading') return <p className="n4ai-loading n4iw-slot"><span className="n4wb-view-busy" aria-hidden="true" />Reading {artifact.id} with its owner…</p>
  if (state.status === 'error') {
    return (
      <div className="n4iw-slot">
        <p className="n4wb-note is-error" role="alert">Preview failed: {state.message}</p>
        <button type="button" className="n4wb-btn n4wb-btn-outline" onClick={() => onRequestPreview(artifact.id)}>Retry preview</button>
      </div>
    )
  }
  if (state.preview.artifactId !== artifact.id) {
    return <p className="n4wb-note is-error" role="alert">Preview refused: it describes artifact <code className="n4ai-id">{state.preview.artifactId}</code>, not the selected artifact.</p>
  }
  return <N4aArtifactPreviewView preview={state.preview} mode="explore" />
}

function ExploreViews({ inspection, previews, onRequestPreview, onInspectArtifact }: Pick<InstrumentedWorkspaceProps, 'previews' | 'onRequestPreview' | 'onInspectArtifact'> & { inspection: N4aInspectionView }) {
  const headingId = useId()
  const panelId = useId()
  const [view, setView] = useState<ViewId | null>(() => VIEWS.find(v => inspection.counts[v.id] > 0)?.id ?? null)
  const [selected, setSelected] = useState<Partial<Record<ViewId, string>>>(() => Object.fromEntries(VIEWS.map(v => [v.id, inspection.artifacts.find(a => a.section === v.id && a.storage === 'embedded')?.id])))
  const inView = (id: ViewId) => inspection.artifacts.filter(artifact => artifact.section === (id as N4aSection))

  // Explicit user choice only: the preview of an embedded, readable artifact is requested once.
  function choose(id: ViewId, artifactId?: string) {
    const artifacts = inView(id)
    const target = artifacts.find(artifact => artifact.id === (artifactId ?? selected[id]))
      ?? artifacts.find(artifact => n4aPreviewUnavailableReason(artifact) === null)
      ?? artifacts[0]
    setView(id)
    if (!target) return
    setSelected(current => ({ ...current, [id]: target.id }))
    if (n4aPreviewUnavailableReason(target) === null && previews[target.id] === undefined) onRequestPreview(target.id)
  }

  const meta = view ? VIEWS.find(entry => entry.id === view)! : null
  const artifacts = view ? inView(view) : []
  const active = view ? artifacts.find(artifact => artifact.id === selected[view]) ?? artifacts[0] : undefined
  return (
    <section className="n4iw-section" aria-labelledby={headingId}>
      <h2 id={headingId} className="n4ai-h2">Explore the container</h2>
      <nav className="n4iw-views" aria-label="Workspace views">
        {VIEWS.map(entry => (
          <button
            key={entry.id}
            type="button"
            className={`n4iw-view-btn${view === entry.id ? ' is-active' : ''}`}
            aria-current={view === entry.id ? 'true' : undefined}
            aria-controls={panelId}
            onClick={() => choose(entry.id)}
          >
            <strong>{entry.label}</strong>
            <span className="n4wb-count">{inspection.counts[entry.id]}</span>
            <span className="n4iw-view-hint">{entry.hint}</span>
          </button>
        ))}
      </nav>
      <div id={panelId} className="n4iw-panel" role="region" aria-label={meta ? meta.label : 'Selected view'}>
        {!meta ? <p className="n4ai-muted-line">Choose a view: its first readable artifact is read by its owner when you click. Nothing is read in advance.</p> : artifacts.length === 0 ? (
          <p className="n4ai-muted-line">This container declares no artifact for {meta.label.toLowerCase()}.</p>
        ) : (
          <>
            <ul className="n4iw-artifacts" aria-label={`${meta.label} artifacts`}>
              {artifacts.map(artifact => (
                <li key={artifact.id}>
                  <button type="button" className={`n4iw-artifact${artifact.id === active?.id ? ' is-active' : ''}`} aria-pressed={artifact.id === active?.id} onClick={() => choose(meta.id, artifact.id)}>
                    <code className="n4ai-id">{artifact.id}</code>
                    <span className="n4ai-caption">{artifact.kind || 'unspecified kind'} · {artifact.owner || 'no owner'}{artifact.storage === 'reference' ? ' · reference only' : ''}</span>
                  </button>
                </li>
              ))}
            </ul>
            {active ? (
              <div className="n4iw-detail">
                <div className="n4iw-detail-head">
                  <code className="n4ai-id">{active.id}</code>
                  <span className="n4ai-badges">
                    {active.storage === 'reference' ? <span className="n4ai-badge is-warning">Reference only</span> : <span className="n4ai-badge">Embedded</span>}
                    <StatusBadge artifact={active} />
                  </span>
                  <button type="button" className="n4wb-btn n4wb-btn-ghost n4iw-inspect" onClick={() => onInspectArtifact(active.id)}>Inspect artifact</button>
                </div>
                <PreviewSlot artifact={active} state={previews[active.id]} onRequestPreview={onRequestPreview} />
              </div>
            ) : null}
          </>
        )}
      </div>
    </section>
  )
}

// ------------------------------------------------------------------ actions

function ActionSource({ action, known, onInspectArtifact }: { action: WorkspaceAction; known: (id: string) => boolean; onInspectArtifact: (id: string) => void }) {
  const ref = (id: string) => known(id)
    ? <button type="button" className="n4ai-id-link" onClick={() => onInspectArtifact(id)} title={`Inspect artifact ${id}`}><code className="n4ai-id">{id}</code></button>
    : <code className="n4ai-id">{id}</code>
  const rows: [string, ReactNode][] = []
  if (action.recipeArtifactId) rows.push(['Recipe', ref(action.recipeArtifactId)])
  if (action.datasetArtifactId) rows.push(['Dataset', ref(action.datasetArtifactId)])
  if (action.entrypoint) rows.push(['Entrypoint', <code className="n4ai-id">{action.entrypoint}</code>])
  if (action.partition) rows.push(['Stored partition', <code className="n4ai-id">{action.partition}</code>])
  rows.push(['Source', <span className="n4ai-wrap">{action.sourceId}</span>])
  return (
    <dl className="n4iw-kv">
      {rows.map(([key, value]) => <div key={key}><dt>{key}</dt><dd>{value}</dd></div>)}
    </dl>
  )
}

function ActionOutput({ state, action, onOpenActionOutput }: { state: InstrumentedWorkspaceProps['actionState']; action: WorkspaceAction | null; onOpenActionOutput: () => void }) {
  const preview = state.preview
  return (
    <div className="n4iw-output">
      <p className="n4wb-note">
        <strong>{state.title ?? (action ? `${KIND_TEXT[action.kind].label} finished` : 'Action finished')}</strong>
        {state.message ? ` ${state.message}` : null}
      </p>
      {action?.kind === 'replay' ? (
        <p className="n4ai-caption">
          Replayed predictions{action.partition ? <> on the stored partition <code className="n4ai-id">{action.partition}</code></> : null}, from the stored fitted state. Nothing was fitted.
        </p>
      ) : null}
      {state.download ? (
        <div className="n4iw-card-actions">
          <a className="n4wb-btn n4wb-btn-primary" href={state.download.url} download={state.download.name}>Download new bundle</a>
          <button type="button" className="n4wb-btn n4wb-btn-outline" onClick={onOpenActionOutput}>Open generated bundle</button>
          <span className="n4ai-caption n4ai-wrap">{state.download.name}</span>
        </div>
      ) : null}
      {preview?.status === 'loading' ? <p className="n4ai-loading"><span className="n4wb-view-busy" aria-hidden="true" />Reading the returned output…</p> : null}
      {preview?.status === 'error' ? <p className="n4wb-note is-error" role="alert">Output preview failed: {preview.message}</p> : null}
      {preview?.status === 'ready' ? <N4aArtifactPreviewView preview={preview.preview} mode="explore" /> : null}
    </div>
  )
}

function Actions({ inspection, actions, actionState, onAction, onCancelAction, onOpenActionOutput, onInspectArtifact }: Pick<InstrumentedWorkspaceProps, 'actions' | 'actionState' | 'onAction' | 'onCancelAction' | 'onOpenActionOutput' | 'onInspectArtifact'> & { inspection: N4aInspectionView }) {
  const headingId = useId()
  const [last, setLast] = useState<WorkspaceAction | null>(null)
  const ids = useMemo(() => new Set(inspection.artifacts.map(artifact => artifact.id)), [inspection])
  const running = actionState.status === 'running'
  const current = last && actions.some(action => action.id === last.id) ? last : null
  return (
    <section className="n4iw-section" aria-labelledby={headingId}>
      <h2 id={headingId} className="n4ai-h2">Run, replay or retrain <span className="n4wb-count">{actions.length}</span></h2>
      {actions.length === 0 ? (
        <p className="n4wb-note">This container has no browser-supported run, replay or retrain action. It can still be inspected; nothing in it is executed here.</p>
      ) : (
        <ul className="n4iw-actions" aria-label="Available actions">
          {actions.map(action => {
            const text = KIND_TEXT[action.kind]
            const isCurrent = current?.id === action.id
            return (
              <li key={action.id} className={`n4iw-action${isCurrent && actionState.status !== 'idle' ? ' is-current' : ''}`}>
                <div className="n4iw-action-head">
                  <span className={`n4ai-badge${action.kind === 'replay' ? '' : ' is-ok'}`}>{text.label}</span>
                  <strong className="n4ai-wrap">{action.label}</strong>
                </div>
                <p className="n4ai-text">{action.description}</p>
                <ActionSource action={action} known={id => ids.has(id)} onInspectArtifact={onInspectArtifact} />
                <p className="n4ai-caption">{text.note}</p>
                <button type="button" className="n4wb-btn n4wb-btn-primary" disabled={running} onClick={() => { setLast(action); onAction(action) }}>
                  {running && isCurrent ? <><span className="n4wb-view-busy" aria-hidden="true" />Working…</> : text.button}
                </button>
              </li>
            )
          })}
        </ul>
      )}
      <div className="n4iw-action-state" aria-live="polite">
        {running ? (
          <div className="n4iw-running">
            <p className="n4ai-loading" role="status"><span className="n4wb-view-busy" aria-hidden="true" />{actionState.title ?? (current ? `${KIND_TEXT[current.kind].label}: ${current.label}` : 'Working')}{actionState.message ? ` · ${actionState.message}` : ''}</p>
            <button type="button" className="n4wb-btn n4wb-btn-outline" onClick={onCancelAction}>Cancel</button>
          </div>
        ) : null}
        {actionState.status === 'error' ? (
          <p className="n4wb-note is-error" role="alert"><strong>{actionState.title ?? 'Action failed'}</strong>{actionState.message ? `: ${actionState.message}` : ''}</p>
        ) : null}
        {actionState.status === 'done' ? <ActionOutput state={actionState} action={current} onOpenActionOutput={onOpenActionOutput} /> : null}
      </div>
    </section>
  )
}

// ------------------------------------------------------------------ root

/**
 * Example gallery plus, once a container is open, direct views and host actions.
 * Every preview, example load and action goes through the parent callbacks.
 */
export function InstrumentedWorkspace(props: InstrumentedWorkspaceProps) {
  const { inspection, currentExample } = props
  const containerKey = inspection ? `${inspection.containerSha256}:${inspection.fileName}` : 'none'
  return (
    <div className="n4wb n4iw">
      <details id="public-example-library" className="n4ai-details n4iw-library" open={props.examplesOpen} onToggle={event => { if (event.currentTarget.open !== props.examplesOpen) props.onExamplesOpenChange(event.currentTarget.open) }}>
        <summary tabIndex={0}>Public examples · {props.examples.length}{inspection ? ' · Choose another example' : ''}</summary>
        <Gallery examples={props.examples} loadingExample={props.loadingExample} currentExample={currentExample} onLoadExample={props.onLoadExample} />
        <p className="n4ai-caption">For a small demonstration with three spectra and a masked target: <button type="button" className="n4wb-btn n4wb-btn-outline" onClick={props.onLoadSynthetic}>Load synthetic example</button></p>
      </details>
      {inspection ? (
        <div key={containerKey} className="n4iw-workspace">
          <header className="n4iw-current">
            <span className="n4ai-eyebrow">{currentExample ? currentExample.scenario : 'Opened container'}</span>
            <strong className="n4iw-current-title">{currentExample ? currentExample.title : inspection.fileName}</strong>
            <span className="n4ai-caption">
              {inspection.fileName} · {plural(inspection.artifacts.length, 'artifact')} · storage verified by Core, execution not evaluated
            </span>
            {currentExample ? <ExampleProvenance example={currentExample} /> : null}
          </header>
          <ExploreViews inspection={inspection} previews={props.previews} onRequestPreview={props.onRequestPreview} onInspectArtifact={props.onInspectArtifact} />
          <Actions
            inspection={inspection}
            actions={props.actions}
            actionState={props.actionState}
            onAction={props.onAction}
            onCancelAction={props.onCancelAction}
            onOpenActionOutput={props.onOpenActionOutput}
            onInspectArtifact={props.onInspectArtifact}
          />
        </div>
      ) : null}
    </div>
  )
}
