import { StrictMode, useEffect, useMemo, useRef, useState } from 'react'
import { createRoot } from 'react-dom/client'
import { N4aInspector, projectN4aInspection, projectN4aPreview, type N4aInspectionView, type N4aPreviewState, type N4aSection } from 'nirs4all-ui/n4aInspector'
import { InstrumentedWorkspace } from './InstrumentedWorkspace'
import type { ActionState, PublicExample, WorkspaceAction } from './workspace-types'
import 'nirs4all-ui/assets/theme.css'
import 'nirs4all-ui/assets/workbench.css'
import 'nirs4all-ui/assets/qualification.css'
import 'nirs4all-ui/assets/dag.css'
import 'nirs4all-ui/assets/viz.css'
import 'nirs4all-ui/assets/chains.css'
import 'nirs4all-ui/assets/n4a-inspector.css'
import './style.css'

function App() {
  const [inspection, setInspection] = useState<N4aInspectionView | null>(null)
  const [phase, setPhase] = useState<'idle' | 'opening' | 'ready' | 'error'>('idle')
  const [error, setError] = useState<string | null>(null)
  const [previews, setPreviews] = useState<Record<string, N4aPreviewState>>({})
  const [rows, setRows] = useState(32)
  const [variant, setVariant] = useState<'explorer' | 'compact'>('explorer')
  const [section, setSection] = useState<N4aSection>('overview')
  const [selectedArtifactId, setSelectedArtifactId] = useState<string | null>(null)
  const [examples, setExamples] = useState<PublicExample[]>([])
  const [loadingExample, setLoadingExample] = useState<string | null>(null)
  const [currentExample, setCurrentExample] = useState<PublicExample | null>(null)
  const [actionState, setActionState] = useState<ActionState>({ status: 'idle' })
  const [dataId, setDataId] = useState('')
  const [sourceId, setSourceId] = useState('spectra')
  const [externalPartition, setExternalPartition] = useState('predict')
  const [attached, setAttached] = useState<{ id: string; label: string }[]>([])
  const [theme, setTheme] = useState(() => window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light')
  const worker = useRef<Worker | null>(null)
  const fileInput = useRef<HTMLInputElement>(null)
  const companionInput = useRef<HTMLInputElement>(null)
  const currentFile = useRef<File | null>(null)
  const companionFile = useRef<File | null>(null)
  const outputFile = useRef<File | null>(null)
  const outputUrl = useRef<string | null>(null)
  const pendingFetch = useRef<AbortController | null>(null)
  const rowsRef = useRef(rows); rowsRef.current = rows
  useEffect(() => { document.documentElement.dataset.theme = theme }, [theme])
  useEffect(() => {
    const controller = new AbortController()
    fetch('./examples/index.json', { signal: controller.signal }).then(response => { if (!response.ok) throw new Error('Public example catalog is unavailable.'); return response.json() }).then(catalog => setExamples(catalog.examples)).catch(cause => { if (!controller.signal.aborted) setError(String(cause.message ?? cause)) })
    return () => { controller.abort(); worker.current?.terminate(); pendingFetch.current?.abort(); if (outputUrl.current) URL.revokeObjectURL(outputUrl.current) }
  }, [])
  function clearOutput() {
    if (outputUrl.current) URL.revokeObjectURL(outputUrl.current)
    outputUrl.current = null; outputFile.current = null; setActionState({ status: 'idle' })
  }
  function close() {
    pendingFetch.current?.abort(); pendingFetch.current = null; setLoadingExample(null)
    worker.current?.terminate(); worker.current = null
    currentFile.current = null; companionFile.current = null
    setInspection(null); setPreviews({}); setError(null); setPhase('idle'); setAttached([]); setDataId(''); setCurrentExample(null); clearOutput()
  }
  function start(file: File, example: PublicExample | null = null, companion: File | null = null) {
    worker.current?.terminate()
    currentFile.current = file; companionFile.current = companion
    setInspection(null); setPreviews({}); setError(null); setPhase('opening'); setAttached([]); setDataId(''); setCurrentExample(example)
    setSection('overview'); setSelectedArtifactId(null)
    const next = new Worker(new URL('./worker.ts', import.meta.url), { type: 'module' })
    worker.current = next
    next.onmessage = ({ data }) => {
      if (worker.current !== next) return
      try {
        if (data.type === 'opened') {
          const view = projectN4aInspection(data.report, file.name)
          setInspection(view); setPhase('ready')
          const datasets = view.artifacts.filter(a => a.owner === 'nirs4all-io' && a.section === 'data' && a.storage === 'embedded')
          setDataId(datasets[0]?.id ?? '')
          const first = datasets[0] ?? view.artifacts.find(a => a.storage === 'embedded' && ['recipe','result','score'].includes(a.kind))
          if (first) { setPreviews({ [first.id]: { status: 'loading' } }); next.postMessage({ type: 'preview', artifactId: first.id, rows: rowsRef.current }) }
          if (companion) next.postMessage({ type: 'attach', file: companion })
        } else if (data.type === 'preview' && data.rows === rowsRef.current) {
          const preview = projectN4aPreview(data.preview)
          setPreviews(current => ({ ...current, [data.artifactId]: { status: 'ready', preview } }))
          setInspection(current => current ? { ...current, artifacts: current.artifacts.map(artifact => artifact.id === data.artifactId ? { ...artifact, contentStatus: preview.status, contentDetail: preview.detail } : artifact) } : current)
        } else if (data.type === 'attached') {
          setAttached(data.artifacts); setDataId(data.artifacts[0]?.id ?? '')
          if (!data.artifacts.length) setError('The companion container has no embedded IO dataset. References are not fetched.')
        } else if (data.type === 'actionDone') {
          const result = data.result
          if (result.archiveBytes) {
            const generated = new File([result.archiveBytes], 'browser-analysis.n4a')
            outputFile.current = generated; outputUrl.current = URL.createObjectURL(generated)
            setActionState({ status: 'done', title: 'Analysis completed', message: result.message, download: { url: outputUrl.current, name: generated.name } })
          } else setActionState({ status: 'done', title: 'Replay completed', message: result.message, preview: { status: 'ready', preview: projectN4aPreview(result.preview) } })
        } else if (data.type === 'error') {
          if (data.operation === 'action') setActionState({ status: 'error', title: 'Action refused or failed', message: data.message })
          else if (data.operation === 'attach') setError(data.message)
          else if (data.artifactId && data.rows === rowsRef.current) setPreviews(current => ({ ...current, [data.artifactId]: { status: 'error', message: data.message } }))
          else if (!data.artifactId) { setError(data.message); setPhase('error'); next.terminate(); worker.current = null }
        }
      } catch (cause) { setError(cause instanceof Error ? cause.message : String(cause)); setPhase('error'); next.terminate(); worker.current = null }
    }
    next.onerror = event => { if (worker.current === next) { setError(event.message || 'The worker stopped.'); setPhase('error'); setActionState({ status: 'error', message: event.message }); next.terminate(); worker.current = null } }
    next.postMessage({ type: 'open', file })
  }
  function open(files: FileList | readonly File[], example: PublicExample | null = null) {
    pendingFetch.current?.abort(); pendingFetch.current = null; setLoadingExample(null); clearOutput()
    if (files.length !== 1) { setError('Select one container at a time.'); return }
    start(files[0]!, example)
  }
  function requestPreview(artifactId: string) {
    if (!worker.current) return
    setPreviews(current => ({ ...current, [artifactId]: { status: 'loading' } }))
    worker.current.postMessage({ type: 'preview', artifactId, rows })
  }
  async function loadExample(example?: PublicExample) {
    pendingFetch.current?.abort()
    const controller = new AbortController(); pendingFetch.current = controller
    setLoadingExample(example?.id ?? 'synthetic'); setError(null)
    try {
      const name = example?.file ?? 'synthetic-signals.n4a'
      const response = await fetch(`./examples/${name}`, { signal: controller.signal })
      if (!response.ok) throw new Error('The example could not be loaded.')
      const blob = await response.blob()
      if (controller.signal.aborted) return
      pendingFetch.current = null; setLoadingExample(null); clearOutput(); start(new File([blob], name), example ?? null)
    } catch (cause) { if (!controller.signal.aborted) { setLoadingExample(null); setError(cause instanceof Error ? cause.message : String(cause)) } }
  }
  const datasets = useMemo(() => [...(inspection?.artifacts.filter(a => a.storage === 'embedded' && a.owner === 'nirs4all-io' && a.section === 'data').map(a => ({ id: a.id, label: a.id })) ?? []), ...attached], [inspection, attached])
  const actions = useMemo<WorkspaceAction[]>(() => {
    if (!inspection || !dataId) return []
    const actions: WorkspaceAction[] = inspection.artifacts.filter(a => a.storage === 'embedded' && a.owner === 'dag-ml' && a.contentType === 'dagml.execution_plan' && a.contentVersion === 1).map(a => ({ id: `run:${a.id}:${dataId}`, label: `Run ${a.id}`, description: `Fit the complete recipe stored in ${a.id} on ${dataId}. Core validates the recipe; DAG-ML owns CV, OOF selection and refit.`, kind: 'run', recipeArtifactId: a.id, datasetArtifactId: dataId, sourceId }))
    const external = dataId.startsWith('companion:')
    const replay = inspection.entrypoints.find(e => e.owner === 'dag-ml' && e.operation === (external ? 'predict-external' : 'predict'))
    if (replay) {
      actions.unshift({ id: 'replay', label: external ? 'Replay on attached prediction data' : 'Replay on heldout test rows', description: 'Core admits the native model profile at execution. Restores fitted state and predicts; no fitting.', kind: 'replay', entrypoint: replay.id, partition: external ? externalPartition : 'test', datasetArtifactId: dataId, sourceId })
      actions.push({ id: 'retrain', label: 'Retrain stored recipe', description: `Create a new fitted model from the archive’s stored recipe and ${dataId}. Requires labelled training rows.`, kind: 'retrain', datasetArtifactId: dataId, sourceId })
    }
    return actions
  }, [inspection, dataId, sourceId, externalPartition])
  async function attachExample(id: string) {
    const example = examples.find(e => e.id === id), target = worker.current
    if (!example || !target) return
    try {
      const response = await fetch(`./examples/${example.file}`)
      if (!response.ok) throw new Error('The companion example could not be loaded.')
      const file = new File([await response.blob()], example.file)
      if (worker.current !== target) return
      companionFile.current = file; setExternalPartition(id === '09-prediction-cohort' ? 'predict' : 'test')
      target.postMessage({ type: 'attach', file })
    } catch (cause) { if (worker.current === target) setError(cause instanceof Error ? cause.message : String(cause)) }
  }
  function onAction(action: WorkspaceAction) {
    if (!worker.current || actionState.status === 'running') return
    clearOutput(); setActionState({ status: 'running', title: action.label, message: 'Running locally in the owner worker. The first action loads the compute engines.' })
    worker.current.postMessage({ type: 'action', action })
  }
  function cancelAction() {
    const file = currentFile.current, companion = companionFile.current
    if (!file) return
    worker.current?.terminate(); worker.current = null
    setActionState({ status: 'idle', message: 'Action cancelled; worker stopped.' }); start(file, currentExample, companion)
  }
  function exportReport() {
    if (!inspection) return
    const url = URL.createObjectURL(new Blob([JSON.stringify({ schema: 'nirs4all.inspection-report.v1', inspection, previews }, null, 2)], { type: 'application/json' }))
    const link = document.createElement('a'); link.href = url; link.download = `${inspection.fileName}.inspection.json`; link.click()
    setTimeout(() => URL.revokeObjectURL(url), 1000)
  }
  return <main className="n4ai-host">
    <div className="n4ai-host-bar"><a href="../">nirs4all</a><span>Container exploration & local execution</span><button type="button" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}>{theme === 'dark' ? 'Light theme' : 'Dark theme'}</button></div>
    <section className="n4ai-host-source" aria-label="Open a local container" onDragOver={event => event.preventDefault()} onDrop={event => { event.preventDefault(); open(event.dataTransfer.files) }}>
      <p>Drop a .n4a file here, or <button type="button" onClick={() => fileInput.current?.click()}>Browse files</button>.</p>
      <input hidden ref={fileInput} aria-label="Choose a .n4a container" type="file" accept=".n4a" onChange={event => { if (event.target.files?.length) open(event.target.files); event.target.value = '' }} />
      <p>Files and computations stay on your device. External artifact references are never fetched.</p>
      <button type="button" onClick={() => loadExample()}>Load synthetic example</button>
      <label>Rows per preview <input aria-label="Rows per preview" type="number" min="1" step="1" value={rows} onChange={event => { const value = Number(event.target.value); if (Number.isSafeInteger(value) && value > 0) { setRows(value); setPreviews({}) } }} /></label>
      {phase === 'opening' ? <button type="button" onClick={close}>Cancel inspection</button> : null}
    </section>
    {error ? <p className="n4wb-note is-error" role="alert">{error}</p> : null}
    {inspection ? <section className="n4ai-host-source" aria-label="Action input data">
      <label>Action dataset <select aria-label="Action dataset" value={dataId} disabled={actionState.status === 'running'} onChange={event => setDataId(event.target.value)}><option value="">Choose embedded or attached data</option>{datasets.map(d => <option key={d.id} value={d.id}>{d.label}</option>)}</select></label>
      <label>Source ID <input aria-label="Source ID" value={sourceId} onChange={event => setSourceId(event.target.value)} /></label>
      <button type="button" disabled={actionState.status === 'running'} onClick={() => companionInput.current?.click()}>Attach data .n4a</button>
      <label>Attach example data <select aria-label="Attach example data" value="" disabled={actionState.status === 'running'} onChange={event => { if (event.target.value) attachExample(event.target.value) }}><option value="">Choose public input</option>{examples.filter(e => ['01-data-share', '09-prediction-cohort'].includes(e.id)).map(e => <option key={e.id} value={e.id}>{e.title}</option>)}</select></label>
      {dataId.startsWith('companion:') ? <label>Replay partition <select aria-label="Replay partition" value={externalPartition} onChange={event => setExternalPartition(event.target.value)}><option value="predict">predict</option><option value="test">test</option><option value="train">train (in-sample)</option></select></label> : null}
      <input hidden type="file" accept=".n4a" aria-label="Attach a dataset container" ref={companionInput} onChange={event => { const file = event.target.files?.[0]; if (file && worker.current) { companionFile.current = file; worker.current.postMessage({ type: 'attach', file }) } event.target.value = '' }} />
      <span>Recipe-only and model-only bundles can use data from a second local container.</span>
    </section> : null}
    <InstrumentedWorkspace key={inspection?.containerSha256 ?? 'empty'} examples={examples} loadingExample={loadingExample} currentExample={currentExample} onLoadExample={loadExample} inspection={inspection} previews={previews} onRequestPreview={requestPreview}
      onInspectArtifact={id => { const a = inspection?.artifacts.find(a => a.id === id); setSelectedArtifactId(id); if (a) setSection(a.section); document.getElementById('container-identity')?.scrollIntoView({ behavior: 'smooth' }) }}
      actions={actions} actionState={actionState} onAction={onAction} onCancelAction={cancelAction} onOpenActionOutput={() => { if (outputFile.current) open([outputFile.current]) }} />
    <div id="container-identity"><N4aInspector inspection={inspection} phase={phase} error={error} previews={previews} variant={variant} section={section} onSectionChange={setSection} selectedArtifactId={selectedArtifactId} onSelectArtifact={setSelectedArtifactId} onRequestPreview={requestPreview} onClose={close} onExportReport={exportReport}
      headerActions={<label>View <select aria-label="View" value={variant} onChange={event => setVariant(event.target.value as 'explorer' | 'compact')}><option value="explorer">Explorer</option><option value="compact">Compact</option></select></label>} /></div>
  </main>
}
createRoot(document.getElementById('root')!).render(<StrictMode><App /></StrictMode>)
