"""Prepare licensed, identity-aligned public inputs through the Datasets API."""

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd
from nirs4all_datasets.dataset import NirsDataset
from nirs4all_datasets.schema import DatasetDescriptor

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--datasets-root", type=Path, required=True)
parser.add_argument("--out-dir", type=Path, required=True)
args = parser.parse_args()
root = args.datasets_root
args.out_dir.mkdir(parents=True, exist_ok=True)
catalog = json.loads((root / "catalog/index.json").read_text())["datasets"]
out = args.out_dir
cases = [
    (
        "walnut",
        "dryad_walnut_moisture_nir_manual",
        ["moisture_content_percent"],
        "split",
    ),
    ("milk", "zenodo_milk_composition_transmittance_nir", ["Fat"], None),
    (
        "soil",
        "zenodo_neospectra_soil_nir_ccby",
        ["oc_usda_c729_w_pct", "clay_tot_usda_a334_w_pct"],
        None,
    ),
]
for short, identifier, targets, split_column in cases:
    descriptor = DatasetDescriptor(**catalog[identifier]["descriptor"])
    assert descriptor.tier.value == "public"
    assert descriptor.governance.license in {"CC0-1.0", "CC-BY-4.0"}
    directory = root / "datasets" / identifier
    dataset = NirsDataset(directory, descriptor)
    source = dataset.sources()[0]
    ids = dataset.sample_ids(source).astype(str)
    assert len(set(ids)) == len(ids)
    y = (
        dataset.y()
        .set_index("sample_id")
        .reindex(ids)[targets]
        .apply(pd.to_numeric)
        .to_numpy(dtype=float)
    )
    metadata = dataset.metadata().set_index("sample_id").reindex(ids)
    x = dataset.x(source)
    valid = np.isfinite(x).all(axis=1) & np.isfinite(y).all(axis=1)
    notes = [
        "Original spectral channels and axis retained; spectra read at the canonical cache float32 precision.",
        "Demonstration analysis, not a reproduction of the source publication benchmark.",
    ]
    if short == "walnut":
        notes += [
            "The source identifier moisture_content_percent is retained verbatim. Values are used as supplied; catalog units are unspecified and no percentage scaling is applied."
        ]
    if short == "soil":
        physical = metadata["id_layer_uuid_txt"].astype(str)
        eligible = np.flatnonzero(valid & ~physical.duplicated().to_numpy())
        indices = eligible[np.linspace(0, len(eligible) - 1, 160, dtype=int)]
        groups = physical.iloc[indices].tolist()
        partitions = [
            "test"
            if int(hashlib.sha256(g.encode()).hexdigest()[:8], 16) % 5 == 0
            else "train"
            for g in groups
        ]
        notes += [
            "160 distinct soil layers sampled evenly from eligible catalog order; first available catalog spectrum per layer, no additional spectral averaging.",
            "Demo holdout by SHA-256(layer ID) modulo 5; not an origin-declared benchmark split.",
        ]
    elif short == "milk":
        eligible = np.flatnonzero(valid)
        indices = eligible[np.linspace(0, len(eligible) - 1, 240, dtype=int)]
        groups = ("cow-" + metadata["Cow_ID"].astype(str)).iloc[indices].tolist()
        partitions = [
            "test"
            if int(hashlib.sha256(g.encode()).hexdigest()[:8], 16) % 5 == 0
            else "train"
            for g in groups
        ]
        notes += [
            "240 source observations sampled evenly from eligible catalog order, retaining the declared Cow_ID.",
            "All measurements of one cow stay together in the holdout and CV folds; demonstration grouping, not a source benchmark reproduction.",
        ]
    else:
        indices = np.flatnonzero(valid)
        groups = ids[indices].tolist()
        labels = metadata[split_column].astype(str).iloc[indices].tolist()
        assert set(labels) <= {"calibration", "prediction", "test"}
        partitions = ["train" if label == "calibration" else "test" for label in labels]
        notes += ["Origin calibration/prediction or test assignment preserved."]
    selected_ids = ids[indices].tolist()
    folds = [
        "fold-" + str(int(hashlib.sha256(g.encode()).hexdigest()[:8], 16) % 3)
        if p == "train"
        else None
        for g, p in zip(groups, partitions)
    ]
    notes += [
        "Three explicit CV folds assigned by SHA-256(physical ID) modulo 3 within training only; selection uses OOF RMSE."
    ]
    source_meta = descriptor.sources[0]
    attributions = {
        "walnut": "Peng, Dan (2021). Spectra of walnut kernel for moisture content measurement. Dryad. doi:10.5061/dryad.xksn02vfp.",
        "milk": "Diaz-Olivares, Jose A.; van Nuenen, Arnout; Gote, Martin J.; Fonseca Diaz, Valeria; Saeys, Wouter; Adriaens, Ines; Aernouts, Ben (2023). Near-infrared spectra dataset of milk composition in transmittance mode. Zenodo. doi:10.5281/zenodo.8263430.",
        "soil": "Sanderman, Jonathan; Partida, Colleen; Safanelli, José Lucas; Mitu, Sadia Mannan; Ge, Yufeng; Murad, Omar; Shepherd, Keith (2024). Near-infrared (NIR) soil spectral library using the NeoSpectra Handheld NIR Analyzer by Si-Ware. Zenodo. doi:10.5281/zenodo.13122321.",
    }
    provenance = {
        "id": identifier,
        "title": descriptor.name,
        "url": next(
            s.locator for s in descriptor.origin_sources if s.access.value == "open"
        ),
        "license": descriptor.governance.license,
        "attribution": descriptor.citation or attributions[short],
        "originalSamples": len(ids),
        "selectedSamples": len(indices),
        "excludedNonfiniteRows": int((~valid).sum()),
        "changes": notes,
        "canonicalFiles": {
            str(p.relative_to(directory)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in (directory / "canonical").rglob("*.parquet")
        },
        "targetUnits": {
            v.name: v.unit for v in descriptor.variables if v.name in targets
        },
    }
    if not provenance["url"].startswith("http"):
        provenance["url"] = "https://doi.org/" + provenance["url"]
    result = {
        "name": descriptor.name,
        "x": x[indices].tolist(),
        "y": y[indices].tolist(),
        "sampleIds": selected_ids,
        "groups": groups,
        "partitions": partitions,
        "foldIds": folds,
        "targetNames": targets,
        "axis": dataset.wavelengths(source).tolist(),
        "unit": source_meta.axis_unit.value,
        "provenance": provenance,
        "notes": notes,
    }
    (out / f"{short}.json").write_text(
        json.dumps(result, allow_nan=False, separators=(",", ":"))
    )
    print(
        short,
        len(indices),
        x.shape[1],
        {p: partitions.count(p) for p in set(partitions)},
        "license",
        provenance["license"],
    )
