import fs from 'node:fs';
import { createHash } from 'node:crypto';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
const web = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const args = process.argv.slice(2);
const option = name => { const at = args.indexOf(name); if (at < 0 || !args[at + 1])
    throw new Error(`Required: ${name}`); return path.resolve(args[at + 1]); };
const core = option('--core-package'), io = option('--io-bindings'), inputsDir = option('--inputs'), outDir = option('--out-dir');
if (fs.existsSync(outDir) && fs.readdirSync(outDir).length)
    throw new Error('Use an empty examples output directory.');
fs.mkdirSync(outDir, { recursive: true });
const out = pathToFileURL(outDir + path.sep);
const load = file => import(pathToFileURL(file));
const [methods, dagMl, estimatorAdapter, { produceN4aNative, predictN4aNative }, { openN4aContainer, writeN4aContainer }, { Dataset }] = await Promise.all([
    load(path.join(web, 'src/engine/wasm/methods/index.js')), load(path.join(web, 'src/engine/wasm/dagml/dag_ml_wasm.js')),
    load(path.join(web, 'src/engine/wasm/dagml/n4m_estimator_controller.mjs')), load(path.join(core, 'src/n4a.js')),
    load(path.join(core, 'src/n4a-storage.js')), load(path.join(io, 'public-dataset.mjs')),
]);
const encode = x => new TextEncoder().encode(JSON.stringify(x));
const hash = b => createHash('sha256').update(b).digest('hex');
const inputs = Object.fromEntries(['walnut', 'milk', 'soil'].map(id => [id, JSON.parse(fs.readFileSync(path.join(inputsDir, `${id}.json`)))]));
const records = Object.fromEntries(Object.entries(inputs).map(([id, x]) => [id, Dataset.fromSources({ spectra: x.x }, { ...x, representations: { spectra: 'signal_1d' }, axisCoordinates: { spectra: { wavelength: x.axis } }, axisUnits: { spectra: { wavelength: x.unit } }, taskType: 'regression' }).record]));
await dagMl.default({ module_or_path: fs.readFileSync(path.join(web, 'src/engine/wasm/dagml/dag_ml_wasm_bg.wasm')) });
await methods.loadModule();
const runtime = { methods, dagMl, estimatorAdapter };
const pls = components => ({ steps: [{ method_id: 'models.pls.pls_regression', role: 'regressor', params: {} }], candidates: components.map(n_components => ({ n_components })) });
const snv = { steps: [{ method_id: 'preprocessing.scatter.snv', role: 'transformer', params: {} }, { method_id: 'models.pls.pls_regression', role: 'regressor', params: {} }], candidates: [{ n_components: 2 }, { n_components: 4 }, { n_components: 6 }] };
const ridge = { steps: [{ method_id: 'preprocessing.scaling.standard_scale', role: 'transformer', params: {} }, { method_id: 'models.regularized.ridge', role: 'regressor', params: { scale_x: false } }], candidates: [{ alpha: 0.1 }, { alpha: 1 }, { alpha: 10 }] };
const runs = {};
for (const [id, dataset, recipe] of [['walnut-pls', 'walnut', pls([2, 4, 6])], ['walnut-snv', 'walnut', snv], ['walnut-ridge', 'walnut', ridge], ['milk-pls', 'milk', pls([2, 4, 6, 8])], ['soil-multitarget', 'soil', pls([2, 4, 6])]]) {
    console.log('TRAIN', id);
    const result = await produceN4aNative(encode(records[dataset]), { ...runtime, sourceId: 'spectra', recipe, containerId: `public-demo:${id}`, runId: `run:public-demo:${id}` });
    const container = await openN4aContainer(result.archiveBytes);
    const manifest = container.view().readability.manifest;
    const members = new Map();
    for (const m of manifest.members)
        members.set(m.path, await container.readMember(m.path));
    container.close();
    const replay = await predictN4aNative(result.archiveBytes, { ...runtime, entrypoint: 'predict', sourceId: 'spectra', partition: 'test', requestId: `test:${id}` });
    fs.writeFileSync(new URL(`${id}.evidence.json`, out), JSON.stringify({ archiveSha256: hash(result.archiveBytes), selection: result.view.training.outcome.execution_bundle.selections, refit: result.view.training.outcome.refit, heldoutRows: replay.sampleIds.length, trainingPerformedOnReplay: false, recipe, methodsVersion: methods.version(), dataset: inputs[dataset].provenance }));
    runs[id] = { ...result, manifest, members, dataset, recipe };
    console.log('DONE', id, result.archiveBytes.length, 'heldout', replay.sampleIds.length);
}
const gallery = [];
async function item(id, title, scenario, description, datasets, bytes, manifest, notes = []) {
    const data = datasets.map(k => inputs[k]);
    const example = { id, title, scenario, description, file: `${id}.n4a`, datasets: data.map(x => x.name), counts: {}, bytes: 0, sources: data.map(x => ({ title: x.provenance.title, url: x.provenance.url, license: x.provenance.license, attribution: x.provenance.attribution })), notes: [...new Set(data.flatMap(x => x.notes).filter(note => id !== '09-prediction-cohort' || !note.startsWith('Three explicit') && !note.startsWith('Origin calibration'))), ...notes, 'Candidate grids are finite demonstration settings; the selected candidate is not a claim of a global optimum.'] };
    const container = await openN4aContainer(bytes), members = [];
    manifest = structuredClone(manifest);
    for (const m of manifest.members)
        members.push({ path: m.path, bytes: await container.readMember(m.path) });
    container.close();
    const path = 'public-example-attribution.json', payload = encode({ title, sources: example.sources, changes: example.notes, attribution: example.sources.map(s => s.attribution).join('\n'), license: example.sources.map(s => s.license).join(', '), url: example.sources.map(s => s.url).join('\n') });
    members.push({ path, bytes: payload });
    manifest.members.push({ path, byte_length: payload.length, sha256: hash(payload) });
    manifest.artifacts.push(artifact('public-example-attribution', 'attachment', 'nirs4all.web-host', 'nirs4all.public-example.provenance', 1, path, payload));
    bytes = (await writeN4aContainer(manifest, members)).archiveBytes;
    example.counts = Object.fromEntries([...new Set(manifest.artifacts.map(a => a.kind))].map(k => [k, manifest.artifacts.filter(a => a.kind === k).length]));
    example.bytes = bytes.length;
    fs.writeFileSync(new URL(example.file, out), bytes);
    const evidenceName = { '03-walnut-analysis': 'walnut-pls', '06-milk-benchmark': 'milk-pls', '07-soil-multitarget': 'soil-multitarget' }[id];
    if (evidenceName) {
        const file = new URL(`${evidenceName}.evidence.json`, out), evidence = JSON.parse(fs.readFileSync(file));
        evidence.producerArchiveSha256 = evidence.archiveSha256;
        delete evidence.archiveSha256;
        evidence.deliveredArchiveSha256 = hash(bytes);
        evidence.deliveredFile = example.file;
        evidence.note = 'Source attribution was appended through Core storage without changing fitted state.';
        fs.writeFileSync(file, JSON.stringify(evidence, null, 2));
    }
    gallery.push(example);
}
function artifact(id, kind, owner, type, version, path, bytes) { return { id, kind, owner, content_type: { id: type, version }, identity: { owner, schema: type, schema_version: version, fingerprint_profile: 'sha256.raw.v1', fingerprint: hash(bytes) }, storage: { kind: 'embedded', root_member: path, member_paths: [path] }, requirements: null }; }
async function compose(id, parts, datasets, { data = true, only, refs = false, recipeOnly = false } = {}) {
    const artifacts = [], members = [], links = [];
    for (const [runId, prefix] of parts) {
        const run = runs[runId];
        const include = a => a.id !== 'training-data' && (!only || only.includes(a.kind)) && (!recipeOnly || a.id === 'recipe' || a.id === 'plan');
        const selected = run.manifest.artifacts.filter(include);
        const ids = new Set(selected.map(a => a.id));
        for (const original of selected) {
            const a = structuredClone(original);
            a.id = prefix + ':' + a.id;
            if (a.requirements && !ids.has(a.requirements.artifact_id))
                a.requirements = null;
            else if (a.requirements)
                a.requirements.artifact_id = prefix + ':' + a.requirements.artifact_id;
            if (a.storage.kind === 'embedded') {
                const paths = a.storage.member_paths;
                a.storage.root_member = prefix + '/' + a.storage.root_member;
                a.storage.member_paths = paths.map(p => prefix + '/' + p);
                for (const p of paths)
                    if (!members.some(m => m.path === prefix + '/' + p))
                        members.push({ path: prefix + '/' + p, bytes: run.members.get(p) });
            }
            artifacts.push(a);
        }
        for (const l of run.manifest.links)
            if (ids.has(l.source_artifact) && ids.has(l.target_artifact))
                links.push({ ...l, id: prefix + ':' + l.id, source_artifact: prefix + ':' + l.source_artifact, target_artifact: prefix + ':' + l.target_artifact });
    }
    for (const dataset of datasets) {
        const bytes = encode(records[dataset]), path = `data/${dataset}.json`;
        const a = artifact(dataset, 'dataset', 'nirs4all-io', records[dataset].schema, records[dataset].schema_version, path, bytes);
        if (data) {
            members.push({ path, bytes });
            artifacts.push(a);
        }
        else if (refs)
            artifacts.push({ ...a, storage: { kind: 'reference' } });
        const provenance = encode(inputs[dataset].provenance), pp = `provenance/${dataset}.json`;
        members.push({ path: pp, bytes: provenance });
        artifacts.push(artifact(`${dataset}:provenance`, 'attachment', 'nirs4all.web-host', 'nirs4all.public-example.provenance', 1, pp, provenance));
    }
    const manifest = { schema: 'nirs4all.n4a.container.v1', schema_version: 1, minimum_reader_version: 1, container_id: `public-demo:${id}`, required_features: [], physical_profile: 'zip-stored.v1', members: members.map(m => ({ path: m.path, byte_length: m.bytes.length, sha256: hash(m.bytes) })), artifacts, links, entrypoints: [] };
    const result = await writeN4aContainer(manifest, members);
    return { bytes: result.archiveBytes, manifest };
}
let c = await compose('01-data-share', [], ['walnut']);
await item('01-data-share', 'Walnut spectra handover', 'Data sharing', '136 spectra, source targets and original calibration / prediction split. No fitted model.', ['walnut'], c.bytes, c.manifest);
c = await compose('02-recipe-library', [['walnut-pls', 'pls'], ['walnut-snv', 'snv'], ['walnut-ridge', 'ridge']], ['walnut'], { data: false, only: ['recipe', 'attachment'], refs: true, recipeOnly: true });
await item('02-recipe-library', 'Three reusable analysis recipes', 'Pipeline sharing', 'PLS, SNV → PLS and scaling → Ridge; complete stored execution plans. Training data is a reference.', ['walnut'], c.bytes, c.manifest, ['Attach 01-data-share to run a stored recipe. No dataset bytes are included.']);
for (const [id, runId, title, scenario, description] of [['03-walnut-analysis', 'walnut-pls', 'Walnut moisture analysis', 'Complete analysis', 'Three PLS variants, three CV folds, OOF selection, full refit and untouched prediction cohort.'], ['06-milk-benchmark', 'milk-pls', 'Milk fat benchmark starter', 'Benchmark', 'Four PLS settings with cow-grouped CV and holdout; stored OOF evidence, scores and a fitted winner. Heldout predictions are replayed on demand.'], ['07-soil-multitarget', 'soil-multitarget', 'Soil carbon + clay campaign', 'Multiple targets', 'One two-output PLS analysis on 160 distinct soil layers, with heldout layers and identity-preserving predictions. Selection uses the owner’s unweighted multi-output RMSE; target-specific scores remain separate.']]) {
    const r = runs[runId];
    await item(id, title, scenario, description, [r.dataset], r.archiveBytes, r.manifest);
}
const deploy = await produceN4aNative(encode(records.walnut), { ...runtime, sourceId: 'spectra', recipe: runs['walnut-pls'].recipe, containerId: 'public-demo:deployment', runId: 'run:public-demo:deployment', embedTrainingRecord: false });
await item('04-deployment-model', 'Fitted model without training spectra', 'Model delivery', 'A portable fitted PLS winner with evaluation evidence; training record omitted. Attach a data bundle for prediction.', ['walnut'], deploy.archiveBytes, deploy.view.manifest, ['Training spectrum bytes are omitted; outcome evidence still contains training IDs, OOF labels/predictions and scores. This is not an anonymized artifact.']);
c = await compose('05-preprocessing-campaign', [['walnut-pls', 'pls'], ['walnut-snv', 'snv'], ['walnut-ridge', 'ridge']], ['walnut'], { only: ['recipe', 'score', 'prediction', 'result', 'run', 'training_evidence', 'attachment'] });
await item('05-preprocessing-campaign', 'Preprocessing comparison campaign', 'Analysis campaign', 'Three independently executed workflows, shared dataset, candidate/fold scores and stored OOF predictions.', ['walnut'], c.bytes, c.manifest, ['No top-level fitted replay entrypoint; select a stored plan to launch a fresh run. Compare scores within this dataset and protocol only.']);
c = await compose('08-results-review', [['walnut-pls', 'walnut'], ['milk-pls', 'milk']], ['walnut', 'milk'], { data: false, only: ['score', 'prediction'], refs: true });
await item('08-results-review', 'Two-study results review', 'Results sharing', 'Stored scores from walnut and milk; prediction-cache inventories are explicitly empty. Source datasets are references; no training spectra or fitted models.', ['walnut', 'milk'], c.bytes, c.manifest, ['Scores across different targets/datasets have different units and must not be ranked together.']);
// A target-free prediction cohort, retaining the original schema and identities.
const predictionInput = inputs.walnut;
const test = predictionInput.partitions.flatMap((p, i) => p === 'test' ? [i] : []);
const predictionRecord = Dataset.fromSources({ spectra: test.map(i => predictionInput.x[i]) }, { name: 'Walnut prediction cohort (unlabelled)', sampleIds: test.map(i => predictionInput.sampleIds[i]), representations: { spectra: 'signal_1d' }, axisCoordinates: { spectra: { wavelength: predictionInput.axis } }, axisUnits: { spectra: { wavelength: predictionInput.unit } }, taskType: 'regression', partitions: test.map(() => 'predict') }).record;
const saved = records.walnut;
records.walnut = predictionRecord;
c = await compose('09-prediction-cohort', [], ['walnut']);
records.walnut = saved;
await item('09-prediction-cohort', 'Incoming unlabelled walnut batch', 'Prediction handover', '34 real source spectra with labels intentionally withheld; attach to the deployment model to replay its fitted state.', ['walnut'], c.bytes, c.manifest, ['Target labels and training folds removed intentionally. All rows are declared predict; no training can run on this record.']);
c = await compose('10-multi-study-campaign', [['walnut-pls', 'walnut-pls'], ['walnut-snv', 'walnut-snv'], ['walnut-ridge', 'walnut-ridge'], ['milk-pls', 'milk-pls'], ['soil-multitarget', 'soil-pls']], ['walnut', 'milk', 'soil'], { only: ['recipe', 'score', 'prediction', 'result', 'run', 'training_evidence', 'attachment'] });
await item('10-multi-study-campaign', 'Three-dataset analysis workspace', 'Multi-study campaign', 'Five real workflows, three datasets, one or two targets per study, varied candidate counts and separate evaluation contexts.', ['walnut', 'milk', 'soil'], c.bytes, c.manifest, ['Study-specific scores stay separate; no cross-dataset winner is asserted. Select a compatible dataset and stored plan for a new run.']);
gallery.sort((a, b) => a.id.localeCompare(b.id));
fs.writeFileSync(new URL('index.json', out), JSON.stringify({ schema: 'nirs4all.inspector.examples.v1', generatedAt: new Date().toISOString(), runtime: 'Core canonical n4a V1 / DAG-ML WASM / Methods WASM', examples: gallery }, null, 2));
console.log('GALLERY', gallery.map(x => [x.id, x.bytes, x.counts]));
