#!/usr/bin/env node
// Build the reusable browser HOST from explicitly selected owner sources/artifacts.
// This local candidate path is separate from the application's pinned runtime.
import fs from 'node:fs'
import path from 'node:path'
import { createHash } from 'node:crypto'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { build } from 'vite'

const here = path.dirname(fileURLToPath(import.meta.url))
const web = path.resolve(here, '..')
const args = process.argv.slice(2)
function option(name) {
  const at = args.indexOf(name)
  if (at < 0 || !args[at + 1]) throw new Error(`Required: ${name}`)
  return path.resolve(args[at + 1])
}
const ui = option('--ui-root'), core = option('--core-package'), io = option('--io-bindings'), dag = option('--dag-bindings')
const native = option('--core-native'), outDir = option('--out-dir')
if (fs.existsSync(outDir) && fs.readdirSync(outDir).length) throw new Error('Use an empty output directory; existing artifacts are never replaced.')
const aliases = [
  { find: 'nirs4all-ui/n4aInspector', replacement: path.join(ui, 'src/n4aInspector/index.ts') },
  { find: 'nirs4all-ui/assets', replacement: path.join(ui, 'assets') },
  { find: /^nirs4all\/actions$/, replacement: path.join(core, 'src/n4a.js') },
  { find: '@nirs4all/io-wasm/inspection', replacement: path.join(io, 'inspection.mjs') },
  { find: 'dag-ml-wasm/artifact-inspector', replacement: path.join(dag, 'artifact_inspector.mjs') },
  { find: 'dag-ml-wasm/n4m-estimator-controller', replacement: path.join(web, 'src/engine/wasm/dagml/n4m_estimator_controller.mjs') },
  { find: '@nirs4all/io-wasm/public-dataset', replacement: path.join(io, 'public-dataset.mjs') },
  { find: /^dag-ml-wasm$/, replacement: path.join(web, 'src/engine/wasm/dagml/dag_ml_wasm.js') },
  { find: /^@nirs4all\/methods$/, replacement: path.join(web, 'src/engine/wasm/methods/index.js') },
]
const nativeBridge = { name: 'explicit-inspector-core-native', enforce: 'pre', resolveId(source, importer) {
  if (source === 'nirs4all') return '\0inspector-selected-core'
  // Select only the host's declared runtime loaders, rather than the aggregate's other products.
  if (source === './index.js' && ['/src/n4a.js', '/src/archive-v2.js'].some(suffix => importer?.endsWith(suffix))) return path.join(web, 'inspector-host/runtime.ts')
  if (source === '../native/nirs4all_core_wasm_native.js' && importer?.endsWith('/src/archive-native.js')) return path.join(native, 'nirs4all_core_wasm_native.js')
}, load(id) {
  if (id === '\0inspector-selected-core') return `export * from ${JSON.stringify(path.join(core, 'src/n4a-inspection.js'))}; export * from ${JSON.stringify(path.join(core, 'src/n4a-storage.js'))};`
} }
await build({
  configFile: false, root: path.join(web, 'inspector-host'), publicDir: false, base: './',
  resolve: { alias: aliases, dedupe: ['react', 'react-dom'] },
  plugins: [nativeBridge], worker: { format: 'es', plugins: () => [nativeBridge] },
  build: { outDir, emptyOutDir: false, target: 'es2022', assetsInlineLimit: 0 },
})
const digest = file => { const bytes = fs.readFileSync(file); return { bytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex') } }
// Deterministic synthetic example, produced by the actual IO and Core owners.
const { Dataset } = await import(pathToFileURL(path.join(io, 'public-dataset.mjs')))
const { writeN4aContainer } = await import(pathToFileURL(path.join(core, 'src/n4a-storage.js')))
const record = Dataset.fromSources({ nir: [[0.2, 0.5, 0.3, 0.8, 0.4], [0.3, 0.6, 0.4, 0.9, 0.5], [0.1, 0.4, 0.2, 0.7, 0.3]] }, {
  name: 'Synthetic signal example', sampleIds: ['sample-a', 'sample-b', 'sample-c'],
  representations: { nir: 'signal_1d' }, axisCoordinates: { nir: { wavelength: [1100, 1300, 1500, 1700, 1900] } },
  axisUnits: { nir: { wavelength: 'nm' } }, targetNames: ['demo target'], y: [1, 2, 3], targetMask: [true, false, true], taskType: 'regression', partitions: ['train', 'train', 'test'],
}).record
const bytes = new TextEncoder().encode(JSON.stringify(record))
const sha = createHash('sha256').update(bytes).digest('hex')
const identity = { owner: 'nirs4all-io', schema: record.schema, schema_version: record.schema_version, fingerprint_profile: 'sha256.raw.v1', fingerprint: sha }
const manifest = { schema: 'nirs4all.n4a.container.v1', schema_version: 1, minimum_reader_version: 1,
  container_id: 'demo:synthetic-signals', required_features: [], physical_profile: 'zip-stored.v1',
  members: [{ path: 'dataset.json', byte_length: bytes.length, sha256: sha }],
  artifacts: [
    { id: 'signals', kind: 'dataset', owner: 'nirs4all-io', content_type: { id: record.schema, version: record.schema_version }, identity, storage: { kind: 'embedded', root_member: 'dataset.json', member_paths: ['dataset.json'] }, requirements: null },
    { id: 'external-example', kind: 'dataset', owner: 'nirs4all-io', content_type: { id: record.schema, version: record.schema_version }, identity: { ...identity, fingerprint_profile: 'demo.reference.v1', fingerprint: 'synthetic-external-reference' }, storage: { kind: 'reference' }, requirements: null },
  ], links: [], entrypoints: [],
}
const example = await writeN4aContainer(manifest, [{ path: 'dataset.json', bytes }])
fs.mkdirSync(path.join(outDir, 'examples'), { recursive: true })
fs.writeFileSync(path.join(outDir, 'examples/synthetic-signals.n4a'), example.archiveBytes)
const exampleAt = args.indexOf('--examples')
if (exampleAt >= 0) {
  const source = path.resolve(args[exampleAt + 1])
  if (!fs.existsSync(path.join(source, 'index.json'))) throw new Error('Public examples must include their provenance catalog.')
  fs.cpSync(source, path.join(outDir, 'examples'), { recursive: true })
}
const legalSources = [
  ['ui', ui], ['core', path.resolve(native, '..')], ['dag', path.resolve(dag, '../..')], ['io', path.resolve(io, '../..')],
  ['methods', path.join(web, 'src/engine/wasm/methods')],
  ['dag-runtime', path.join(web, 'src/engine/wasm/dagml')],
  ['react', path.join(web, 'node_modules/react')], ['react-dom', path.join(web, 'node_modules/react-dom')], ['scheduler', path.join(web, 'node_modules/scheduler')],
]
for (const [name, source] of legalSources) {
  const destination = path.join(outDir, 'legal', name)
  fs.mkdirSync(destination, { recursive: true })
  for (const entry of ['LICENSE', 'LICENSES', 'LICENSE-CeCILL-2.1', 'LICENSING.md', 'THIRD_PARTY_NOTICES.md', 'THIRD_PARTY_LICENSES.md', 'NOTICE.md', 'COPY_PROVENANCE.md', 'PROVENANCE.json']) {
    if (fs.existsSync(path.join(source, entry))) fs.cpSync(path.join(source, entry), path.join(destination, entry), { recursive: true })
  }
}
const nativeFiles = ['nirs4all_core_wasm_native.js', 'nirs4all_core_wasm_native_bg.wasm']
const sourceFiles = [path.join(core, 'src/n4a-inspection.js'), path.join(core, 'src/n4a-storage.js'), path.join(core, 'src/n4a-common.js'), path.join(core, 'src/archive-native.js'), path.join(core, 'src/n4a.js'), path.join(core, 'src/archive-v2.js'), path.join(io, 'inspection.mjs'), path.join(io, 'public-dataset.mjs'), path.join(dag, 'artifact_inspector.mjs')]
sourceFiles.push(...['src/n4aInspector/N4aInspector.tsx', 'src/n4aInspector/model.ts', 'src/n4aInspector/types.ts', 'assets/n4a-inspector.css'].map(file => path.join(ui, file)))
sourceFiles.push(path.join(ui, 'src/n4aInspector/dagEvidence.ts'))
sourceFiles.push(...['inspector-host/main.tsx', 'inspector-host/worker.ts', 'inspector-host/runtime.ts', 'inspector-host/InstrumentedWorkspace.tsx', 'inspector-host/workspace-types.ts', 'inspector-host/workspace.css', 'src/lib/n4a-host-contract.ts', 'src/lib/n4a-inspection-port.ts'].map(file => path.join(web, file)))
const outputs = {}
function inventory(directory, prefix = '') {
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    const relative = prefix + entry.name, file = path.join(directory, entry.name)
    if (entry.isDirectory()) inventory(file, relative + '/')
    else outputs[relative] = digest(file)
  }
}
inventory(outDir)
fs.writeFileSync(path.join(outDir, 'inspection-build.json'), JSON.stringify({
  schema: 'nirs4all.inspector-local-build.v1', sourceKind: 'explicit-local-working-trees',
  note: 'Local unpublished source candidate; the native bridge is the explicitly selected existing artifact. This does not claim a native rebuild or a registry release.',
  sources: Object.fromEntries(sourceFiles.map(file => [file, digest(file)])),
  native: Object.fromEntries(nativeFiles.map(file => [file, digest(path.join(native, file))])), outputs,
  executionRuntimes: Object.fromEntries(['dagml/dag_ml_wasm.js', 'dagml/dag_ml_wasm_bg.wasm', 'dagml/n4m_estimator_controller.mjs', 'methods/index.js', 'methods/estimatorRoles.js', 'methods/ffi.js', 'methods/n4m.js', 'methods/n4m.wasm'].map(file => [file, digest(path.join(web, 'src/engine/wasm', file))])),
}, null, 2) + '\n')
console.log(`Inspector host built: ${outDir}`)
