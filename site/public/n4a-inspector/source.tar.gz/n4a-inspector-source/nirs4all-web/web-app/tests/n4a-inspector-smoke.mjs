import assert from 'node:assert/strict'
import fs from 'node:fs/promises'
import path from 'node:path'
import { chromium } from 'playwright-core'

const url = process.env.N4A_INSPECTOR_URL ?? new URL('n4a-inspector/index.html', process.env.SMOKE_URL ?? 'http://localhost:4173/').href
const browser = await chromium.launch({ executablePath: process.env.CHROME ?? '/usr/bin/google-chrome', headless: true, args: ['--no-sandbox'] })
const errors = [], external = []
try {
  const page = await browser.newPage({ viewport: { width: 1280, height: 900 } })
  page.on('pageerror', error => errors.push(error.message))
  page.on('request', request => { if (new URL(request.url()).origin !== new URL(url).origin) external.push(request.url()) })
  await page.goto(url)
  await page.getByRole('button', { name: 'Load synthetic example' }).click()
  await page.getByText('demo:synthetic-signals', { exact: true }).waitFor()
  assert.match(await page.locator('body').innerText(), /Storage verified/)
  const identity = page.locator('#container-identity')
  const sections = identity.getByRole('navigation', { name: 'Container sections' })
  await sections.getByRole('button', { name: /^Data/ }).click()
  if (await identity.getByRole('button', { name: 'Load preview', exact: true }).count()) await identity.getByRole('button', { name: 'Load preview', exact: true }).click()
  await identity.getByText('Synthetic signal example', { exact: true }).waitFor()
  const samples = identity.getByRole('table', { name: /Sample identities and declared partitions/ })
  assert.equal(await samples.getByRole('row').count(), 4)
  assert.match(await samples.getByRole('row').filter({ hasText: 'sample-b' }).innerText(), /not available/)
  await identity.getByRole('list', { name: 'Data artifacts' }).getByRole('button', { name: /external-example/ }).click()
  assert.equal(await identity.getByRole('button', { name: 'Load preview', exact: true }).count(), 0)
  assert.match(await page.locator('body').innerText(), /Reference only/)
  await sections.getByRole('button', { name: /^Files & metadata/ }).click()
  await page.getByLabel('Original manifest text').waitFor({ state: 'attached' })
  const downloadPromise = page.waitForEvent('download')
  await page.getByRole('button', { name: 'Export report' }).click()
  const download = await downloadPromise
  const report = JSON.parse(await fs.readFile(await download.path(), 'utf8'))
  assert.equal(report.schema, 'nirs4all.inspection-report.v1')
  assert.equal(report.inspection.executability, 'not_evaluated')
  assert.match(report.inspection.containerSha256, /^[0-9a-f]{64}$/)
  assert.equal(report.inspection.artifacts.find(artifact => artifact.id === 'external-example').storage, 'reference')
  await page.getByLabel('View', { exact: true }).selectOption('compact')
  assert.match(await page.locator('body').innerText(), /synthetic-signals.n4a/)
  await page.getByLabel('View', { exact: true }).selectOption('explorer')
  await sections.getByRole('button', { name: /^Data/ }).click()
  await page.getByRole('button', { name: 'Dark theme' }).click()
  assert.equal(await page.locator('html').getAttribute('data-theme'), 'dark')
  if (process.env.N4A_INSPECTOR_SHOTS) {
    await fs.mkdir(process.env.N4A_INSPECTOR_SHOTS, { recursive: true })
    await page.screenshot({ path: path.join(process.env.N4A_INSPECTOR_SHOTS, 'inspector-desktop-dark.png'), fullPage: true })
  }
  for (const width of [390, 320]) {
    await page.setViewportSize({ width, height: 844 })
    const dimensions = await page.evaluate(() => ({ actual: document.documentElement.scrollWidth, viewport: innerWidth }))
    assert.ok(dimensions.actual <= dimensions.viewport, `Horizontal overflow at ${width}px: ${JSON.stringify(dimensions)}`)
  }
  if (process.env.N4A_INSPECTOR_SHOTS) await page.screenshot({ path: path.join(process.env.N4A_INSPECTOR_SHOTS, 'inspector-mobile.png'), fullPage: true })
  if (process.env.N4A_INSPECTOR_MIXED_FIXTURE) {
    await page.setViewportSize({ width: 1280, height: 900 })
    await page.getByLabel('Choose a .n4a container', {exact:true}).setInputFiles(process.env.N4A_INSPECTOR_MIXED_FIXTURE)
    await page.getByText('container:owner.qualification', { exact: true }).waitFor()
    for (const section of ['Pipelines', 'Results', 'Models']) {
      await page.getByRole('navigation', { name: 'Container sections' }).getByRole('button', { name: new RegExp(`^${section}`) }).click()
      if (await identity.getByRole('button', { name: 'Load preview', exact: true }).count()) await identity.getByRole('button', { name: 'Load preview', exact: true }).click()
      await identity.locator('.n4ai-preview .n4ai-text').waitFor()
      assert.match(await identity.locator('.n4ai-preview').innerText(), /not evaluated/i)
    }
    console.log('Mixed owner fixture: stored graph, score contexts and fitted-model package preview passed.')
  }
  await page.getByLabel('Choose a .n4a container', {exact:true}).setInputFiles({ name: 'corrupt.n4a', mimeType: 'application/octet-stream', buffer: Buffer.from('invalid container') })
  await page.getByRole('alert').first().waitFor()
  assert.equal(await page.getByRole('navigation', { name: 'Container sections' }).count(), 0)
  await page.getByRole('button', { name: 'Load synthetic example' }).click()
  await page.getByText('demo:synthetic-signals', { exact: true }).waitFor()
  assert.deepEqual(errors, [])
  assert.deepEqual(external, [], 'Inspection must not contact an external origin')
  console.log('N4a Inspector browser smoke passed: local opening, owner preview, target mask, references, manifest, report export, compact, dark/mobile, corruption and reopen.')
} finally { await browser.close() }
