// Browser gate for the instrumented inspector: real public examples and owner actions.
import assert from 'node:assert/strict'
import fs from 'node:fs/promises'
import path from 'node:path'
import { chromium } from 'playwright-core'
const url = process.env.N4A_INSPECTOR_URL
if (!url) throw new Error('Set N4A_INSPECTOR_URL to the built inspector host.')
const browser = await chromium.launch({ executablePath: process.env.CHROME_PATH ?? '/usr/bin/google-chrome', headless: true, args: ['--no-sandbox'] })
const page = await browser.newPage({ viewport: { width: 1440, height: 1000 }, acceptDownloads: true })
const errors = [], outside = []
page.on('pageerror', error => errors.push(error.message))
page.on('request', request => { if (/^https?:/.test(request.url()) && new URL(request.url()).origin !== new URL(url).origin) outside.push(request.url()) })
page.setDefaultTimeout(30000)
const catalog = await (await page.request.get(new URL('examples/index.json', url).href)).json()
assert.equal(catalog.examples.length, 10)
async function open(id) {
  await page.goto(url)
  const example = catalog.examples.find(e => e.id === id)
  const card = page.locator('.n4iw-card').filter({ has: page.getByText(example.title, { exact: true }) })
  await card.getByRole('button', { name: 'Open example', exact: true }).click()
  await page.getByRole('navigation', { name: 'Workspace views' }).waitFor()
  assert.match(await page.locator('.n4iw-current').innerText(), new RegExp(example.title.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')))
  assert.equal(await page.locator('[role=alert]').count(), 0, id)
  return example
}
async function view(name) { await page.getByRole('navigation', { name: 'Workspace views' }).getByRole('button', { name: new RegExp(`^${name}`) }).click() }
async function actionDone(title) {
  await page.waitForFunction(title => document.querySelector('.n4iw-action-state')?.textContent.includes(title) || document.querySelector('.n4iw-action-state [role=alert]'), title, { timeout: 120000 })
  assert.equal(await page.locator('.n4iw-action-state [role=alert]').count(), 0, await page.locator('.n4iw-action-state').innerText())
}
try {
  for (const example of catalog.examples) { await open(example.id); console.log('OPEN', example.id, example.bytes, example.counts) }
  await open('03-walnut-analysis')
  await page.locator('.n4iw-panel').getByText(/Horizontal axis:.*nm.*860 positions/).waitFor()
  assert.ok(await page.locator('.n4iw-panel svg').count() > 0)
  await view('Pipeline graph'); await page.locator('.n4iw-panel').getByText(/Graph as text/).waitFor()
  await view('Results')
  await page.locator('.n4iw-artifact').filter({ has: page.locator('code').filter({ hasText: /^result$/ }) }).click()
  await page.locator('.n4iw-panel').getByText('Predicted vs observed', { exact: true }).first().waitFor()
  assert.match(await page.locator('.n4iw-panel').innerText(), /validation.*cv avg/)
  await page.getByRole('button', { name: 'Replay', exact: true }).click(); await actionDone('Replay completed')
  assert.match(await page.locator('.n4iw-action-state').innerText(), /Replayed 34 samples.*no fit/)
  await page.locator('.n4iw-action-state').getByText('Predicted vs observed', { exact: true }).first().waitFor()
  console.log('REPLAY', '34 heldout rows, parity component and identity-labelled table')
  await page.getByRole('button', { name: 'Run in browser', exact: true }).first().click(); await actionDone('Analysis completed')
  const downloadPromise = page.waitForEvent('download')
  await page.getByRole('link', { name: 'Download new bundle', exact: true }).click()
  const download = await downloadPromise
  assert.match(download.suggestedFilename(), /\.n4a$/)
  await page.getByRole('button', { name: 'Open generated bundle', exact: true }).click()
  await page.locator('.n4iw-current').getByText('browser-analysis.n4a', { exact: true }).waitFor()
  console.log('RUN', 'new owner-produced bundle downloaded and reopened')
  await open('04-deployment-model')
  await page.getByLabel('Attach example data', { exact: true }).selectOption('09-prediction-cohort')
  await page.waitForFunction(() => document.querySelector('[aria-label="Action dataset"]')?.value.startsWith('companion:'))
  await page.getByRole('button', { name: 'Replay', exact: true }).click(); await actionDone('Replay completed')
  assert.match(await page.locator('.n4iw-action-state').innerText(), /Replayed 34 samples.*no fit/)
  await page.locator('.n4iw-action-state').getByText(/Tables.*Replay predictions/).click()
  assert.equal(await page.locator('.n4iw-action-state table tbody tr').count(), 34)
  console.log('EXTERNAL REPLAY', 'model-only + target-free cohort, 34 rows')
  await open('02-recipe-library')
  await page.getByLabel('Attach example data', { exact: true }).selectOption('01-data-share')
  await page.getByRole('button', { name: 'Run in browser', exact: true }).first().waitFor()
  await page.getByRole('button', { name: 'Run in browser', exact: true }).first().click(); await actionDone('Analysis completed')
  console.log('RECIPE RUN', 'stored recipe-only bundle + second dataset container')
  await open('07-soil-multitarget'); await view('Results')
  await page.locator('.n4iw-artifact').filter({ has: page.locator('code').filter({ hasText: /^result$/ }) }).click()
  await page.locator('.n4iw-panel').getByText('Predicted vs observed', { exact: true }).first().waitFor()
  const text = await page.locator('.n4iw-panel').innerText(); assert.match(text, /oc_usda_c729_w_pct/); assert.match(text, /clay_tot_usda_a334_w_pct/)
  for (const width of [390, 320]) {
    await page.setViewportSize({ width, height: 844 })
    await page.waitForTimeout(100)
    assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1), `horizontal overflow at ${width}`)
  }
  await page.getByRole('button', { name: /Dark theme|Light theme/ }).click()
  if (process.env.SCREENSHOTS_DIR) { await fs.mkdir(process.env.SCREENSHOTS_DIR, { recursive: true }); await page.screenshot({ path: path.join(process.env.SCREENSHOTS_DIR, 'workspace-mobile.png') }); await page.setViewportSize({ width: 1440, height: 1000 }); await page.screenshot({ path: path.join(process.env.SCREENSHOTS_DIR, 'workspace-desktop.png') }) }
  assert.deepEqual(errors, []); assert.deepEqual(outside, [])
  console.log('PASS', '10 examples; spectra, graph, result charts; run and two replay routes; multi-target; mobile; no outside-origin requests')
} finally { await browser.close() }
