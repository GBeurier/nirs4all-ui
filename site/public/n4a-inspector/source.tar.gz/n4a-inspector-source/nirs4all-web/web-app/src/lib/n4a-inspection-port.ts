import { N4A_FORMAT, N4A_VERSION, WEB_HOST } from './n4a-host-contract'

/** Passive metadata preview of this host's payload; no typed-array or model restoration. */
export function inspectWebHostBundle(bytes: Uint8Array, artifact: { id: string }) {
  const payload = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(bytes))
  if (payload.format !== N4A_FORMAT || payload.version !== N4A_VERSION) throw new Error('Unsupported Web host payload format or version.')
  const fields = ['name', 'createdAt', 'taskType', 'targetName', 'engine', 'scoreMetric', 'containsTrainingRows']
    .filter(key => payload[key] !== undefined).map(key => ({ label: key, value: String(payload[key]) }))
  const rows: (string | number | boolean | null)[][] = []
  for (const [scope, metrics] of Object.entries(payload.metrics ?? {})) {
    if (metrics && typeof metrics === 'object') for (const [metric, value] of Object.entries(metrics)) {
      if (value === null || typeof value === 'number') rows.push([scope, metric, value])
    }
  }
  if (payload.model?.dsl !== undefined) fields.push({ label: 'Stored pipeline', value: JSON.stringify(payload.model.dsl) })
  return { artifactId: artifact.id, kind: 'model' as const, title: String(payload.name ?? artifact.id), status: 'not_evaluated' as const,
    detail: 'Recorded Web-host metadata only. Scores retain their stored scope. Fitted states and typed arrays are not restored; scientific validity and execution admission are not assessed.',
    fields, tables: rows.length ? [{ title: 'Stored Web-host scores', columns: ['Scope', 'Metric', 'Value'], rows, totalRows: rows.length }] : [] }
}
export const webHostInspectionPort = { owner: WEB_HOST.owner, contentType: WEB_HOST.bundleContentType, version: WEB_HOST.contentTypeVersion, inspect: inspectWebHostBundle }
