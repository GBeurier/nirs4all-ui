/** The existing Web-host payload and Core-container identities, independent of execution. */
export const N4A_FORMAT = 'nirs4all-web/n4a'
/** v3 stores typed arrays as exact little-endian bytes. */
export const N4A_VERSION = 3
export const WEB_HOST = {
  owner: 'nirs4all.web-host',
  feature: 'nirs4all-web-host@1',
  entrypointId: 'host-predict',
  operation: 'host.predict',
  bundlePath: 'host/bundle.json',
  bundleContentType: 'nirs4all.web-host.bundle',
  contentTypeVersion: 1,
  fingerprintProfile: 'sha256.raw.v1',
} as const
