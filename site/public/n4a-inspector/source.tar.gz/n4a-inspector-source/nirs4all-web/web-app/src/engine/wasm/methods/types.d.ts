/** Float row-major matrix view passed to nirs4all-methods. */
export interface Matrix {
    /** Row-major data buffer. Length must be `rows * cols`. */
    data: Float64Array;
    rows: number;
    cols: number;
}
/** Mirror of the C enum n4m_status_t (cpp/include/n4m/n4m.h). */
export declare enum Status {
    OK = 0,
    ERR_INVALID_ARGUMENT = 1,
    ERR_NULL_POINTER = 2,
    ERR_SHAPE_MISMATCH = 3,
    ERR_DTYPE_MISMATCH = 4,
    ERR_STRIDE_INVALID = 5,
    ERR_NOT_FITTED = 6,
    ERR_NUMERICAL_FAILURE = 7,
    ERR_CONVERGENCE_FAILED = 8,
    ERR_OUT_OF_MEMORY = 9,
    ERR_UNSUPPORTED = 10,
    ERR_NOT_IMPLEMENTED = 11,
    ERR_ABI_MISMATCH = 12,
    ERR_IO = 13,
    ERR_CORRUPT_BUFFER = 14,
    ERR_VERSION_INCOMPATIBLE = 15,
    ERR_BACKEND_UNAVAILABLE = 16,
    ERR_CANCELLED = 17,
    ERR_INTERNAL = 255
}
/** Mirror of n4m_dtype_t (cpp/include/n4m/n4m.h §2). */
export declare enum Dtype {
    UNKNOWN = 0,
    F64 = 1,
    F32 = 2,
    I32 = 3,
    I64 = 4
}
/** Mirror of n4m_algorithm_t. Values must match cpp/include/n4m/n4m.h. */
export declare enum Algorithm {
    PLS_REGRESSION = 0,
    PLS_CANONICAL = 1,
    PLS_SVD = 2,
    PLS_DA = 3,
    OPLS = 4,
    OPLS_DA = 5,
    SPARSE_PLS = 6,
    MB_PLS = 7,
    LW_PLS = 8,
    AOM_PLS = 9,
    PCR = 10,
    IMPORTED_LINEAR_PREDICTOR = 11
}
/** Mirror of n4m_solver_t. */
export declare enum Solver {
    NIPALS = 0,
    SIMPLS = 1,
    ORTHOGONAL_SCORES = 2,
    KERNEL_ALGORITHM = 3,
    WIDE_KERNEL = 4,
    SVD = 5,
    POWER = 6,
    RANDOMIZED_SVD = 7
}
/** Mirror of n4m_model_array_t (n4m_model_get_array tags). */
export declare enum ModelArray {
    COEFFICIENTS = 0,
    INTERCEPT = 1,
    X_MEAN = 2,
    X_SCALE = 3,
    Y_MEAN = 4,
    Y_SCALE = 5,
    WEIGHTS_W = 6,
    LOADINGS_P = 7,
    Y_LOADINGS_Q = 8,
    ROTATIONS_R = 9,
    SCORES_T = 10,
    Y_SCORES_U = 11,
    /** ABI 2.20: (1, 1) X-Y cross-covariance resolution of the components. */
    COMPONENT_RESOLUTION = 12,
    /** ABI 2.20: (1, n_components), 1 for a numerically unresolved component. */
    UNRESOLVED_COMPONENTS = 13
}
/** Mirror of n4m_deflation_t. */
export declare enum Deflation {
    REGRESSION = 0,
    CANONICAL = 1,
    X_ONLY = 2,
    XY = 3,
    ORTHOGONAL = 4
}
export declare class N4mError extends Error {
    readonly status: number;
    constructor(status: number, message: string);
}
