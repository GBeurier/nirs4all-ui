export interface InspectionArtifact { id: string; content_type: { id: string; version: number }; }
export function inspectDatasetRecord(bytes: Uint8Array, artifact: InspectionArtifact, options?: { maxRows?: number }): {
  artifactId: string; kind: 'dataset'; title: string; status: 'validated'; detail: string;
  fields: { label: string; value: string }[];
  tables: { title: string; columns: string[]; rows: (string | number | boolean | null)[][]; totalRows: number }[];
  spectra: { title: string; axis: number[]; axisUnit: string; axisLabel: string; yLabel: string; totalSamples: number; series: { id: string; label: string; values: (number | null)[] }[] }[];
};
export const datasetInspectionPorts: { owner: 'nirs4all-io'; contentType: string; version: number; inspect: typeof inspectDatasetRecord }[];
