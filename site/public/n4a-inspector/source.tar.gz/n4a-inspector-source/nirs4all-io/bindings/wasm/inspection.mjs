// SPDX-License-Identifier: CeCILL-2.1 OR AGPL-3.0-or-later
import { normalizeDataset } from './public-dataset.mjs';

/** Read-only IO record preview. No inference, fitting, imputation or partitioning. */
export function inspectDatasetRecord(bytes, artifact, options = {}) {
  const maxRows = options.maxRows ?? 32;
  if (!Number.isSafeInteger(maxRows) || maxRows < 1) throw new TypeError('Preview maxRows must be a positive integer.');
  const raw = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(bytes));
  if (raw.schema !== artifact.content_type.id || raw.schema_version !== artifact.content_type.version) {
    throw new TypeError('Dataset payload schema differs from its declared content type.');
  }
  const record = normalizeDataset(raw), ds = record.dataset;
  const sampleIds = ds.sample_ids, count = Math.min(maxRows, sampleIds.length);
  const targetNames = ds.target_names ?? [];
  const valueAt = (array, i) => array?.values[i] ?? null;
  const targetAt = i => {
    const values = ds.y === null ? [] : Array.isArray(ds.y.values[i]) ? ds.y.values[i] : [ds.y.values[i]];
    const mask = ds.target_mask?.values[i];
    return targetNames.map((_, j) => (Array.isArray(mask) ? mask[j] : mask) === false ? null : values[j] ?? null);
  };
  const tables = [{
    title: 'Sample identities and declared partitions',
    columns: ['Sample ID', 'Origin ID', 'Partition', 'Group', 'Fold', ...targetNames.map(name => `Target: ${name}`)],
    rows: sampleIds.slice(0, count).map((id, i) => [id, record.origin_ids[i], valueAt(ds.partitions, i), valueAt(ds.groups, i), record.fold_ids[i], ...targetAt(i)]),
    totalRows: sampleIds.length,
  }];
  const spectra = [];
  const fields = [
    { label: 'Samples', value: String(sampleIds.length) },
    { label: 'Sources', value: String(ds.sources.length) },
    { label: 'Task', value: ds.task_type ?? 'Not declared' },
    { label: 'Targets', value: targetNames.join(', ') || 'None declared' },
    { label: 'Source alignment', value: ds.source_alignment ?? 'strict' },
  ];
  for (const source of ds.sources) {
    const isRagged = source.source_kind === 'ragged_series';
    fields.push({ label: `Source: ${source.name}`, value: `${source.representation_id} · ${source.array.dtype} · ${isRagged ? 'ragged · ' : ''}${source.array.shape.join(' × ')}` });
    fields.push({ label: `${source.name}: axes`, value: JSON.stringify(isRagged ? { axes: source.axes, time_unit: source.time_unit, channel_names: source.channel_names } : { axes: source.axes, units: source.axis_units, coordinates: source.axis_coordinates }) });
    // Only actual 1-D signals are drawn as spectra. Other modalities keep their shape/axis metadata.
    if (!isRagged && source.representation_id === 'signal_1d' && source.array.shape.length === 2) {
      const axisName = source.axes[1];
      const coordinates = source.axis_coordinates[axisName];
      const numericAxis = Array.isArray(coordinates) && coordinates.every(value => typeof value === 'number' && Number.isFinite(value));
      spectra.push({
        title: source.name,
        axis: numericAxis ? coordinates : Array.from({ length: source.array.shape[1] }, (_, i) => i),
        axisUnit: numericAxis ? source.axis_units[axisName] ?? '' : '',
        axisLabel: numericAxis ? axisName : 'Channel index (axis coordinates not declared)',
        yLabel: source.name,
        totalSamples: sampleIds.length,
        series: sampleIds.slice(0, count).map((id, i) => ({
          id, label: String(ds.partitions.values[i]),
          values: source.array.values[i].map(value => source.presence_mask.values[i] === false ? null : value),
        })),
      });
    } else if (!isRagged && source.array.shape.length === 2) {
      tables.push({ title: source.name, columns: ['Sample ID', ...(source.feature_names ?? Array.from({ length: source.array.shape[1] }, (_, i) => `Column ${i}`))],
        rows: sampleIds.slice(0, count).map((id, i) => [id, ...source.array.values[i].map(value => source.presence_mask.values[i] === false ? null : value)]), totalRows: sampleIds.length });
    }
  }
  return {
    artifactId: artifact.id, kind: 'dataset', title: ds.name || artifact.id, status: 'validated',
    detail: 'IO record structure, masks and sample alignment validated. Manifest semantic fingerprints, cross-artifact links and execution were not assessed. Preview rows are the first stored samples; no statistical sampling is performed.',
    fields, tables, spectra,
  };
}

export const datasetInspectionPorts = [1, 2].map(version => ({
  owner: 'nirs4all-io', contentType: `nirs4all.dataset.v${version}`, version, inspect: inspectDatasetRecord,
}));
