// Canonical V1 `.n4a` L2 actions for JavaScript/WASM.
//
// Core's Rust/WASM bridge validates containers and records, asks IO for the
// dataset identities and DAG-ML for the training/replay requests, and seals the
// result. DAG-ML's WASM executor runs CV/selection/refit/replay and Methods
// fits or restores every estimator. This module only passes exact strings and
// typed arrays between them: it parses no recipe, package or record, hashes
// nothing per task and has no fallback fit.
//
// The handoff to the executor is private to this file. No exported function
// accepts an envelope, matrix, request or package.
import { loadArchiveV2Native } from './archive-v2.js';
import { loadDagMlWasm, loadMethodsWasm } from './index.js';

import { requireValue, bytesOf, text, objectOf, owner, budgetOf, admit } from './n4a-common.js';

async function runtime(options) {
  const [dag, methods, native, adapter] = await Promise.all([
    options.dagMl ?? loadDagMlWasm(),
    options.methods ?? loadMethodsWasm(),
    loadArchiveV2Native(),
    options.estimatorAdapter ?? import('dag-ml-wasm/n4m-estimator-controller'),
  ]);
  if (typeof methods.loadModule === 'function') await methods.loadModule();
  const missing = [
    ['inspect_n4a_bytes', native], ['sha256_bytes', native],
    ['execute_training_json', dag], ['replay_training_package_json', dag],
  ].filter(([name, module]) => typeof module?.[name] !== 'function').map(([name]) => name);
  requireValue(missing.length === 0 && typeof native.N4aPredictPlan === 'function'
    && typeof native.N4aTrainPlan === 'function' && typeof adapter?.N4mWasmEstimatorControllers === 'function',
  `The loaded Core/DAG-ML WASM cohort does not expose the canonical .n4a actions (${missing.join(', ') || 'plans or estimator controller'}).`);
  return { dag, methods, native, Controller: adapter.N4mWasmEstimatorControllers, digest: (bytes) => native.sha256_bytes(bytes) };
}

// Each task picks its rows by sample ID from the one marshalled block.
function resolvers({ sourceId, ids, x, cols, y, width }) {
  const positions = new Map(ids.map((id, index) => [id, index]));
  requireValue(positions.size === ids.length, 'Plan sample IDs must be unique.');
  const select = (values, columns) => (wanted) => {
    const data = new Float64Array(wanted.length * columns);
    wanted.forEach((id, row) => {
      const position = positions.get(id);
      requireValue(position !== undefined, `Native task requested unknown sample '${id}'.`);
      data.set(values.subarray(position * columns, (position + 1) * columns), row * columns);
    });
    return { data, rows: wanted.length, cols: columns };
  };
  const features = select(x, cols), targets = y ? select(y, width) : null;
  return {
    resolveFeatures: ({ view }) => {
      requireValue(view.source_ids.length === 1 && view.source_ids[0] === sourceId, 'Native source mismatch.');
      return { sampleIds: [...view.sample_ids], matrix: features(view.sample_ids) };
    },
    resolveTargets: ({ sampleIds }) => {
      requireValue(targets, 'Target-free replay cannot request fitting labels.');
      return { sampleIds: [...sampleIds], matrix: targets(sampleIds) };
    },
  };
}

// Trusted manifests are needed before the plan (and its target names) exist.
function trustedManifests(deps) {
  const refuse = () => { throw new TypeError('Manifest probe carries no data.'); };
  const probe = new deps.Controller({ methods: deps.methods, dagMl: deps.dag, digest: deps.digest, targetNames: [],
    resolveFeatures: refuse, resolveTargets: refuse });
  try { return JSON.stringify(probe.manifests); } finally { probe.close(); }
}

// `early` is a Core object built before the runtime loads (the retrain facts).
// It is passed to `makePlan` and freed on every exit, including a runtime refusal.
async function train(options, makePlan, early) {
  try {
    const deps = await runtime(options);
    const plan = owner(() => makePlan(deps, trustedManifests(deps), early));
    try {
      const ids = JSON.parse(plan.sample_ids_json()), targetNames = JSON.parse(plan.target_names_json());
      const controller = new deps.Controller({ methods: deps.methods, dagMl: deps.dag, digest: deps.digest, targetNames,
        ...resolvers({ sourceId: plan.source_id, ids, x: plan.x(), cols: plan.cols, y: plan.y(), width: targetNames.length }) });
      try {
        const captured = JSON.parse(owner(() => deps.dag.execute_training_json(plan.request_json(), plan.envelopes_json(),
          plan.relations_json(), plan.package_id, plan.outcome_id, plan.run_id, plan.bundle_id, controller.callback)));
        const sealed = owner(() => plan.seal(captured.training_outcome_json, captured.portable_predictor_package_json,
          options.containerId ?? `container:${globalThis.crypto.randomUUID()}`, options.embedTrainingRecord ?? true,
          budgetOf(options)));
        try {
          return { archiveBytes: sealed.bytes(), view: JSON.parse(sealed.view_json()) };
        } finally { sealed.free(); }
      } finally { controller.close(); }
    } finally { plan.free(); }
  } finally { early?.free(); }
}

const runIdOf = (options) => options.runId ?? `run:wasm-n4a:${globalThis.crypto.randomUUID()}`;

/**
 * Train once in WASM and seal a canonical V1 `.n4a`. `record` is the exact IO
 * record bytes; `recipe` is the native pipeline recipe (object or JSON text),
 * parsed and refused or preserved completely by Core.
 */
export async function produceN4aNative(record, options) {
  const bytes = bytesOf(record, 'record'), settings = objectOf(options);
  const sourceId = text(settings.sourceId, 'sourceId');
  requireValue(typeof settings.recipe === 'string' || (settings.recipe !== null && typeof settings.recipe === 'object'),
    'recipe must be a native pipeline recipe object or its JSON text.');
  const recipe = typeof settings.recipe === 'string' ? settings.recipe : JSON.stringify(settings.recipe);
  const runId = runIdOf(settings), budget = budgetOf(settings);
  return train(settings, (deps, manifests) => {
    admit(deps.native, budget, bytes.byteLength);
    return new deps.native.N4aTrainPlan(bytes, sourceId, recipe, manifests, runId, budget);
  });
}

/**
 * Retrain from the recipe stored in the archive: the caller supplies a training
 * record and no recipe. Core reads and validates the stored recipe and source.
 */
export async function retrainN4aNative(archiveBytes, record, options = {}) {
  const archive = bytesOf(archiveBytes, 'archiveBytes'), bytes = bytesOf(record, 'record'), settings = objectOf(options);
  const runId = runIdOf(settings), budget = budgetOf(settings);
  // Core validates the archive and reads its stored recipe and source once, before any
  // runtime loads: anything outside the closed native model profile is refused here.
  const native = await loadArchiveV2Native();
  requireValue(typeof native?.N4aRetrainFacts === 'function', 'The loaded Core WASM bridge does not expose the .n4a retrain facts.');
  admit(native, budget, archive.byteLength);
  const facts = owner(() => new native.N4aRetrainFacts(archive, budget));
  return train(settings, (deps, manifests, held) => {
    admit(deps.native, budget, bytes.byteLength);
    return held.plan(bytes, manifests, runId, budget);
  }, facts);
}

/** Core-validated closed native-produced model view. Inspection is not executability. */
export async function inspectN4aBytes(archiveBytes, options = {}) {
  const bytes = bytesOf(archiveBytes, 'archiveBytes'), budget = budgetOf(objectOf(options));
  const native = await loadArchiveV2Native();
  requireValue(typeof native.inspect_n4a_bytes === 'function', 'The loaded Core WASM bridge does not expose inspect_n4a_bytes.');
  admit(native, budget, bytes.byteLength);
  return JSON.parse(owner(() => native.inspect_n4a_bytes(bytes, budget)));
}

/**
 * Replay an `.n4a` entrypoint in WASM. `record` is `undefined` for the stored
 * input or exact external IO bytes. `sampleIds` lists the selected partition in
 * the record's physical order; `replay` keeps the owner's own order, so align
 * predictions to rows by sample ID and target name.
 */
export async function predictN4aNative(archiveBytes, options) {
  const settings = objectOf(options), archive = bytesOf(archiveBytes, 'archiveBytes');
  const record = settings.record === undefined || settings.record === null ? undefined : bytesOf(settings.record, 'record');
  const entrypoint = text(settings.entrypoint, 'entrypoint'), sourceId = text(settings.sourceId, 'sourceId');
  const requestId = settings.requestId ?? 'request:wasm-n4a', runId = settings.runId ?? 'run:wasm-n4a:predict';
  const budget = budgetOf(settings);
  // Only the Core bridge loads before the plan: Core refuses an archive outside the supported
  // native profile before any Methods or DAG-ML runtime is touched. The plan is freed on every exit.
  const native = await loadArchiveV2Native();
  requireValue(typeof native?.N4aPredictPlan === 'function', 'The loaded Core WASM bridge does not expose the .n4a predict plan.');
  admit(native, budget, archive.byteLength, record?.byteLength ?? 0);
  const plan = owner(() => new native.N4aPredictPlan(archive, entrypoint, record, sourceId,
    settings.partition ?? 'predict', settings.requireTrainingSchema ?? true, requestId, budget));
  try {
    const deps = await runtime(settings);
    const ids = JSON.parse(plan.sample_ids_json()), targetNames = JSON.parse(plan.target_names_json());
    const controller = new deps.Controller({ methods: deps.methods, dagMl: deps.dag, digest: deps.digest, targetNames,
      ...resolvers({ sourceId, ids, x: plan.x(), cols: plan.cols }) });
    try {
      const replay = JSON.parse(owner(() => deps.dag.replay_training_package_json(plan.package_json(), plan.request_json(),
        plan.envelopes_json(), JSON.stringify(controller.manifests), `outcome:${requestId}`, runId, controller.callback)));
      return { replay, receipt: JSON.parse(plan.receipt_json()), sampleIds: ids };
    } finally { controller.close(); }
  } finally { plan.free(); }
}

export { N4aContainer, openN4aContainer, writeN4aContainer, writeN4aStream } from './n4a-storage.js';
