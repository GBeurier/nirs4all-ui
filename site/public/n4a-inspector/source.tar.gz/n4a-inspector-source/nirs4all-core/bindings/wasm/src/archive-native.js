// SPDX-License-Identifier: CeCILL-2.1 OR AGPL-3.0-or-later
let archiveNativePromise = null;

/** Load the Core-owned Archive V2 validator compiled from Rust to WASM. */
export async function loadArchiveV2Native() {
  if (!archiveNativePromise) {
    archiveNativePromise = (async () => {
      const module = await import('../native/nirs4all_core_wasm_native.js');
      if (typeof process !== 'undefined' && process?.versions?.node) {
        const { readFile } = await import('node:fs/promises');
        const bytes = await readFile(new URL(
          '../native/nirs4all_core_wasm_native_bg.wasm',
          import.meta.url,
        ));
        await module.default({ module_or_path: bytes });
      } else {
        await module.default();
      }
      return module;
    })();
  }
  return archiveNativePromise;
}

