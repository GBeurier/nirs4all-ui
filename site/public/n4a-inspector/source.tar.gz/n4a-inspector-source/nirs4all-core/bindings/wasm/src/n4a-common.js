// SPDX-License-Identifier: CeCILL-2.1 OR AGPL-3.0-or-later
const requireValue = (ok, message) => { if (!ok) throw new TypeError(message); };

function bytesOf(value, name) {
  if (value instanceof Uint8Array) return value;
  if (ArrayBuffer.isView(value)) return new Uint8Array(value.buffer, value.byteOffset, value.byteLength);
  if (value instanceof ArrayBuffer) return new Uint8Array(value);
  throw new TypeError(`${name} must be exact bytes (Uint8Array or ArrayBuffer), not text or an object.`);
}
const text = (value, name) => {
  requireValue(typeof value === 'string' && value.length > 0, `${name} must be a non-empty string.`);
  return value;
};
const objectOf = (value) => {
  requireValue(value !== null && typeof value === 'object' && !Array.isArray(value), 'Options must be an object.');
  return value;
};
// wasm-bindgen throws bare strings; surface the owner's refusal text as an Error.
function owner(call) {
  try {
    return call();
  } catch (error) {
    throw typeof error === 'string' ? new Error(error) : error;
  }
}

// The optional working-memory budget, as BigInt for Core's `Option<u64>`: a safe
// integer, a BigInt or exact decimal text, never rounded. `undefined` declares
// no Core ceiling. This is input validation only: no default and no maximum.
const U64_MAX = (1n << 64n) - 1n;
function budgetOf(options) {
  const value = options?.memoryBudgetBytes;
  if (value === undefined || value === null || value === '') return undefined;
  let budget;
  if (typeof value === 'bigint') budget = value;
  else if (typeof value === 'number' && Number.isSafeInteger(value)) budget = BigInt(value);
  else if (typeof value === 'string' && /^[0-9]+$/.test(value)) budget = BigInt(value);
  else throw new TypeError('memoryBudgetBytes must be a safe integer, a BigInt or exact decimal text.');
  if (budget < 0n || budget > U64_MAX) throw new RangeError('memoryBudgetBytes must lie in 0..18446744073709551615.');
  return budget;
}
// Core admission BEFORE a wasm-bindgen argument copy: the copy itself is an
// allocation Core cannot make fallible. No budget means nothing to admit.
function admit(native, budget, ...lengths) {
  if (budget === undefined) return;
  const total = lengths.reduce((sum, length) => sum + BigInt(length), 0n);
  owner(() => native.n4a_admit(budget, total));
}


export { requireValue, bytesOf, text, objectOf, owner, budgetOf, admit, U64_MAX };
